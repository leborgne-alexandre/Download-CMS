$(document).ready(function(){

    $("#add-text-element").click(function(){
        alertInputFieldMessage("Entrez un nom pour l'élément :", "Valider", "Annuler", "beforeAddElement", "", "text");
    });

    $("#add-image-element").click(function(){
        alertInputFieldMessage("Entrez un nom pour l'élément :", "Valider", "Annuler", "beforeAddElement", "", "image");
    });

    $("#add-video-element").click(function(){
        alertInputFieldMessage("Entrez un nom pour l'élément :", "Valider", "Annuler", "beforeAddElement", "", "video");
    });

    $("#add-link-element").click(function(){
        alertInputFieldMessage("Entrez un nom pour l'élément :", "Valider", "Annuler", "beforeAddElement", "", "link");
    });

    String.prototype.replaceArray = function(search, replace) {
        var replaceString = this;
        for (var i = 0; i < search.length; i++) {
          replaceString = replaceString.replace(search[i], replace[i]);
        }
        return replaceString;
      };

    window.convertStringToElementName = function convertStringToElementName(elementName){

        var search = ['À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 
        'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 
        'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 
        'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 
        'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 
        'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 
        'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ', 
        '&', ' ', '?', '!', 'ç', ';', '/', '\'', ',', '"', '+', '(', ')', '[', ']', '{', '}', '='];
        var replace = ['A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 
        'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 
        'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 
        'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 
        'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 
        's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 
        's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o', '', '-', '', '', 
        'c', '', '-', '-', '', '', '-', '-', '-', '-', '-', '-', '-', '-'];

        var result = elementName.replaceArray(search, replace);

        return encodeURIComponent(result.toLowerCase());

    }

    window.chooseMedia = function chooseMedia(type){
        getMediasToAdd(type);
    }

    window.createBoxWithMedias = function createBoxWithMedias(data, isEditMenu, isBackground){
        var json = JSON.parse(data);

        var html = "";

        for (i in json){
            if(json[i].type === "image"){
                if(json[i].is_initial)
                    html += "<div class='icon-in-media-list' data-path='" + json[i].path + "' data-filename='" + json[i].file_name + "' style='background-image: url(" + json[i].path + json[i].file_name + ");' title='Choisir cette image' onclick='selectMedia(this, \"image\", " + isEditMenu + ", " + isBackground + ");' ></div>";
                else
                    html += "<div class='icon-in-media-list' data-path='" + window.PATH_DL_MEDIAS + "' data-filename='" + json[i].file_name + "' style='background-image: url(" + window.PATH_DL_MEDIAS + json[i].file_name + ");' title='Choisir cette image' onclick='selectMedia(this, \"image\", " + isEditMenu + ", " + isBackground + ");' ></div>";
            }else if(json[i].type === "video"){
                if(json[i].is_initial)
                    html += "<video class='icon-in-media-list' data-path='" + json[i].path + "' data-filename='" + json[i].file_name + "' title='Choisir cette vidéo' onclick='selectMedia(this, \"video\", " + isEditMenu + ", " + isBackground + ");' muted autoplay loop><source src='" + json[i].path + json[i].file_name + "' /></video>";
                else
                    html += "<video class='icon-in-media-list' data-path='" + window.PATH_DL_MEDIAS + "' data-filename='" + json[i].file_name + "' title='Choisir cette vidéo' onclick='selectMedia(this, \"video\", " + isEditMenu + ", " + isBackground + ");' muted autoplay loop><source src='" + window.PATH_DL_MEDIAS + json[i].file_name + "' /></video>";
            }
        }

        html += "<input id='cta-close-media-list' type='button' value='Fermer' onclick='closeMediaList(" + isEditMenu + ", " + isBackground + ");' />";

        if(!isEditMenu){
            $("#display-media-list").removeClass("hidden");
            $("#display-media-list").html(html);
        }else{
            if(!isBackground){
                $("#display-media-list-edit-menu").removeClass("hidden");
                $("#display-media-list-edit-menu").html(html);
            }else{
                $("#display-media-list-edit-menu-background").removeClass("hidden");
                $("#display-media-list-edit-menu-background").html(html);
            }
        }


    }

    window.closeMediaList = function closeMediaList(isEditMenu = false, isBackground = false){
        if(!isEditMenu){
            $("#display-media-list").addClass("hidden");
            $("#display-media-list").html("");
        }else{
            if(!isBackground){
                $("#display-media-list-edit-menu").addClass("hidden");
                $("#display-media-list-edit-menu").html("");
            }else{
                $("#display-media-list-edit-menu-background").addClass("hidden");
                $("#display-media-list-edit-menu-background").html("");
            }
        }
    }

    window.selectMedia = function selectMedia(element, type, isEditMenu = false, isBackground = false){
        if(!isEditMenu){
            $("#display-media-list").addClass("hidden");
            $("#display-media-list").html("");

            if(type === "image")
                var html = "<label class='label-selected-media' >Image séléctionnée : </label><div class='selected-media' data-path='" + $(element).attr("data-path") + "' data-filename='" + $(element).attr("data-filename") + "' style='background-image: url(" + $(element).attr("data-path") + $(element).attr("data-filename")+ ");' ></div>";
            else if(type === "video")
                var html = "<label class='label-selected-media' >Vidéo séléctionnée : </label><video class='selected-media' data-path='" + $(element).attr("data-path") + "' data-filename='" + $(element).attr("data-filename") + "' muted autoplay loop><source src='" + $(element).attr("data-path") + $(element).attr("data-filename") + "' /></video>";

            $("#display-selected-media").html(html);
        }else{
            if(!isBackground){
                var idElement = $(".preview-media-edit-menu").attr("data-idelement");

                if(type === "image"){
                    $(".preview-media-edit-menu").css("background-image", "url(" + $(element).attr("data-path") + $(element).attr("data-filename") + ")");
                }else if(type === "video"){
                    $(".preview-media-edit-menu").attr("src", $(element).attr("data-path") + $(element).attr("data-filename"));
                }

                $("#display-media-list-edit-menu").addClass("hidden");
                $("#display-media-list-edit-menu").html("");

                changeMediaView(idElement, $(element).attr("data-path"), $(element).attr("data-filename"));
            }else{
                $("#display-media-list-edit-menu-background").addClass("hidden");
                $("#display-media-list-edit-menu-background").html("");

                var idElement = $("#select-background-edit-menu").attr("data-idelement");

                $("#preview-image-edit-menu-background").removeClass("hidden");
                $("#label-selected-image-background").removeClass("hidden");

                changeMediaView(idElement, $(element).attr("data-path"), $(element).attr("data-filename"), isBackground);
            }
        }
    }

});
