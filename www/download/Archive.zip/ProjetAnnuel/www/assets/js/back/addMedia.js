$(document).ready(function(){

    var fileInput = document.querySelector(".input-file");
    fileInput.addEventListener("change", function(event) {
        if($(this).val() == ""){
            $(".label-add-media").html("Ajouter un média");
            $("#upload-media").attr("class", "hidden");
        }else{
            $(".label-add-media").html($(this).val());
            $("#upload-media").attr("class", "visible");
        }
    });

    window.cancelDownloadMedia = function cancelDownloadMedia(){
        $("#display-preview-media").html("");
        $('#display-media-loader').html('');
    }

    window.validateDownloadMedia = function validateDownloadMedia(fileName, fileSize){
       var title = $("#text-field-preview-media").val();
       addMedia(fileName, fileSize, "image", title);
    }

    $(".bloc-display-media").hover(function(){
        var elementId = $(this).attr("id");
        $("#" + elementId + " .cta-delete-media").removeClass("hidden");
        $("#" + elementId + " .infos-box-media").removeClass("hidden");
    }, function(){
        var elementId = $(this).attr("id");
        $("#" + elementId + " .cta-delete-media").addClass("hidden");
        $("#" + elementId + " .infos-box-media").addClass("hidden");
    });

    window.mediaHover = function mediaHover(element){
        var elementId = $(element).attr("id");
        $("#" + elementId + " .cta-delete-media").removeClass("hidden");
        $("#" + elementId + " .infos-box-media").removeClass("hidden");
    }
    
    window.mediaNotHover = function mediaNotHover(element){
        var elementId = $(element).attr("id");
        $("#" + elementId + " .cta-delete-media").addClass("hidden");
        $("#" + elementId + " .infos-box-media").addClass("hidden");
    }

    $(".cta-delete-media").click(function(event){
        event.stopPropagation();
        var fileName = $(this).attr("data-filename");
        var path = $(this).attr("data-path");
        deleteMedia(fileName, path, $(this).parent().attr("id"));
    });

    window.deleteNewMedia = function deleteNewMedia(element, event){
        event.stopPropagation();
        var fileName = $(element).attr("data-filename");
        deleteMedia(fileName, $(element).parent().attr("id"));
    }

    $(".bloc-display-media").click(function(){
        var elementId = $(this).attr("id");
        $("#" + elementId + " .background-media").addClass("show-full-media");
        $("#" + elementId).removeClass("bloc-display-media");
        $(".show-full-media").html("<button id='close-full-screen-media' onclick='closeFullScreenMedia(this, event);'><i class='fas fa-times'></i></buton>");
    });

    window.showFullScreenMedia = function showFullScreenMedia(element){
        var elementId = $(element).attr("id");
        $("#" + elementId + " .background-media").addClass("show-full-media");
        $("#" + elementId).removeClass("bloc-display-media");
        $(".show-full-media").html("<button id='close-full-screen-media' onclick='closeFullScreenMedia(this, event);'><i class='fas fa-times'></i></buton>");
    }

    window.closeFullScreenMedia = function closeFullScreenMedia(element, event){
        event.stopPropagation();
        var mainParentId = $(element).parent().parent().attr("id");
        var id = $("#" + mainParentId + " .background-media").attr("id");
        $("#" + id).removeClass("show-full-media");
        $("#" + id).parent().addClass("bloc-display-media");
        $(".background-media").html("");
    }

});