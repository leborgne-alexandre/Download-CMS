afterAlertChoiceFunctions = {

	deletePage : function(element)	{
		$.ajax({
			url: 'deletePageInPageList?page='+ element.attr("name") +'',
			type:'GET',
			success: function(data){

				$(element).parent().parent().parent().remove();
				//document.getElementById("count-elements").deleteRow(parseInt(element.val()) + 1);

				$('#main-display-search').html("");
			}
		});
	},
	deleteAnnounce : function(element)	{
		$.ajax({
            url: 'deleteAnnounceInPageList?a='+ element.attr("name") +'',
            type:'GET',
            success: function(data){

				//document.getElementById("count-elements").deleteRow(parseInt(element.val()) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html("");
            }
		});
	},
	deletePageWhileSearch : function(element) {
		$.ajax({
            url: 'deletePageInPageList?page='+ element.attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements tr').each(function(){
            	
					if(element.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

				//document.getElementById("count-elements").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	},
	deleteAnnounceWhileSearch : function(element) {
		$.ajax({
            url: 'deleteAnnounceInPageList?a='+ element.attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements tr').each(function(){
            	
					if(element.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

				//document.getElementById("count-elements").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	},
	beforeAddElement : function(element, elementName, fileName, path) {
		var slug = $("#page-slug").val();
		addElement(element, elementName, slug, fileName, path);
	}
};

$(document).ready(function(){
	
	/**
	*
	*
	* Recherche des pages dans page-list
	*
	***/

	$("#search-bar-pages").keyup(function(){

		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");

		$.ajax({
			url: 'searchPages?q='+ encodeURIComponent($(this).val()) +'',
			type:'GET',
			success: function(data){
				if($("#search-bar-pages").val() != ""){
					$('#main-display-search').html("<div class='display-search'><table id='count-elements-search'><thead><tr><th id='title'>Titre</th><th>Auteur</th><th>Date de modification</th><th>Description</th><th>Etat</th><th>Action</th></tr></thead><tbody id='body-display-search-pages'>" + data + "</tbody></table></div>");
					$('#display-list-pages').addClass("hidden");
				}else{
					$('#main-display-search').html("");
					$('#display-list-pages').removeClass("hidden");
				}
			}
		});
	});

	/**
	*
	*
	* supprimé page dans page-list
	*
	***/

	$(".cta-delete-page-in-page-list").click(function(){
		var element = $(this);
		alertChoiceMessage('Etes vous sur de vouloir supprimer cette page ?', 'Oui', 'Non', 'deletePage', '', element);
	});

	/**
	*
	*
	* active ou desactive la page
	*
	***/

	$(".active-no-active-button").click(function(){
		var element = $(this);

		if(element.val() == "activate"){
			$.ajax({
				url: 'activatePage?page='+ element.attr("name") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-full active-page active-no-active-icon'></i>");
					element.attr("value", "desactivate");
					element.attr("id", element.attr("id").substr(3));
					element.attr("title", "Désactiver la page ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='page-state-']").html("active");

				}
			});
		}else if(element.val() == "desactivate"){
			$.ajax({
				url: 'desactivatePage?page='+ element.attr("name") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-empty no-active-page active-no-active-icon'></i>");
					element.attr("value", "activate");
					element.attr("id", "no-" + element.attr("id"));
					element.attr("title", "Activer la page ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='page-state-']").html("non active");
				}
			});
		}
	});

	/**
	*
	*
	* active ou desactive la page pour les pages recherchés
	*
	***/

	window.activateOrDesactivatePage = function activateOrDesactivatePage(elementFocus, statut){

		var element = $(elementFocus);

		if(element.val() == "activate"){
			$.ajax({
				url: 'activatePage?page='+ element.attr("name") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-full active-page active-no-active-icon'></i>");
					element.attr("value", "desactivate");
					element.attr("id", element.attr("id").substr(3));
					element.attr("title", "Désactiver la page ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='searched-page-state-']").html("active");

				}
			});
		}else if(element.val() == "desactivate"){
			$.ajax({
				url: 'desactivatePage?page='+ element.attr("name") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-empty no-active-page active-no-active-icon'></i>");
					element.attr("value", "activate");
					element.attr("id", "no-" + element.attr("id"));
					element.attr("title", "Activer la page ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='searched-page-state-']").html("non active");
				}
			});
		}

	}

	/**
	*
	*
	* supprimé page dans page-list dans la recherche
	*
	***/

	window.deleteInPageListPageWhileSearch = function deleteInPageListPageWhileSearch(elementFocus){

		var element = $(elementFocus);
		alertChoiceMessage('Etes vous sur de vouloir supprimer cette page ?', 'Oui', 'Non', 'deletePageWhileSearch', '', element);
	}

	/**
	*
	*
	* Recherche des annonces dans announce-list
	*
	***/

	$("#search-bar-announce").keyup(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'searchAnnounces?q='+ encodeURIComponent($(this).val()) +'',
            type:'GET',
            success: function(data){
            	if($("#search-bar-announce").val() != ""){
                	$('#main-display-search').html("<div class='display-search'><table id='count-elements-search'><thead><tr><th id='title'>Titre</th><th>Auteur</th><th>Date de création</th><th>Etat</th><th>Action</th></tr></thead><tbody id='body-display-search-pages'>" + data + "</tbody></table></div>");
					$('#display-list-announces').addClass("hidden");
				}else{
            		$('#main-display-search').html("");
					$('#display-list-announces').removeClass("hidden");
				}
            }
        });
	});

	/**
	*
	*
	* supprimé annonce dans annonce-list
	*
	***/

	$(".cta-delete-announce-in-page-list").click(function(){

		var element = $(this);
		alertChoiceMessage('Etes vous sur de vouloir supprimer cette annonce ?', 'Oui', 'Non', 'deleteAnnounce', '', element);

	});

	$(".cta-activate-desactivate-announce-in-page-list").click(function(){
		var element = $(this);

		if(element.val() == "activate"){
			$.ajax({
				url: 'activateAnnounce?announce='+ element.attr("data-slug") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-full cta-announce-activated'></i>");
					element.attr("value", "desactivate");
					element.attr("id", element.attr("id").substr(3));
					element.attr("title", "Désactiver l'annonce ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='announce-state-']").html("Active");

				}
			});
		}else if(element.val() == "desactivate"){
			$.ajax({
				url: 'desactivateAnnounce?announce='+ element.attr("data-slug") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-empty cta-announce-desactivated'></i>");
					element.attr("value", "activate");
					element.attr("id", "no-" + element.attr("id"));
					element.attr("title", "Activer l'annonce ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='announce-state-']").html("Non active");
				}
			});
		}
	});

	window.activateOrDesactivateAnnounce = function activateOrDesactivateAnnounce(element){
		var element = $(element);

		if(element.val() == "activate"){
			$.ajax({
				url: 'activateAnnounce?announce='+ element.attr("data-slug") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-full cta-announce-activated'></i>");
					element.attr("value", "desactivate");
					element.attr("id", element.attr("id").substr(3));
					element.attr("title", "Désactiver l'annonce ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='announce-state-']").html("Active");

				}
			});
		}else if(element.val() == "desactivate"){
			$.ajax({
				url: 'desactivateAnnounce?announce='+ element.attr("data-slug") +'',
				type:'GET',
				success: function(data){
					element.html("<i class='fas fa-battery-empty cta-announce-desactivated'></i>");
					element.attr("value", "activate");
					element.attr("id", "no-" + element.attr("id"));
					element.attr("title", "Activer l'annonce ?");

					var parentLabelStatut = element.parent().parent().parent().attr("id");
					$("#" + parentLabelStatut + " td[id^='announce-state-']").html("Non active");
				}
			});
		}
	}

	/**
	*
	*
	* supprimé annonce dans annonce-list dans la recherche
	*
	***/

	window.deleteInPageListAnnounceWhileSearch = function deleteInPageListAnnounceWhileSearch(elementFocus){

		var element = $(elementFocus);
		alertChoiceMessage('Etes vous sur de vouloir supprimer cette annonce ?', 'Oui', 'Non', 'deleteAnnounceWhileSearch', '', element);

	}

	/**
	*
	*
	* Recherche des users dans user-list
	*
	***/

	$("#search-bar-users").keyup(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'searchUsers?q='+ encodeURIComponent($(this).val()) +'',
            type:'GET',
            success: function(data){
            	if($("#search-bar-users").val() != ""){
                	$('#main-display-search').html("<div class='display-search display-search-users'><table id='count-elements-search'><thead><tr><th id='name'>Nom</th><th>Prénom</th><th>Adresse mail</th><th>Rôle</th><th>Etat</th><th>Statut</th><th>Action</th></tr></thead><tbody id='body-display-search-users'>" + data + "</tbody></table></div>");
					$('#display-list-user').addClass("hidden");
				}else{
					$('#main-display-search').html("");
					$('#display-list-user').removeClass("hidden");
            	}
            }
        });
	});

	$(".cta-more-details-user-moderator").click(function(){
		var mail = $(this).val();
		getUserDetails(mail);
	});

	/**
	*
	*
	* recherche details d un user ou moderator
	*
	***/

	window.getUserDetails = function getUserDetails(mail){
		$('#display-details').html("<div class='display-loader loader-absolute'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'getUserModeratorDetails?u='+ mail +'',
            type:'GET',
            success: function(data){
            	$("#display-details").html(data);
            }
        });

	}

	/**
	*
	*
	* ban user dans user-list
	*
	***/

	$(".cta-delete-user-in-user-list").click(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'banUserOrModeratorInUserList?u='+ $(this).attr("name") +'',
            type:'GET',
            success: function(data){

            	document.getElementById("count-elements-user").deleteRow(parseInt(save.val()) + 1);

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* supprimé user dans user-list dans la recherche
	*
	***/

	window.banInUserListUserWhileSearch = function banInUserListUserWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'banUserOrModeratorInUserList?u='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-user tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

				//document.getElementById("count-elements-user").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/**
	*
	*
	* Recherche des moderateurs dans user-list
	*
	***/

	$("#search-bar-moderators").keyup(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'searchModerators?q='+ encodeURIComponent($(this).val()) +'',
            type:'GET',
            success: function(data){
            	if($("#search-bar-moderators").val() != ""){
                	$('#main-display-search').html("<div class='display-search display-search-moderators'><table id='count-elements-search'><thead><tr><th id='name'>Nom</th><th>Prénom</th><th>Adresse mail</th><th>Rôle</th><th>Etat</th><th>Statut</th><th>Action</th></tr></thead><tbody id='body-display-search-users'>" + data + "</tbody></table></div>");
					$('#display-list-moderator').addClass("hidden");
				}else{
					$('#main-display-search').html("");
					$('#display-list-moderator').removeClass("hidden");
            	}
            }
        });
	});

	/**
	*
	*
	* bannir moderator dans user-list
	*
	***/

	$(".cta-delete-moderator-in-user-list").click(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'banUserOrModeratorInUserList?u='+ $(this).attr("name") +'',
            type:'GET',
            success: function(data){

            	document.getElementById("count-elements-moderator").deleteRow(parseInt(save.val()) + 1);

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* supprimé moderator dans user-list dans la recherche
	*
	***/

	window.banInUserListModeratorWhileSearch = function banInUserListModeratorWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'banUserOrModeratorInUserList?u='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-moderator tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

				//document.getElementById("count-elements-moderator").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/**
	*
	*
	* Recherche des admin dans user-list
	*
	***/

	$("#search-bar-admins").keyup(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'searchAdmins?q='+ encodeURIComponent($(this).val()) +'',
            type:'GET',
            success: function(data){
            	if($("#search-bar-admins").val() != ""){
                	$('#main-display-search').html("<div class='display-search display-search-admins'><table id='count-elements-search'><thead><tr><th>Nom d'utilisateur</th><th>Adresse mail</th><th>Rôle</th><th>Etat</th><th>Statut</th><th>Action</th></tr></thead><tbody id='body-display-search-users'>" + data + "</tbody></table></div>");
					$('#display-list-admin').addClass("hidden");
				}else{
					$('#main-display-search').html("");
					$('#display-list-admin').removeClass("hidden");
            	}
            }
        });
	});

	/**
	*
	*
	* bannir admin dans user-list
	*
	***/

	$(".cta-delete-admin-in-user-list").click(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'banAdminInUserList?a='+ $(this).attr("name") +'',
            type:'GET',
            success: function(data){

            	document.getElementById("count-elements-admin").deleteRow(parseInt(save.val()) + 1);

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* ban admin dans user-list dans la recherche
	*
	***/

	window.banInUserListAdminWhileSearch = function banInUserListAdminWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'banAdminInUserList?a='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-admin tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

				//document.getElementById("count-elements-admin").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/**
	*
	*
	* Recherche des user et moderateur banni dans user-list
	*
	***/

	$("#search-bar-users-moderators-banned").keyup(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'searchUsersModeratorBanned?q='+ encodeURIComponent($(this).val()) +'',
            type:'GET',
            success: function(data){
            	if($("#search-bar-users-moderators-banned").val() != ""){
                	$('#main-display-search').html("<div class='display-search display-search-users-moderators-banned'><table id='count-elements-search'><thead><tr><th>Nom</th><th>Prénom</th><th>Adresse mail</th><th>Rôle</th><th>Etat</th><th>Statut</th><th>Action</th></tr></thead><tbody id='body-display-search-users'>" + data + "</tbody></table></div>");
					$('#display-list-users-moderators-banned').addClass("hidden");
				}else{
            		$('#main-display-search').html("");
					$('#display-list-users-moderators-banned').removeClass("hidden");
				}
            }
        });
	});

	/**
	*
	*
	* supprimé definitivement user et moderateur banni dans user-list
	*
	***/

	$(".cta-delete-users-moderators-banned-in-user-list").click(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'deleteUserAndModeratorBanned?u='+ $(this).attr("name") +'',
            type:'GET',
            success: function(data){

            	document.getElementById("count-elements-users-moderators-banned").deleteRow(parseInt(save.val()) + 1);

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* supprimé definitivement user et moderateur banni dans user-list dans la recherche
	*
	***/

	window.deleteInUserListUsersAndModeratorsBannedWhileSearch = function deleteInUserListUsersAndModeratorsBannedWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'deleteUserAndModeratorBanned?u='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-users-moderators-banned tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

            	//document.getElementById("count-elements-users-moderators-banned").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/**
	*
	*
	* Recherche des admin banni dans user-list
	*
	***/

	$("#search-bar-admin-banned").keyup(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		$.ajax({
            url: 'searchAdminBanned?q='+ encodeURIComponent($(this).val()) +'',
            type:'GET',
            success: function(data){
            	if($("#search-bar-admin-banned").val() != ""){
                	$('#main-display-search').html("<div class='display-search display-search-admins-banned'><table id='count-elements-search'><thead><tr><th>Nom d'utilisateur</th><th>Adresse mail</th><th>Rôle</th><th>Etat</th><th>Statut</th><th>Action</th></tr></thead><tbody id='body-display-search-users'>" + data + "</tbody></table></div>");
					$('#display-list-admin-banned').addClass("hidden");
				}else{
            		$('#main-display-search').html("");
					$('#display-list-admin-banned').removeClass("hidden");
				}
            }
        });
	});

	/**
	*
	*
	* supprimé definitivement admin banni dans user-list
	*
	***/

	$(".cta-delete-admin-banned-in-user-list").click(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'deleteAdminBanned?a='+ $(this).attr("name") +'',
            type:'GET',
            success: function(data){

            	document.getElementById("count-elements-admin-banned").deleteRow(parseInt(save.val()) + 1);

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* supprimé definitivement admin banni dans user-list dans la recherche
	*
	***/

	window.deleteInUserListAdminBannedWhileSearch = function deleteInUserListAdminBannedWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'deleteAdminBanned?a='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-admin-banned tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

            	//document.getElementById("count-elements-admin-banned").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/**
	*
	*
	* debannir utilisateur ou moderateur dans user-list
	*
	***/

	$(".cta-unban-user-moderator-in-user-list").click(function(){

		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'unbanUserModerator?u='+ save.attr("name") +'',
            type:'GET',
            success: function(data){

            	//document.getElementById("count-elements-users-moderators-banned").deleteRow(parseInt(save.val()) + 1);
				save.parent().parent().parent().remove();

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* debannir utilisateur ou moderateur dans user-list dans la recherche
	*
	***/

	window.unbanInUserListUserModeratorWhileSearch = function unbanInUserListUserModeratorWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'unbanUserModerator?u='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-users-moderators-banned tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

            	//document.getElementById("count-elements-users-moderators-banned").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/**
	*
	*
	* debannir admin dans user-list
	*
	***/

	$(".cta-unban-admin-in-user-list").click(function(){
		$('#main-display-search').html("<div class='display-loader'><i class='fas fa-spinner fa-spin'></i></div>");
		var save = $(this);
		$.ajax({
            url: 'unbanAdmin?a='+ $(this).attr("name") +'',
            type:'GET',
            success: function(data){

            	document.getElementById("count-elements-admin-banned").deleteRow(parseInt(save.val()) + 1);

            	$('#main-display-search').html("");
            }
        });
	});

	/**
	*
	*
	* debannir admin dans user-list dans la recherche
	*
	***/

	window.unbanInUserListAdminWhileSearch = function unbanInUserListAdminWhileSearch(element){

		$('#main-display-search').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
		var save = $(element);
		$.ajax({
            url: 'unbanAdmin?a='+ $(element).attr('name') +'',
            type:'GET',
            success: function(data){
            	var value;
            	$('#count-elements-admin-banned tr').each(function(element){
            	
					if(save.attr('name') == $(this).children().last().children().children().last().attr('name')){
						value = $(this).children().last().children().children().last().val();
					}
            	});

            	//document.getElementById("count-elements-admin-banned").deleteRow(parseInt(value) + 1);
				$(element).parent().parent().parent().remove();

            	$('#main-display-search').html('');
            }
        });
	}

	/*******
	*
	*
	*
	*	incrementation offset dans requete sql si scroll en tout en bas du tableau pour gain de performance a l affichage
	*
	*/

	var offsetAnnounces = 20;
	var offsetUser = 20;
	var offsetModerator = 20;
	var offsetAdmin = 20;
	var offsetUsersModeratorsBanned = 20;
	var offsetAdminBanned = 20;

	$('.display-list, .display-search').data('ajaxready', true);

	$('.display-list, .display-search').append('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');
	$('.display-loader').fadeOut(0);

	var deviceAgent = navigator.userAgent.toLowerCase();
	var agentID = deviceAgent.match(/(iphone|ipod|ipad)/);

	$('.display-list-announces').scroll(function() {
		incOffsetAnnouncesScroll();
	});
	$('.display-list-user').scroll(function() {
		incOffsetUserScroll();
	});
	$('.display-list-moderator').scroll(function() {
		incOffsetModeratorScroll();
	});
	$('.display-list-admin').scroll(function() {
		incOffsetAdminScroll();
	});
	$('.display-list-users-moderators-banned').scroll(function() {
		incOffsetUsersModeratorsBannedScroll();
	});
	$('.display-list-admin-banned').scroll(function() {
		incOffsetAdminBannedScroll();
	});

	function incOffsetAnnouncesScroll(){

		if ($('.display-list-announces').data('ajaxready') == false) return;

		var scrollDiv = document.getElementById('display-list-announces')

		if (scrollDiv.offsetHeight + scrollDiv.scrollTop >= scrollDiv.scrollHeight
		|| agentID && (scrollDiv.offsetHeight + scrollDiv.scrollTop) > scrollDiv.scrollHeight){

			$('.display-list-announces').data('ajaxready', false);

			$.get('getAnnouncesWithNewOffset?offset=' + offsetAnnounces +'', function(data){

				if (data != '') {

					  $('#display-list-announces table tbody tr').last().after(data);
									
					  offsetAnnounces+= 20;
					  
					  $('.display-list-announces').data('ajaxready', true);
				}
						
				$('.display-loader').fadeOut(400);
						
			});
		}

	}

	function incOffsetUserScroll(){

		if ($('.display-list-user').data('ajaxready') == false) return;

		var scrollDiv = document.getElementById('display-list-user')

		if (scrollDiv.offsetHeight + scrollDiv.scrollTop >= scrollDiv.scrollHeight
		|| agentID && (scrollDiv.offsetHeight + scrollDiv.scrollTop) > scrollDiv.scrollHeight){

			$('.display-list-user').data('ajaxready', false);

			$.get('getUsersModeratorsWithNewOffset?offset=' + offsetUser +'', function(data){

				if (data != '') {

					  $('#display-list-user table tbody tr').last().after(data);
									
					  offsetUser+= 20;
					  
					  $('.display-list-user').data('ajaxready', true);
				}
						
				$('.display-loader').fadeOut(400);
						
			});
		}

	}

	function incOffsetModeratorScroll(){

		if ($('.display-list-moderator').data('ajaxready') == false) return;

		var scrollDiv = document.getElementById('display-list-moderator')

		if (scrollDiv.offsetHeight + scrollDiv.scrollTop >= scrollDiv.scrollHeight
		|| agentID && (scrollDiv.offsetHeight + scrollDiv.scrollTop) > scrollDiv.scrollHeight){

			$('.display-list-moderator').data('ajaxready', false);

			$.get('getUsersModeratorsWithNewOffset?offset=' + offsetModerator +'&role=3', function(data){

				if (data != '') {

					  $('#display-list-moderator table tbody tr').last().after(data);
									
					  offsetModerator+= 20;
					  
					  $('.display-list-moderator').data('ajaxready', true);
				}
						
				$('.display-loader').fadeOut(400);
						
			});
		}

	}

	function incOffsetAdminScroll(){

		if ($('.display-list-admin').data('ajaxready') == false) return;

		var scrollDiv = document.getElementById('display-list-admin')

		if (scrollDiv.offsetHeight + scrollDiv.scrollTop >= scrollDiv.scrollHeight
		|| agentID && (scrollDiv.offsetHeight + scrollDiv.scrollTop) > scrollDiv.scrollHeight){

			$('.display-list-admin').data('ajaxready', false);

			$.get('getAdminWithNewOffset?offset=' + offsetAdmin +'', function(data){

				if (data != '') {

					  $('#display-list-admin table tbody tr').last().after(data);
									
					  offsetAdmin+= 20;
					  
					  $('.display-list-admin').data('ajaxready', true);
				}
						
				$('.display-loader').fadeOut(400);
						
			});
		}

	}

	function incOffsetUsersModeratorsBannedScroll(){

		if ($('.display-list-users-moderators-banned').data('ajaxready') == false) return;

		var scrollDiv = document.getElementById('display-list-users-moderators-banned')

		if (scrollDiv.offsetHeight + scrollDiv.scrollTop >= scrollDiv.scrollHeight
		|| agentID && (scrollDiv.offsetHeight + scrollDiv.scrollTop) > scrollDiv.scrollHeight){

			$('.display-list-users-moderators-banned').data('ajaxready', false);

			$.get('getUsersModeratorsBannedWithNewOffset?offset=' + offsetUsersModeratorsBanned +'', function(data){

				if (data != '') {

					  $('#display-list-users-moderators-banned table tbody tr').last().after(data);
									
					  offsetUsersModeratorsBanned+= 20;
					  
					  $('.display-list-users-moderators-banned').data('ajaxready', true);
				}
						
				$('.display-loader').fadeOut(400);
						
			});
		}

	}

	function incOffsetAdminBannedScroll(){

		if ($('.display-list-admin-banned').data('ajaxready') == false) return;

		var scrollDiv = document.getElementById('display-list-admin-banned')

		if (scrollDiv.offsetHeight + scrollDiv.scrollTop >= scrollDiv.scrollHeight
		|| agentID && (scrollDiv.offsetHeight + scrollDiv.scrollTop) > scrollDiv.scrollHeight){

			$('.display-list-admin-banned').data('ajaxready', false);

			$.get('getAdminBannedWithNewOffset?offset=' + offsetAdminBanned +'', function(data){

				if (data != '') {

					  $('#display-list-admin-banned table tbody tr').last().after(data);
									
					  offsetAdminBanned+= 20;
					  
					  $('.display-list-admin-banned').data('ajaxready', true);
				}
						
				$('.display-loader').fadeOut(400);
						
			});
		}

	}

	window.getEditableStyles = function getEditableStyles(idElement){

		$.ajax({
			url: 'getEditableStyles?id='+ idElement +'',
			type:'GET',
			success: function(data){
				$('.display-editable-styles').html(data);
			}
		});

	}

	window.insertNewStyle = function insertNewStyle(styleName, value, idElementValue, elementSelected = null){

		$.ajax({
			url: 'insertNewStyle?style='+ styleName +'&value='+ encodeURIComponent(value) +'&element='+ idElementValue,
			type:'GET',
			success: function(data){
				if(styleName == "contenu"){
					$("#" + elementSelected).html(data);
					$("#" + elementSelected).val(data);
				}else if(styleName == "placeholder"){
					$("#" + elementSelected).attr("placeholder", data);
				}
			}
		});

	}

	window.insertNewStyleHover = function insertNewStyleHover(styleName, value, idElementValue){

		$.ajax({
			url: 'insertNewStyleHover?style='+ styleName +'&value='+ encodeURIComponent(value) +'&element='+ idElementValue,
			type:'GET',
			success: function(data){
			}
		});

	}

	window.removeTransition = function removeTransition(styleName, idElement){

		$.ajax({
			url: 'removeTransition?style='+ styleName + '&id=' + idElement,
			type:'GET',
			success: function(data){
			}
		});

	}

	window.changeRole = function changeRole(mail, role){

		$('#change-role').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');

		$.ajax({
			url: 'changeRole?mail='+ mail + "&role=" + role,
			type:'GET',
			success: function(data){
				$('#change-role').html('<div class=\'flex\' id=\'validate-change-role\'><i class="fas fa-check"></i>Le rôle a bien été modifié</div>');
			}
		});

	}

	$("#form-edit-page-infos").submit(function(event){
		event.preventDefault();
		var name = encodeURIComponent($("#form-edit-page-infos #name").val());
		var slug = encodeURIComponent($("#form-edit-page-infos #slug").val());
		var title = encodeURIComponent($("#form-edit-page-infos #title").val());

		var initialName = encodeURIComponent($("#form-edit-page-infos #name").attr("name"));
		var initialSlug = encodeURIComponent($("#form-edit-page-infos #slug").attr("name"));
	
		var description = encodeURIComponent($("#form-edit-page-infos #description-page-in-db").val());
		$('#display-result-update-page-infos').html('<div class=\'display-loader loader-grey\'><i class=\'fas fa-spinner fa-spin\'></i></div>');

		$.ajax({
			url: 'updatePageInfos?initial_name='+ initialName +'&initial_slug='+ initialSlug +'&name='+ name +'&slug='+ slug +'&title='+ title +'&description='+ description,
			type:'GET',
			success: function(data){
				if(data == "Les informations ont bien été modifiées")
					$('#display-result-update-page-infos').html('<div class=\'flex\' id=\'validate-update-page-infos\'><i class="fas fa-check"></i>'+ data +'</div>');
				else
					$('#display-result-update-page-infos').html('<div class=\'flex\' id=\'error-update-page-infos\'><i class="fas fa-times"></i>'+ data +'</div>');
			}
		});
	});

	window.addElement = function addElement(element, elementName, slug, fileName, path){
		
		$.ajax({
			url: 'addElement?element=' + element + '&element_name=' + encodeURIComponent(elementName) + '&slug=' + slug + '&file_name=' + fileName + '&path=' + path,
			type:'GET',
			success: function(data){
				if(data == "0"){
					$(".display-element-list #display-add-element-status").html("Le nom de l'élément est trop long (maximum autorisé : 100 caractères)");
					setTimeout(function(){
						$(".display-element-list #display-add-element-status").html("");	
					}, 5000);
					return;
				}
				elementName = convertStringToElementName(elementName);
				$('#added-element-current-view').append(data);
				var lastChild = $('#added-element-current-view *').last().attr("id");
				var allElementName = $("#" + lastChild).first().attr("id");
				var idElement = allElementName.split('-');
            	idElement = idElement.slice(-1)[0];
				$("#in-element-list ul").append("<li class='flex'><button class='flex column cta-focus-element-deletable' name='" + allElementName + "' onclick='focusCtaAddedElement(this);' onmouseover='mouseHoverCtaAddedElement(this);' onmouseout='mouseOutCtaAddedElement(this);'><p>" + elementName + "</p><p class='label-info-type-element' >(" + element + ")</p><i class='fas fa-arrow-right padding-arrow-element'></i></button><button class='flex column cta-delete-element' id='delete-element-" + idElement + "' name='" + allElementName + "' value='" + idElement + "' title='Supprimer l&rsquo;élément " + elementName + "' onclick='deleteAddedElement(this);' ><input type='hidden' value='" + element + "' /></button></li>");
			}
		});

	}

	window.getMediasToAdd = function getMediasToAdd(type, isEditMenu = false, isBackground = false){
		$.ajax({
			url: 'getMediasToAdd?type=' + type,
			type:'GET',
			success: function(data){
				createBoxWithMedias(data, isEditMenu, isBackground);
			}
		});
	}

	$("button[id^='delete-element-']").click(function(){
		
		var thisElement = $(this);

		var elementName = thisElement.attr("name");
		var elementId = thisElement.val();
		var ctaDeleteId = thisElement.attr("id");
		var type = $("#" + ctaDeleteId + " input").val();
		var slug = $("#page-slug").val();
		
		$.ajax({
			url: 'deleteElement?element=' + elementId + '&element_name=' + elementName + '&slug=' + slug + '&type=' + type,
			type:'GET',
			success: function(data){
				$('#added-element-current-view').append(data);
				$("#" + elementName).parent().remove();
				$(thisElement.parent()).remove();
			}
		});

	});

	window.deleteAddedElement = function deleteAddedElement(element){
		
		var thisElement = $(element);

		var elementName = thisElement.attr("name");
		var elementId = thisElement.val();
		var ctaDeleteId = thisElement.attr("id");
		var type = $("#" + ctaDeleteId + " input").val();
		var slug = $("#page-slug").val();
		
		$.ajax({
			url: 'deleteElement?element=' + elementId + '&element_name=' + elementName + '&slug=' + slug + '&type=' + type,
			type:'GET',
			success: function(data){
				$("#" + elementName).parent().remove();
				$(thisElement.parent()).remove();
			}
		});

	}

	window.linkField = function linkField(element, idElement, type = null, isVideo = false){

		if(type == null && !isVideo){
			if($("#external-url").attr("checked"))
				type = $("#external-url").val();
			else if($("#internal-url").attr("checked"))
				type = $("#internal-url").val();
		}else if(type == null && isVideo){
			type = "external";
		}else if(type != null){
			if(type == "internal"){
				$("#external-url").removeAttr("checked");
				$("#internal-url").attr("checked", "checked");
			}
			else if(type == "external"){
				$("#internal-url").removeAttr("checked");
				$("#external-url").attr("checked", "checked");
			}

			value = $("#text-edit-link").val();
		}

		var value = $(element).val();
		if(value != ""){
			$.ajax({
				url: 'sendLink?value=' + value + '&element=' + idElement + '&type=' + type,
				type:'GET',
				success: function(data){
					if(data == "true"){
						$(".link-input").css({"border":"1px solid #00E600", "border-radius":"5px"});
						$("#response-link-field").html("");
					}else{
						$(".link-input").css({"border":"1px solid #F90000", "border-radius":"5px"});
						$("#response-link-field").html("L'url n'est pas valide");
					}
				}
			});
		}else{
			$(".link-input").css({"border":"1px solid #F90000", "border-radius":"5px"});
			$("#response-link-field").html("Ce champ ne peut pas être vide.");
		}

	}

	/// bloc note /////
	$("#menu-cta-notes, #dashboard-access-notes").click(function(){
		
		$.ajax({
			url: 'getNotes',
			type:'GET',
			success: function(data){
				openNotes(data);
				CKEDITOR.instances.textFieldNotes.setData(data);
			}
		});
	});

	window.saveNotes = function saveNotes(text){
		
		if(typeof t !== "undefined")
			clearTimeout(t);

		$.ajax({
			url: 'saveNotes?text=' + encodeURIComponent(text),
			type:'GET',
			success: function(data){
				$("#display-notes-save-status").html(data);
				var t = setTimeout(function(){
					$("#display-notes-save-status").html("");
				}, 4000);
			}
		});

	}

	$("#cta-insert-note").click(function(){
		var title = $("#title-note-dashboard").val();
		var text = $("#text-note-dashboard").val();

		if(typeof t !== "undefined")
			clearTimeout(t);

		if(title != "" || text != ""){
			$.ajax({
				url: 'saveNotes?title=' + encodeURIComponent(title) + '&text=' + encodeURIComponent(text),
				type:'GET',
				success: function(data){
					$("#display-insert-note-status").attr("class", "success");
					$("#display-insert-note-status").html("La note a été enregistrée avec succès");
					$("#title-note-dashboard").val("");
					$("#text-note-dashboard").val("");
					var t = setTimeout(function(){
						$("#display-insert-note-status").html("");
					}, 4000);
				}
			});
		}else{
			$("#display-insert-note-status").attr("class", "fail");
			$("#display-insert-note-status").html("Veuillez renseigner au moins l'un des deux champs");
			var t = setTimeout(function(){
				$("#display-insert-note-status").html("");
			}, 4000);
		}
	});

	$("#select-file").change(function(){
		if (this.files && this.files[0]) {
			var reader = new FileReader();
		
			reader.onload = function(e) {
				$('#media-to-display-to-preview').attr('value', e.target.result);
			}
		
			reader.readAsDataURL(this.files[0]);
		}
	});

	$('#form-input-file').ajaxForm(function(){
		
		$('#display-media-loader').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');

		var form = $("#form-input-file")[0];
		var formData = new FormData(form);

		$.ajax({
			url: 'beforeAddImageOrDwnlVideo',
			data: formData,
			processData: false,
            contentType: false,
			type: 'POST',
			success: function(data){
				var json = JSON.parse(data);
				if(json.hasErrors === 0){
					if(json.type === "image"){
						var mediaInBase64 = $('#media-to-display-to-preview').val();
						$('#display-media-loader').html('');
						$("#display-preview-media").html("<div class='filter-pop-up'>" + json.html + "</div>");
						$(".bloc-display-preview").css("background-image", "url('" + mediaInBase64 + "')");
						$("#media-in-base64").attr("value", mediaInBase64);
					}else if(json.type === "video"){
						$('#display-media-loader').html('');
						$('#display-preview-media').html('');
						$("#display-media-status").html("Le média a été correctement téléchargé");
						$("#display-media-status").attr("class", "success");
						
						$("#new-media-after-insert").prepend("<div id='bloc-media-" + json.newMediaId + "' class='bloc-media bloc-display-media' onmouseover='mediaHover(this);' onmouseout='mediaNotHover(this);'><video autoplay loop muted controls><source src='\/uploads\/medias\/" + json.newFileName + "'/></video><button class='cta-delete-media hidden' data-filename='" + json.newFileName + "' title='Supprimer cette vidéo' onclick='deleteNewMedia(this, event);' ><i class='fas fa-times'></i></button><div class='infos-box-media size-info-box-media hidden'>" + json.fileSize + " <b>Mo</b></div><div type='hidden' value='" + json.newFileName + "' ></div></div>");
						setTimeout(function(){
							$("#display-media-status").html("");
						}, 4000);
					}
				}else{
					$('#display-media-loader').html('');
					$('#display-preview-media').html('');

					var errorHtml = "";
					for(var value in json){
						if(value != "hasErrors")
							errorHtml += "<div class='fail' >" + json[value] + "</div>";
					}

					$("#display-media-status").html(errorHtml);
					$("#display-media-status").attr("class", "fail");
					setTimeout(function(){
						$("#display-media-status").html("");
					}, 4000);
				}
			}
		});
	}); 

	window.addMedia = function addMedia(fileName, fileSize, type, title = null){

		$('#display-media-loader').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\'></i></div>');

		if(title != ""){
			if(type === "image")
				var mediaInBase64 = $("#media-in-base64").val();
			else
				var mediaInBase64 = $('#media-to-display-to-preview').val();
			$.ajax({
				url: 'addMedia',
				type: 'POST',
				data: {
					file_name : fileName,
					file_size : fileSize,
					title : title,
					media : mediaInBase64,
					type : type
				},
				success: function(data){
					if(data !== 0){
						var json = JSON.parse(data);
						$('#display-media-loader').html('');
						$('#display-preview-media').html('');
						$("#display-media-status").html("Le média a été correctement téléchargé");
						$("#display-media-status").attr("class", "success");
						$("#new-media-after-insert").prepend("<div id='bloc-media-" + json.newMediaId + "' class='bloc-media bloc-display-media' onmouseover='mediaHover(this);' onmouseout='mediaNotHover(this);' onclick='showFullScreenMedia(this);'><div id='show-full-media-" + json.newMediaId + "' class='background-media' style='background-image: url(\/uploads\/medias\/" + json.newFileName + ");'></div><button class='cta-delete-media hidden' data-filename='" + json.newFileName + "' title='Supprimer cette image' onclick='deleteNewMedia(this, event);' ><i class='fas fa-times'></i></button><div class='infos-box-media size-info-box-media hidden'>" + json.fileSize + " <b>Mo</b></div><div class='infos-box-media title-info-box-media hidden'>" + json.fileTitle + "</div><div type='hidden' value='" + json.newFileName + "' ></div></div>");
						setTimeout(function(){
							$("#display-media-status").html("");
						}, 4000);
					}else{
						$('#display-media-loader').html('');
						$('#display-preview-media').html('');
						$("#display-media-status").html("Une erreur est survenue");
						$("#display-media-status").attr("class", "fail");
						setTimeout(function(){
							$("#display-media-status").html("");
						}, 4000);
					}
				}
			});
		}else{
			$("#text-field-preview-media").css("border", "1px solid #F90000");
			$("#error-title-preview-media").html("Ce champ ne peut pas être vide");
		}

	}

	window.deleteMedia = function deleteMedia(fileName, path, mediaBoxId){

		$.ajax({
			url: 'deleteMedia?file_name=' + fileName + '&path=' + path,
			type:'GET',
			success: function(data){
				$("#" + mediaBoxId).remove();
			}
		});

	}

	window.updateMediaInEdition = function updateMediaInEdition(idElement, path, fileName, isBackground = false, isUnable = false){

		$.ajax({
			url: 'updateMediaInEdition?file_name=' + fileName + '&path=' + path + '&id_element=' + idElement + '&is_background=' + isBackground + '&is_unable=' + isUnable,
			type:'GET',
			success: function(data){
			}
		});
	}

	window.acceptNotif = function acceptNotif(type, element, slug = null, mail = null, key = null){

		if(type === ASK_NEW_ADMIN_NOTIFICATION_TYPE){
			$.ajax({
				url: '/zz-send_autorised_sign_up?u=' + mail + '&k=' + key + '&notif=' + true,
				type:'GET',
				success: function(data){
					$(element).parent().parent().remove();
				}
			});
		}else if(type === NEW_ANNOUNCE_NOTIFICATION_TYPE){
			$.ajax({
				url: 'activateAnnounce?announce=' + slug + '&notif=' + true,
				type:'GET',
				success: function(data){
					$(element).parent().parent().remove();
				}
			});
		}

	}

	window.declineNotif = function declineNotif(type, element, slug = null, mail = null, key = null){

		if(type === ASK_NEW_ADMIN_NOTIFICATION_TYPE){
			$.ajax({
				url: '/zz-refused_sign_up?u=' + mail + '&k=' + key + '&notif=' + true,
				type:'GET',
				success: function(data){
					$(element).parent().parent().remove();
				}
			});
		}else if(type === NEW_ANNOUNCE_NOTIFICATION_TYPE){
			$.ajax({
				url: 'desactivateAnnounce?announce=' + slug + '&notif=' + true,
				type:'GET',
				success: function(data){
					$(element).parent().parent().remove();
				}
			});
		}

	}

	$("#accept-all-announces").click(function(){

		$.ajax({
			url: 'activateAnnounce?notif=' + true + '&all=' + true,
			type:'GET',
			success: function(data){
				$('*[id^="is-new-announce-"]').each(function () {
					$(this).remove();
				});
			}
		});

	});
});