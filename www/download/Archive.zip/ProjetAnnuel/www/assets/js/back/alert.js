function alertMessage(message, redirect = ""){

	$("body").css('overflow-y','hidden');

	var alertBox = "";

	alertBox  +=  "<div class=\"alert_message\">"; 
	alertBox  +=  "<p>"+message+"</p>"; 
	alertBox  +=  "</div>";

	$("body").append('<div id="alert_box" class="alert_box" ></div>');
	var Alertpanel = document.getElementById("alert_box"); // On selection le div alertPanel deja présent dans la page (mais vide)
	Alertpanel.innerHTML = alertBox; // On le remplit de notre div
	Alertpanel.focus(); // On lui donne le focus

	$("#alert_box").click(function(){
		closeAlert(redirect);
	});
}

function alertErrorMessage(message, redirect = ""){

	$("body").css('overflow-y','hidden');

	var alertBox = "";

	alertBox  +=  "<div class=\"alert_error_message\">"; 
	alertBox  +=  "<p>"+message+"</p>"; 
	alertBox  +=  "</div>";

	$("body").append('<div id="alert_box" class="alert_box" ></div>');
	var Alertpanel = document.getElementById("alert_box"); // On selection le div alertPanel deja présent dans la page (mais vide)
	Alertpanel.innerHTML = alertBox; // On le remplit de notre div
	Alertpanel.focus(); // On lui donne le focus

	$("#alert_box").click(function(){
		closeAlert(redirect);
	});
}

function alertChoiceMessage(message, firstChoice, secondChoice, actionAfterClick, redirect = "", param = null){

	$("body").css('overflow-y','hidden');

	var alertBox = "";

	alertBox  +=  "<div class=\"alert_message flex column\">"; 
	alertBox  +=  "<p>"+message+"</p>"; 
	alertBox  +=  "<div class='flex space-around'>";
	alertBox  +=  "<input type='button' value='"+ firstChoice +"' id='first-choice-alert' class='cta-alert-choice'/>";
	alertBox  +=  "<input type='button' value='"+ secondChoice +"' id='second-choice-alert' class='cta-alert-choice'/>";
	alertBox  +=  "</div>";
	alertBox  +=  "</div>";

	$("body").append('<div id="alert_box" class="alert_choice_box" ></div>');
	var Alertpanel = document.getElementById("alert_box"); // On selection le div alertPanel deja présent dans la page (mais vide)
	Alertpanel.innerHTML = alertBox; // On le remplit de notre div
	Alertpanel.focus(); // On lui donne le focus

	$("#first-choice-alert").click(function(){
		afterAlertChoiceFunctions[actionAfterClick](param);
		closeAlert(redirect);
	});

	$("#second-choice-alert").click(function(){
		closeAlert(redirect);
	});
	
}

function alertInputFieldMessage(message, firstChoice, secondChoice, actionAfterClick, redirect = "", param = null){

	$("body").css('overflow-y','hidden');

	var alertBox = "";

	alertBox  +=  "<div class=\"alert_message flex column\">"; 
	alertBox  +=  "<p>"+message+"</p>"; 
	alertBox  +=  "<input type='text' id='input-element-name' class='text-input-field-alert' />"; 

	if(param === "video" || param === "image"){
		if(param === "video"){
			alertBox  +=  "<input type='button' id='cta-choose-video' class='cta-choose-media' value='Choisir une vidéo' onclick='chooseMedia(\"video\");' />";
			alertBox  +=  "<div id='display-media-list' class='flex hidden'></div>";
			alertBox  +=  "<div id='display-selected-media' class='flex'></div>";
		}else if(param === "image"){
			alertBox  +=  "<input type='button' id='cta-choose-image' class='cta-choose-media' value='Choisir une image' onclick='chooseMedia(\"image\");'/>";
			alertBox  +=  "<div id='display-media-list' class='flex hidden'></div>";
			alertBox  +=  "<div id='display-selected-media' class='flex'></div>";
		}
	}

	alertBox  +=  "<div class='flex space-around'>";
	alertBox  +=  "<input type='button' value='"+ firstChoice +"' id='first-choice-alert' class='cta-alert-choice'/>";
	alertBox  +=  "<input type='button' value='"+ secondChoice +"' id='second-choice-alert' class='cta-alert-choice'/>";
	alertBox  +=  "</div>";
	alertBox  +=  "</div>";

	$("#display-alert-add-element").html('<div id="alert_box" class="alert_choice_box" ></div>');
	var Alertpanel = document.getElementById("alert_box"); // On selection le div alertPanel deja présent dans la page (mais vide)
	Alertpanel.innerHTML = alertBox; // On le remplit de notre div
	Alertpanel.focus(); // On lui donne le focus

	$("#first-choice-alert").click(function(){
		var elementName = $("#input-element-name").val();
		
		if(param === "video" || param === "image"){
			var fileName = $(".selected-media").attr("data-filename");
			var path = $(".selected-media").attr("data-path");
		}else{
			var fileName = null;
			var path = null;
		}

		if(elementName == "")
			elementName = "added element";
		afterAlertChoiceFunctions[actionAfterClick](param, elementName, fileName, path);
		closeAlert(redirect);
	});

	$("#second-choice-alert").click(function(){
		closeAlert(redirect);
	});
	
}

window.closeAlert = function closeAlert(redirect){

	$("#alert_box").remove();
	$("body").css('overflow-y','visible');

	if(redirect != ""){
		window.location = redirect;
	}

}

function openNotes(){

	$("body").css('overflow-y','hidden');

	var contain = "<div class='filter-pop-up filter-pop-up-notes'>";
	contain += "<div id='close-notes'><i class='fas fa-times'></i></div>";
	contain += "<div id='bloc-notes' class='flex column'>";
	contain += "<div id='bloc-notes-top'><h1>Bloc-notes</h1></div>";
	contain += "<textarea id='textFieldNotes' name='textFieldNotes' ></textarea>";
	contain += "<script>CKEDITOR.replace( 'textFieldNotes', {toolbar: [[ 'Bold', 'Italic', '-', 'NumberedList', 'BulletedList', '-' ],[ 'FontSize', 'TextColor', 'BGColor' ]]});</script>";
	contain += "<div id='bloc-action-notes' class='flex'>";
	contain += "<input type='button' id='cta-save-notes' value='Sauvegarder'/>";
	contain += "<input type='button' id='cta-cancel-notes' value='Annuler'/>";
	contain += "</div>";
	contain += "<div id='display-notes-save-status'></div>";
	contain += "</div></div>";

	$("#display-bloc-notes").html(contain);

	$("#close-notes").click(function(){
		closeNotes();
	});

	$("#cta-save-notes").click(function(){
		saveNotes(CKEDITOR.instances.textFieldNotes.getData());
	});

	$("#cta-cancel-notes").click(function(){
		closeNotes();
	});

}

function closeNotes(){
	$("body").css('overflow-y','auto');
	$("#display-bloc-notes").html("");
}