$(document).ready(function () {

    $('#close-editable-styles-menu').click(function () {
        $('.sidebar-menu-element-edit').removeClass("show-menu");
        $('.sidebar-menu-element-edit').addClass("hidden-menu");
    });

    window.changeStyleStatut = function changeStyleStatut(element, elementFocus, idElement) {

        if ($(element).attr('id') == "enable-disable-checkbox-colors-" + elementFocus + "-" + idElement)
            var parent = $(element).parent().parent().attr('id');
        else if ($(element).attr('id') == "enable-disable-checkbox-borders-" + elementFocus + "-" + idElement)
            var parent = $(element).parent().parent().parent().attr('id');
        else if ($(element).attr('id') == "enable-disable-checkbox-text-" + elementFocus + "-" + idElement)
            var parent = $(element).parent().parent().attr('id');
        else if ($(element).attr('id') == "enable-disable-checkbox-shadow-" + elementFocus + "-" + idElement)
            var parent = $(element).parent().parent().parent().attr('id');
        else if ($(element).attr('id') == "enable-disable-checkbox-background-" + elementFocus + "-" + idElement)
            var parent = $(element).parent().parent().attr('id');
        else if (elementFocus == "colorHover" || elementFocus == "backgroundColorHover" || elementFocus == "shadowHover" || elementFocus == "borderHover")
            var parent = $(element).parent().parent().attr('id');
        else if (elementFocus == "contenu")
            var parent = $(element).parent().parent().attr('id');

        if ($('#' + $(element).attr('id')).is(':checked')) {

            if ($(element).attr('id') == "enable-disable-checkbox-colors-" + elementFocus + "-" + idElement) {
                $('#' + parent + ' .style-value-input, #' + parent + ' .put-styles-cta').removeAttr('disabled');

                var value = $('#' + parent + ' .style-value-input, #' + parent + ' .put-styles-cta').val();

                $('*[id^="element-"]').each(function () {
                    var ids = this.id;

                    if (ids.endsWith(idElement)) {
                        var elementSelected = this.id;

                        if (elementFocus == "color"){
                            $("#" + elementSelected).css("color", value);
                            $("#enable-disable-checkbox-colors-color-" + idElement).attr("checked", "checked");
                            $("#editable-style-color-" + idElement + " input").attr("value", value);
                        }else if (elementFocus == "background-color"){
                            $("#" + elementSelected).css("background-color", value);
                            $("#enable-disable-checkbox-colors-background-color-" + idElement).attr("checked", "checked");
                            $("#editable-style-background-color-" + idElement + " input").attr("value", value);
                        }

                        value = value.replace("#", "");

                        insertNewStyle(elementFocus, value, idElement);
                    }
                });

            } else if ($(element).attr('id') == "enable-disable-checkbox-borders-" + elementFocus + "-" + idElement) {
                if (elementFocus == "border-radius" || elementFocus == "border-top-left-radius" || elementFocus == "border-bottom-left-radius" ||
                    elementFocus == "border-top-right-radius" || elementFocus == "border-bottom-right-radius") {
                    $('#' + parent + ' div .style-value-input').removeAttr('disabled');
                    var radiusValue = $('#' + parent + ' div .style-value-input').val();

                    $('*[id^="element-"]').each(function () {
                        var ids = this.id;

                        if (ids.endsWith(idElement)) {
                            var elementSelected = this.id;

                            changeBorderStyleRadiusInLive(elementFocus, radiusValue + "px", elementSelected);
                            changeBorder(null, radiusValue, idElement, elementFocus);
                        }
                    });

                } else {
                    var borderOptions = $('#' + parent + ' .main-border-options').removeClass('hidden');
                    changeBorder(borderOptions, null, idElement, elementFocus);
                }
            } else if ($(element).attr('id') == "enable-disable-checkbox-text-" + elementFocus + "-" + idElement) {
                var textField = $('#' + parent + ' .style-value-input').removeAttr('disabled');
                var value = textField.val();
                if (elementFocus == "contenu")
                    changeTextContain(value, idElement);
                else if (elementFocus == "placeholder")
                    changePlaceholderContain(value, idElement);
                else if (elementFocus == "font-size")
                    changeFontSize(value, idElement);

            } else if ($(element).attr('id') == "enable-disable-checkbox-shadow-" + elementFocus + "-" + idElement) {
                $('#' + parent + ' .main-shadow-options').removeClass('hidden');
                changeShadow(element, null, idElement, "box-shadow");

            } else if ($(element).attr('id') == "enable-disable-checkbox-background-" + elementFocus + "-" + idElement) {
                $("#editable-style-" + elementFocus + "-" + idElement + " #box-edit-media-edit-menu-background input").removeAttr("disabled");

            } else if (elementFocus == "colorHover" || elementFocus == "backgroundColorHover" || elementFocus == "shadowHover" || elementFocus == "borderHover") {
                $('#' + parent + ' .bloc-edit-hover-item').removeClass('hidden');

                if (elementFocus == "colorHover") {
                    var colorHoverValue = $('#' + parent + ' .bloc-edit-hover-item div input').val();
                    var timeValue = $('#' + parent + ' .bloc-edit-hover-item div div input').val();
                    changeColorHover(colorHoverValue, idElement);
                    changeTransitionTime(timeValue, idElement, "color");
                } else if (elementFocus == "backgroundColorHover") {
                    var colorHoverValue = $('#' + parent + ' .bloc-edit-hover-item div input').val();
                    var timeValue = $('#' + parent + ' .bloc-edit-hover-item div div input').val();
                    changeBackgroundColorHover(colorHoverValue, idElement);
                    changeTransitionTime(timeValue, idElement, "background-color");
                }else if (elementFocus == "shadowHover") {
                    var colorHoverValue = $('#' + parent + ' .bloc-edit-hover-item div input').val();
                    var timeValue = $('#' + parent + ' .bloc-edit-hover-item div div input').val();
                    changeShadowHover(element, null, idElement, null);
                    changeTransitionTime(timeValue, idElement, "box-shadow");
                }else if (elementFocus == "borderHover") {
                    var colorHoverValue = $('#' + parent + ' .bloc-edit-hover-item div input').val();
                    var timeValue = $('#' + parent + ' .bloc-edit-hover-item div div input').val();
                    changeBorderHover(element, null, idElement, null);
                    changeTransitionTime(timeValue, idElement, "border");
                }
            }

        } else {
            if ($(element).attr('id') == "enable-disable-checkbox-colors-" + elementFocus + "-" + idElement) {
                $('#' + parent + ' .style-value-input, #' + parent + ' .put-styles-cta').prop('disabled', true);

                $('*[id^="element-"]').each(function () {
                    var ids = this.id;

                    if (ids.endsWith(idElement)) {
                        var elementSelected = this.id;

                        if (elementFocus == "color") {
                            $("#" + elementSelected).css("color", "#000000");
                            $("#editable-style-color-" + idElement + " input").attr("value", "#000000");
                            $("#enable-disable-checkbox-colors-color-" + idElement).removeAttr("checked");
                            var color = "";
                        } else if (elementFocus == "background-color") {
                            $("#" + elementSelected).css("background-color", "transparent");
                            $("#editable-style-background-color-" + idElement + " input").attr("value", "");
                            $("#enable-disable-checkbox-colors-background-color-" + idElement).removeAttr("checked");
                            var color = "";
                        }

                        insertNewStyle(elementFocus, color, idElement);
                    }
                });

            } else if ($(element).attr('id') == "enable-disable-checkbox-borders-" + elementFocus + "-" + idElement) {
                if (elementFocus == "border-radius" || elementFocus == "border-top-left-radius" || elementFocus == "border-bottom-left-radius" ||
                    elementFocus == "border-top-right-radius" || elementFocus == "border-bottom-right-radius") {
                    $('#' + parent + ' div .style-value-input').prop('disabled', true);

                    $('*[id^="element-"]').each(function () {
                        var ids = this.id;

                        if (ids.endsWith(idElement)) {
                            var elementSelected = this.id;

                            changeBorderStyleRadiusInLive(elementFocus, "0px", elementSelected);
                            var value = "";

                            insertNewStyle(elementFocus, value, idElement);
                        }
                    });

                } else {
                    $('#' + parent + ' .main-border-options').addClass('hidden');

                    $('*[id^="element-"]').each(function () {
                        var ids = this.id;

                        if (ids.endsWith(idElement)) {
                            var elementSelected = this.id;

                            changeBorderStyleInLive(elementFocus, elementSelected, "none");
                            var value = "";

                            insertNewStyle(elementFocus, value, idElement);
                        }
                    });

                }

            } else if ($(element).attr('id') == "enable-disable-checkbox-text-" + elementFocus + "-" + idElement) {
                $('#' + parent + ' .style-value-input').prop('disabled', true);
                if (elementFocus == "contenu")
                    changeTextContain("", idElement);
                else if (elementFocus == "placeholder")
                    changePlaceholderContain("", idElement);
                else if (elementFocus == "font-size")
                    changeFontSize("16", idElement);

            } else if ($(element).attr('id') == "enable-disable-checkbox-shadow-" + elementFocus + "-" + idElement) {
                $('#' + parent + ' .main-shadow-options').addClass('hidden');

                $('*[id^="element-"]').each(function () {
                    var ids = this.id;

                    if (ids.endsWith(idElement)) {
                        var elementSelected = this.id;

                        changeShadowStyleInLive(elementFocus, elementSelected, "none");
                        var value = "";

                        insertNewStyle(elementFocus, value, idElement);
                    }
                });

            } else if ($(element).attr('id') == "enable-disable-checkbox-background-" + elementFocus + "-" + idElement) {
                $("#editable-style-" + elementFocus + "-" + idElement + " #box-edit-media-edit-menu-background input").prop("disabled", true);
                $("#preview-image-edit-menu-background").addClass("hidden");
                $("#label-selected-image-background").addClass("hidden");
                changeMediaView(idElement, null, null, true, true);

            } else if (elementFocus == "colorHover" || elementFocus == "backgroundColorHover" || elementFocus == "shadowHover" || elementFocus == "borderHover") {
                $('#' + parent + ' .bloc-edit-hover-item').addClass('hidden');

                if (elementFocus == "colorHover") {
                    changeColorHover("", idElement);
                    removeTransition("color", idElement);
                } else if (elementFocus == "backgroundColorHover") {
                    changeBackgroundColorHover("", idElement);
                    removeTransition("background-color", idElement);
                }else if (elementFocus == "shadowHover") {
                    changeShadowHover(elementFocus, "", idElement, null);
                    removeTransition("box-shadow", idElement);
                }else if (elementFocus == "borderHover") {
                    changeBorderHover(elementFocus, "", idElement, null);
                    removeTransition("border", idElement);
                }
            }
        }
    }

    window.changeColor = function changeColor(colorValue, idElement, style) {

        var valueStyle = colorValue;
        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                if (style == "color") {
                    $("#" + elementSelected).css("color", colorValue);
                    $("#editable-style-color-" + idElement + " input").attr("value", valueStyle);
                    var styleName = "color";
                } else if (style == "background-color") {
                    $("#" + elementSelected).css("background-color", colorValue);
                    $("#editable-style-background-color-" + idElement + " input").attr("value", valueStyle);
                    var styleName = "background-color";
                }

                valueStyle = valueStyle.replace("#", "");

                insertNewStyle(styleName, valueStyle, idElementValue);
            }
        });
    }

    function getBorderSizeValue(parent) {

        return $("#" + parent + " .border-size input").val();
    }

    function getBorderTypeValue(parent) {

        var value = "";

        $("#" + parent + " .border-types").children().each(function () {
            if ($(this).attr("id")) {
                if ($("#" + this.id + " input[type='radio']").is(':checked'))
                    value = $(this).children().val();
            }
        });

        return value;
    }

    function getBorderColorValue(parent) {

        return $("#" + parent + " .color-picker-border label input").val();
    }

    function changeBorderStyleInLive(style, elementSelected, styleAsCSS) {

        switch (style) {
            case "border":
                $("#" + elementSelected).css("border", styleAsCSS);
                break;
            case "border-top":
                $("#" + elementSelected).css("border-top", styleAsCSS);
                break;
            case "border-bottom":
                $("#" + elementSelected).css("border-bottom", styleAsCSS);
                break;
            case "border-left":
                $("#" + elementSelected).css("border-left", styleAsCSS);
                break;
            case "border-right":
                $("#" + elementSelected).css("border-right", styleAsCSS);
                break;
        }

    }

    function changeBorderStyleRadiusInLive(style, radius, elementSelected) {

        $("#" + elementSelected).css(style, radius);

    }

    function targetKindOfBorder(style, value, elementFocus, part, elementSelected = null) {

        if (style == "border" ||
            style == "border-top" ||
            style == "border-bottom" ||
            style == "border-left" ||
            style == "border-right") {

            if (part == "size") {
                var parent = $(elementFocus).parent().parent().attr("id");
                var type = getBorderTypeValue(parent);
                var color = getBorderColorValue(parent);

                var styleAsCSS = value + "px " + type + " " + color;

                return styleAsCSS;

            } else if (part == "type") {
                var parent = $(elementFocus).parent().parent().parent().attr("id");
                var size = getBorderSizeValue(parent);
                var color = getBorderColorValue(parent);

                var styleAsCSS = size + "px " + value + " " + color;

                return styleAsCSS;

            } else if (part == "color") {
                var parent = $(elementFocus).parent().parent().parent().attr("id");
                var size = getBorderSizeValue(parent);
                var type = getBorderTypeValue(parent);

                var styleAsCSS = size + "px " + type + " " + value;

                return styleAsCSS;

            } else if (part == null && value == null) {
                var parent = $(elementFocus).attr("id");
                var size = getBorderSizeValue(parent);
                var type = getBorderTypeValue(parent);
                var color = getBorderColorValue(parent);

                var styleAsCSS = size + "px " + type + " " + color;

                return styleAsCSS;
            }

            styleAsCSS = styleAsCSS.replace("#", "*");

        } else if (style == "border-radius" ||
            style == "border-top-left-radius" ||
            style == "border-bottom-left-radius" ||
            style == "border-top-right-radius" ||
            style == "border-bottom-right-radius") {

            var styleAsCSS = value + "px";

            changeBorderStyleRadiusInLive(style, styleAsCSS, elementSelected)
            return styleAsCSS;
        }

    }

    window.changeBorder = function changeBorder(elementFocus, value, idElement, style, part = null) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                var styleAsCSS = targetKindOfBorder(style, value, elementFocus, part, elementSelected);

                changeBorderStyleInLive(style, elementSelected, styleAsCSS);

                insertNewStyle(style, styleAsCSS, idElementValue);

            }
        });
    }

    window.selectTextAlign = function selectTextAlign(elementFocus, value, idElement) {

        var parent = $(elementFocus).parent().attr('id');

        if (value == "left") {
            $('#' + parent + ' #text-align-left').css('color', '#6B6FD8');
            $('#' + parent + ' #text-align-center').css('color', '#353B48');
            $('#' + parent + ' #text-align-right').css('color', '#353B48');
            $('#' + parent + ' #text-align-justify').css('color', '#353B48');
        } else if (value == "center") {
            $('#' + parent + ' #text-align-left').css('color', '#353B48');
            $('#' + parent + ' #text-align-center').css('color', '#6B6FD8');
            $('#' + parent + ' #text-align-right').css('color', '#353B48');
            $('#' + parent + ' #text-align-justify').css('color', '#353B48');
        } else if (value == "right") {
            $('#' + parent + ' #text-align-left').css('color', '#353B48');
            $('#' + parent + ' #text-align-center').css('color', '#353B48');
            $('#' + parent + ' #text-align-right').css('color', '#6B6FD8');
            $('#' + parent + ' #text-align-justify').css('color', '#353B48');
        } else if (value == "justify") {
            $('#' + parent + ' #text-align-left').css('color', '#353B48');
            $('#' + parent + ' #text-align-center').css('color', '#353B48');
            $('#' + parent + ' #text-align-right').css('color', '#353B48');
            $('#' + parent + ' #text-align-justify').css('color', '#6B6FD8');
        }

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                $("#" + elementSelected).css("text-align", value);

                insertNewStyle("text-align", value, idElementValue);
            }
        });

    }

    window.changeTextContain = function changeTextContain(value, idElement) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                insertNewStyle("contenu", value, idElementValue, elementSelected);
            }
        });

    }

    window.changePlaceholderContain = function changePaceholderContain(value, idElement) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                insertNewStyle("placeholder", value, idElementValue, elementSelected);
            }
        });

    }

    window.changeFontFamily = function changeFontFamily(value, idElement) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                $("#" + elementSelected).css("font-family", value);

                insertNewStyle("font-family", value, idElementValue, elementSelected);
            }
        });

    }

    window.changeFontSize = function changeFontSize(value, idElement) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                $("#" + elementSelected).css("font-size", value + "px");

                insertNewStyle("font-size", value + "px", idElementValue, elementSelected);
            }
        });

    }

    function getShadowXAxis(parent) {

        var value = "";

        $("#" + parent).children().each(function () {
            var children = $(this).children();
            children.each(function () {
                var id = this.id;
                if (id.startsWith("xaxis"))
                    value = this.value;
            });
        });

        return value;
    }

    function getShadowYAxis(parent) {

        var value = "";

        $("#" + parent).children().each(function () {
            var children = $(this).children();
            children.each(function () {
                var id = this.id;
                if (id.startsWith("yaxis"))
                    value = this.value;
            });
        });

        return value;
    }

    function getShadowBlur(parent) {

        var value = "";

        $("#" + parent).children().each(function () {
            var children = $(this).children();
            children.each(function () {
                var id = this.id;
                if (id.startsWith("blur"))
                    value = this.value;
            });
        });

        return value;
    }

    function getShadowSpread(parent) {

        var value = "";

        $("#" + parent).children().each(function () {
            var children = $(this).children();
            children.each(function () {
                var id = this.id;
                if (id.startsWith("spread"))
                    value = this.value;
            });
        });

        return value;
    }

    function getShadowColor(parent) {

        var value = "";

        $("#" + parent).children().each(function () {
            var children = $(this).children();
            children.each(function () {
                var id = this.id;
                if (id.startsWith("color"))
                    value = this.value;
            });
        });

        return value;
    }

    function shadowInset(parent) {

        var isInset = false;

        $("#" + parent).children().each(function () {
            var children = $(this).children();
            children.each(function () {
                var id = this.id;
                if (id.startsWith("inset")) {
                    if ($(this).is(':checked'))
                        isInset = true
                }
            });
        });

        return isInset;
    }

    function changeShadowStyleInLive(style, elementSelected, styleAsCSS) {

        $("#" + elementSelected).css(style, styleAsCSS);

    }

    function targetPart(parent, style, value, elementFocus, part) {

        if (part == "xAxis") {
            var yAxis = getShadowYAxis(parent);
            var blur = getShadowBlur(parent);
            var spread = getShadowSpread(parent);
            var color = getShadowColor(parent);

            if (shadowInset(parent))
                var inset = "inset";
            else
                var inset = "";

            var styleAsCSS = value + "px " + yAxis + "px " + blur + "px " + spread + "px " + color + " " + inset;

            return styleAsCSS;

        } else if (part == "yAxis") {
            var xAxis = getShadowXAxis(parent);
            var blur = getShadowBlur(parent);
            var spread = getShadowSpread(parent);
            var color = getShadowColor(parent);

            if (shadowInset(parent))
                inset = "inset";
            else
                inset = "";

            var styleAsCSS = xAxis + "px " + value + "px " + blur + "px " + spread + "px " + color + " " + inset;

            return styleAsCSS;

        } else if (part == "blur") {
            var yAxis = getShadowYAxis(parent);
            var xAxis = getShadowXAxis(parent);
            var spread = getShadowSpread(parent);
            var color = getShadowColor(parent);

            if (shadowInset(parent))
                inset = "inset";
            else
                inset = "";

            var styleAsCSS = xAxis + "px " + yAxis + "px " + value + "px " + spread + "px " + color + " " + inset;

            return styleAsCSS;

        } else if (part == "spread") {
            var yAxis = getShadowYAxis(parent);
            var blur = getShadowBlur(parent);
            var xAxis = getShadowXAxis(parent);
            var color = getShadowColor(parent);

            if (shadowInset(parent))
                inset = "inset";
            else
                inset = "";

            var styleAsCSS = xAxis + "px " + yAxis + "px " + blur + "px " + value + "px " + color + " " + inset;

            return styleAsCSS;

        } else if (part == "inset") {
            var yAxis = getShadowYAxis(parent);
            var blur = getShadowBlur(parent);
            var spread = getShadowSpread(parent);
            var xAxis = getShadowXAxis(parent);
            var color = getShadowColor(parent);

            if (shadowInset(parent))
                inset = "inset";
            else
                inset = "";

            var styleAsCSS = xAxis + "px " + yAxis + "px " + blur + "px " + spread + "px " + color + " " + inset;

            return styleAsCSS;

        } else if (part == "color") {
            var yAxis = getShadowYAxis(parent);
            var blur = getShadowBlur(parent);
            var spread = getShadowSpread(parent);
            var xAxis = getShadowXAxis(parent);

            if (shadowInset(parent))
                inset = "inset";
            else
                inset = "";

            var styleAsCSS = xAxis + "px " + yAxis + "px " + blur + "px " + spread + "px " + value + " " + inset;

            return styleAsCSS;

        } else if (part == null && value == null) {
            var parent = $(elementFocus).parent().parent().parent().attr("id");
            parent = $("#" + parent + " .shadow-types").attr("id");
            var yAxis = getShadowYAxis(parent);
            var xAxis = getShadowXAxis(parent);
            var blur = getShadowBlur(parent);
            var spread = getShadowSpread(parent);
            var color = getShadowColor(parent);

            if (shadowInset(parent))
                inset = "inset";
            else
                inset = "";

            var styleAsCSS = xAxis + "px " + yAxis + "px " + blur + "px " + spread + "px " + color + " " + inset;

            return styleAsCSS;

        }

    }

    window.changeShadow = function changeShadow(elementFocus, value, idElement, style, part = null) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                var parent = $(elementFocus).parent().parent().attr("id");
                var styleAsCSS = targetPart(parent, style, value, elementFocus, part);
                changeShadowStyleInLive(style, elementSelected, styleAsCSS);

                styleAsCSS = styleAsCSS.replace("#", "*");

                insertNewStyle("box-shadow", styleAsCSS, idElementValue, elementSelected);

            }
        });
    }

    function changeTransitionTimeInLive(elementSelected, value) {

        if ($("#" + elementSelected).attr("style")) {
            var styleAttribute = $("#" + elementSelected).attr("style");
            var splitedStyleAttribute = styleAttribute.split("transition:");

            if (splitedStyleAttribute[1] != undefined) {
                splitedStyleAttribute = splitedStyleAttribute[1];
                var transitionStyle = splitedStyleAttribute.split(";");
                transitionStyle = transitionStyle[0];
                var initialTransitionStyle = transitionStyle.split(",");
                var newTransitionStyleName = value.split(" ");
                newTransitionStyleName = newTransitionStyleName[0];

                initialTransitionStyle.forEach(function (element) {
                    var initialTransitionStyleElement = element.split(" ");
                    initialTransitionStyleName = initialTransitionStyleElement[1];
                    initialTransitionTime = initialTransitionStyleElement[2];

                    if (initialTransitionStyleName == newTransitionStyleName) {
                        for (var i = 0; i < initialTransitionStyle.length; i++) {
                            if (initialTransitionStyle[i] == " " + initialTransitionStyleName + " " + initialTransitionTime + " ease 0s") {
                                initialTransitionStyle.splice(i, 1);
                                i++;
                            }
                        }
                    }
                });

                initialTransitionStyle.push(value);
                var finalTransitionStyles = initialTransitionStyle.join(", ");
                var newTransitionStyle = finalTransitionStyles;
                $("#" + elementSelected).css("transition", newTransitionStyle);

            } else {
                $("#" + elementSelected).css("transition", value);
            }
        } else {
            $("#" + elementSelected).css("transition", value);
        }

    }

    window.changeTransitionTime = function changeTransitionTime(timeValue, idElement, style) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;
                var value = style + " " + timeValue + "s";

                changeTransitionTimeInLive(elementSelected, value);
                insertNewStyle("transition", value, idElementValue);
            }
        });
    }

    window.changeColorHover = function changeColorHover(colorValue, idElement) {

        var valueStyle = colorValue;
        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;
                var colorEdited = $("#editable-style-color-" + idElement + " input").attr("value");
                if (colorValue != "") {
                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("color", colorValue);
                    }, function () {
                        $("#" + elementSelected).css("color", colorEdited);
                    });

                    valueStyle = valueStyle.replace("#", "");
                } else {
                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("color", $("#editable-style-color-" + idElement + " input").val());
                    }, function () {
                        $("#" + elementSelected).css("color", $("#editable-style-color-" + idElement + " input").val());
                    });
                }

                insertNewStyleHover("color", valueStyle, idElementValue);
            }
        });
    }

    window.changeBackgroundColorHover = function changeBackgroundColorHover(colorValue, idElement) {

        var valueStyle = colorValue;
        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;
                var colorEdited = $("#editable-style-background-color-" + idElement + " input").attr("value");
                if (colorValue != "") {
                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("background-color", colorValue);
                    }, function () {
                        if(colorEdited == "")
                            $("#" + elementSelected).css("background-color", "transparent");
                        else
                            $("#" + elementSelected).css("background-color", colorEdited);
                    });

                    valueStyle = valueStyle.replace("#", "");
                } else {
                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("background-color", $("#editable-style-background-color-" + idElement + " input").val());
                    }, function () {
                        $("#" + elementSelected).css("background-color", $("#editable-style-background-color-" + idElement + " input").val());
                    });
                }

                insertNewStyleHover("background-color", valueStyle, idElementValue);
            }
        });
    }

    window.changeShadowHover = function changeShadowHover(elementFocus, value, idElement, style, part = null) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;

                if (value != "") {
                    var parent = $(elementFocus).parent().parent().attr("id");

                    var styleAsCSS = targetPart(parent, style, value, elementSelected, part);

                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("box-shadow", styleAsCSS);
                    }, function () {
                        if ($("#enable-disable-checkbox-shadow-box-shadow-" + idElement).is(":checked"))
                            $("#" + elementSelected).css("box-shadow", targetPart($("#editable-style-box-shadow-" + idElementValue), style, null, $("#enable-disable-checkbox-shadow-box-shadow-" + idElement)));
                        else
                            $("#" + elementSelected).css("box-shadow", "none");
                    });

                    styleAsCSSChanged = styleAsCSS.replace("#", "*");

                } else {

                    var styleAsCSSChanged = "";

                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("box-shadow", $("#" + elementSelected).css("box-shadow"));
                    }, function () {
                        $("#" + elementSelected).css("box-shadow", $("#" + elementSelected).css("box-shadow"));
                    });
                }

                insertNewStyleHover("box-shadow", styleAsCSSChanged, idElementValue);

            }
        });
    }

    window.changeBorderHover = function changeBorderHover(elementFocus, value, idElement, style, part = null) {

        var idElementValue = idElement;

        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;
                var borderValue = targetKindOfBorder("border", null, $("#main-border-options-border-" + idElementValue), null);
                if (value != "") {

                    var styleAsCSS = targetKindOfBorder(style, value, elementFocus, part);

                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("border", styleAsCSS);
                    }, function () {
                        $("#" + elementSelected).css("border", borderValue);
                    });

                } else {

                    var styleAsCSS = "";

                    $("#" + elementSelected).hover(function () {
                        $("#" + elementSelected).css("border", borderValue);
                    }, function () {
                        $("#" + elementSelected).css("border", borderValue);
                    });
                }

                insertNewStyleHover("border", styleAsCSS, idElementValue);

            }
        });
    }

    window.changeMediaView = function changeMediaView(idElement, path, value, isBackground = false, isUnable = false){
        $('*[id^="element-"]').each(function () {
            var ids = this.id;

            if (ids.endsWith(idElement)) {
                var elementSelected = this.id;
                if(!isBackground){
                    $("#" + elementSelected).attr("src", path + value);
                    updateMediaInEdition(idElement, value);
                }else{
                    if(!isUnable){
                        $("#" + elementSelected).css("background-image", "url(" + path + value + ")");
                        $("#preview-image-edit-menu-background").css("background-image", "url(" + path + value + ")");
                    }else{
                        $("#" + elementSelected).css("background-image", "none");
                        $("#preview-image-edit-menu-background").css("none");
                    }
                    updateMediaInEdition(idElement, path, value, isBackground, isUnable);
                }
            }
        });
    }

});