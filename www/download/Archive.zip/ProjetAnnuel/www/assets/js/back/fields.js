$(window).ready(function(){

	labelFocusAnimation();

});

function labelFocusAnimation(){

	$("input[type='text'], input[type='email']").ready(function(){
			var value = $("input[type='text'], input[type='email']").val();
			if(value!=""){
				$("input[type='text'], input[type='email']").parent("div").children("label").attr("class", "label-focus");
			}
		});
		$("input[type='text'], input[type='email'], input[type='password']").focus(function(){
			$(this).parent("div").children("label").attr("class", "label-focus");
		});
		$("input[type='text'], input[type='email'], input[type='password']").focusout(function(){
			$(this).parent("div").children("label").attr("class", "label");

			var value = $(this).val();
			
			if(value!=""){
				$(this).parent("div").children("label").attr("class", "label-focus");
			}
	});

}