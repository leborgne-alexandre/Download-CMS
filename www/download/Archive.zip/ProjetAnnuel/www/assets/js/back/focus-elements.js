$(document).ready(function(){

    $("#close-list-editable-elements-menu").click(function(){
        $(".sidebar-menu-element-list").removeClass("show-menu");
        $(".sidebar-menu-element-list").addClass("hidden-menu");
    });
    $("#open-list-editable-elements-menu").click(function(){
        $(".sidebar-menu-element-list").addClass("show-menu");
        $(".sidebar-menu-element-list").removeClass("hidden-menu");
    });

    $("#in-element-list ul li .cta-focus-element, #in-element-list ul li .cta-focus-element-deletable").hover(function(){
        $('#' + $(this).attr('name')).addClass("hover-element-focus");
    }, function(){
        $('#' + $(this).attr('name')).removeClass("hover-element-focus");
    });

    window.mouseHoverCtaAddedElement = function mouseHoverCtaAddedElement(element){
        $('#' + $(element).attr('name')).addClass("hover-element-focus");
    }

    window.mouseOutCtaAddedElement = function mouseOutCtaAddedElement(element){
        $('#' + $(element).attr('name')).removeClass("hover-element-focus");
    }

    $('#in-element-list ul li .cta-focus-element, #in-element-list ul li .cta-focus-element-deletable').click(function(event){
    
        var attrName = $(event.target).attr("name");

        if(typeof attrName !== typeof undefined && attrName !== false)
            var buttonName = event.target.name;
        else
            var buttonName = $(event.target).parent().attr("name");
        
        var tagIdElement = buttonName;

        if(tagIdElement.startsWith('element-')){

            $('.sidebar-menu-element-edit').addClass('show-menu');

            $('.display-editable-styles').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\' style=\'color: #000000;\'></i></div>');
            
            var idElement = tagIdElement.split('-');
            idElement = idElement.slice(-1)[0];

            getEditableStyles(idElement);
        }
    });

    window.focusCtaAddedElement = function focusCtaAddedElement(element){
    
        var attrName = $(element).attr("name");
        if(typeof attrName !== typeof undefined && attrName !== false)
            var buttonName = $(element).attr("name");
        else
            var buttonName = $(element).parent().attr("name");

        var tagIdElement = buttonName;

        if(tagIdElement.startsWith('element-')){

            $('.sidebar-menu-element-edit').addClass('show-menu');

            $('.display-editable-styles').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\' style=\'color: #000000;\'></i></div>');
            
            var idElement = tagIdElement.split('-');
            idElement = idElement.slice(-1)[0];

            getEditableStyles(idElement);
        }
    }

    $('*[id^="element-"]').mouseover(function(event){
        $(this).addClass("hover-element-focus");
        event.stopPropagation();
    }).mouseout(function(event){
        $(this).removeClass('hover-element-focus');
    });

    window.mouseHoverAddedElement = function mouseHoverAddedElement(element){
        $(element).addClass("hover-element-focus");
    }

    window.mouseOutAddedElement = function mouseOutAddedElement(element){
        $(element).removeClass('hover-element-focus');
    }

    $('.view-website').click(function(event){
        
        var tagIdElement = event.target.id;

        if(tagIdElement.startsWith('element-')){
        
            $('.sidebar-menu-element-edit').addClass('show-menu');

            $('.display-editable-styles').html('<div class=\'display-loader\'><i class=\'fas fa-spinner fa-spin\' style=\'color: #000000;\'></i></div>');
            
            var idElement = tagIdElement.split('-');
            idElement = idElement.slice(-1)[0];

            getEditableStyles(idElement);
        }
    });

});
