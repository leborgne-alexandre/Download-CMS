/*function getAllElementsInPage(){
var node = document.querySelector('.view-website');
	//var node = document.getElementsByClassName('view-website').childNodes;

	var tabNode = Object.keys(node);
	console.log(tabNode);
	tabNode.forEach(function(element){
		alert(element);
	});
	
	var children = node.childNodes;
 
	for(k=0;children.length;k++){
	 if( document.getElementById(children[k].id)){
 
            alert(children[k].id );
 
		  if (document.getElementById(children[k].id).hasChildNodes()){
		  	getIds(children[k].id);
		  }
	 }
	}

}*/
