$(document).ready(function(){

    $(".accept-notification").click(function(){
        if($(this).attr("data-type") === ASK_NEW_ADMIN_NOTIFICATION_TYPE){
            var mail = $(this).attr("data-mail");
            var key = $(this).attr("data-key");
            acceptNotif(ASK_NEW_ADMIN_NOTIFICATION_TYPE, this, null, mail, key);
        }else if($(this).attr("data-type") === NEW_ANNOUNCE_NOTIFICATION_TYPE){
            var slug = $(this).attr("data-slug");
            acceptNotif(NEW_ANNOUNCE_NOTIFICATION_TYPE, this, slug);
        }
    });

    $(".decline-notification").click(function(){
        if($(this).attr("data-type") === ASK_NEW_ADMIN_NOTIFICATION_TYPE){
            var mail = $(this).attr("data-mail");
            var key = $(this).attr("data-key");
            declineNotif(ASK_NEW_ADMIN_NOTIFICATION_TYPE, this, null, mail, key);
        }else if($(this).attr("data-type") === NEW_ANNOUNCE_NOTIFICATION_TYPE){
            var slug = $(this).attr("data-slug");
            declineNotif(NEW_ANNOUNCE_NOTIFICATION_TYPE, this, slug);
        }
    });

});