/*function popProfil(){
	var profil = document.getElementById('popProfil').className;
	var notif = document.getElementById('popNotif').className;
	var message = document.getElementById('popMessage').className;

	if(profil == "" || profil == "hidden"){
		if(notif =="visible" || message == "visible"){
			document.getElementById('popMessage').className = "hidden";
			document.getElementById('popNotif').className = "hidden";
		}
		document.getElementById('popProfil').className = "visible";
	}
	if(profil == "visible"){
		document.getElementById('popProfil').className = "hidden";
	}
}
function popNotif(){
	var notif = document.getElementById('popNotif').className;
	var profil = document.getElementById('popProfil').className;
	var message = document.getElementById('popMessage').className;

	if(notif == "" || notif == "hidden"){
		if(profil =="visible" || message == "visible"){
			document.getElementById('popMessage').className = "hidden";
			document.getElementById('popProfil').className = "hidden";
		}
		document.getElementById('popNotif').className = "visible";
	}
	if(notif == "visible"){
		document.getElementById('popNotif').className = "hidden";
	}
}

function popMessage(){
	var message = document.getElementById('popMessage').className;
	var profil = document.getElementById('popProfil').className;
	var notif =  document.getElementById('popNotif').className;

	if(message == "" || message == "hidden"){
		if(profil =="visible" || notif == "visible"){
			document.getElementById('popNotif').className = "hidden";
			document.getElementById('popProfil').className = "hidden";
		}
		document.getElementById('popMessage').className = "visible";
	}
	if(message == "visible"){
		document.getElementById('popMessage').className = "hidden";
	}
	showMessage()
}

function showMessage(){

	
}*/
$(document).ready(function(){
	isFocus();
});

function isFocus(){
	$("#right-menu-icon-profil").focus(function(){
		$("#popup-profil").removeClass("hidden");
	});
	$("#right-menu-icon-profil").focusout(function(){
		$("#popup-profil").addClass("hidden");
	});

	$("#right-menu-icon-notif").focus(function(){
		$("#popup-notif").removeClass("hidden");
	});
	$("#right-menu-icon-notif").focusout(function(){
		$("#popup-notif").addClass("hidden");
	});

	$("#right-menu-icon-message").focus(function(){
		$("#popup-message").removeClass("hidden");
	});
	$("#right-menu-icon-message").focusout(function(){
		$("#popup-message").addClass("hidden");
	});
}
