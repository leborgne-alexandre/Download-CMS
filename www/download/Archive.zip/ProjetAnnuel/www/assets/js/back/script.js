///////////////
//Constantes///
//////////////
var PATH_DL_MEDIAS = "/uploads/medias/";
var ASK_NEW_ADMIN_NOTIFICATION_TYPE = "ask_new_admin";
var NEW_ANNOUNCE_NOTIFICATION_TYPE = "new_announce";
///////////////
///////////////
//////////////

$(document).ready(function(){
	$("html").attr("class", "js-trigger");
});

$("#leftside-navigation .sub-menu > a").click(function (e) {
  $("#leftside-navigation ul ul").slideUp(), $(this).next().is(":visible") || $(this).next().slideDown(),
    e.stopPropagation()
})

/**** désactiver les actions pour les pages en edition ****/
$(document).ready(function(){
$('.view-website').find('*').removeAttr('action href onclick onsubmit name');
});
/************************/

/***** Details user moderator admin*/
window.closeDetails = function closeDetails(){
	$("#display-details").html("");
}
/*************************************/

/*** CHANGEMENT MENU TABLEAU PAGE-LIST ***/

$(document).ready(function(){
	$("#target-users").click(function(){
		$('.menu-list-user, .display-list-user, .display-search-users').removeClass('hidden');
		$('.menu-list-moderator, .display-list-moderator, .display-search-moderators').addClass('hidden');
		$('.menu-list-admin, .display-list-admin, .display-search-admins').addClass('hidden');
		$('.menu-list-users-moderators-banned, .display-list-users-moderators-banned, .display-search-users-moderators-banned').addClass('hidden');
		$('.menu-list-admin-banned, .display-list-admin-banned, .display-search-admins-banned').addClass('hidden');
		$('#target-users').css({'border-bottom':'1px solid #6B6FD8',
										'color':'#6B6FD8'});
		$('#target-moderator').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-users-moderators-banned').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin-banned').css({'border-bottom':'none',
										'color':'#000000'});
	});
	$("#target-moderator").click(function(){
		$('.menu-list-user, .display-list-user, .display-search-users').addClass('hidden');
		$('.menu-list-moderator, .display-list-moderator, .display-search-moderators').removeClass('hidden');
		$('.menu-list-admin, .display-list-admin, .display-search-admins').addClass('hidden');
		$('.menu-list-users-moderators-banned, .display-list-users-moderators-banned, .display-search-users-moderators-banned').addClass('hidden');
		$('.menu-list-admin-banned, .display-list-admin-banned, .display-search-admins-banned').addClass('hidden');
		$('#target-moderator').css({'border-bottom':'1px solid #6B6FD8',
										'color':'#6B6FD8'});
		$('#target-users').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-users-moderators-banned').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin-banned').css({'border-bottom':'none',
										'color':'#000000'});
	});
	$("#target-admin").click(function(){
		$('.menu-list-user, .display-list-user, .display-search-users').addClass('hidden');
		$('.menu-list-moderator, .display-list-moderator, .display-search-moderators').addClass('hidden');
		$('.menu-list-admin, .display-list-admin, .display-search-admins').removeClass('hidden');
		$('.menu-list-users-moderators-banned, .display-list-users-moderators-banned, .display-search-users-moderators-banned').addClass('hidden');
		$('.menu-list-admin-banned, .display-list-admin-banned, .display-search-admins-banned').addClass('hidden');
		$('#target-admin').css({'border-bottom':'1px solid #6B6FD8',
										'color':'#6B6FD8'});
		$('#target-users').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-moderator').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-users-moderators-banned').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin-banned').css({'border-bottom':'none',
										'color':'#000000'});
	});
	$("#target-users-moderators-banned").click(function(){
		$('.menu-list-user, .display-list-user, .display-search-users').addClass('hidden');
		$('.menu-list-moderator, .display-list-moderator, .display-search-moderators').addClass('hidden');
		$('.menu-list-admin, .display-list-admin, .display-search-admins').addClass('hidden');
		$('.menu-list-users-moderators-banned, .display-list-users-moderators-banned, .display-search-users-moderators-banned').removeClass('hidden');
		$('.menu-list-admin-banned, .display-list-admin-banned, .display-search-admins-banned').addClass('hidden');
		$('#target-users-moderators-banned').css({'border-bottom':'1px solid #6B6FD8',
										'color':'#6B6FD8'});
		$('#target-users').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-moderator').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin-banned').css({'border-bottom':'none',
										'color':'#000000'});
	});
	$("#target-admin-banned").click(function(){
		$('.menu-list-user, .display-list-user, .display-search-users').addClass('hidden');
		$('.menu-list-moderator, .display-list-moderator, .display-search-moderators').addClass('hidden');
		$('.menu-list-admin, .display-list-admin, .display-search-admins').addClass('hidden');
		$('.menu-list-users-moderators-banned, .display-list-users-moderators-banned, .display-search-users-moderators-banned').addClass('hidden');
		$('.menu-list-admin-banned, .display-list-admin-banned, .display-search-admins-banned').removeClass('hidden');
		$('#target-admin-banned').css({'border-bottom':'1px solid #6B6FD8',
										'color':'#6B6FD8'});
		$('#target-users').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-admin').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-users-moderators-banned').css({'border-bottom':'none',
										'color':'#000000'});
		$('#target-moderator').css({'border-bottom':'none',
										'color':'#000000'});
	});

	function noPhoneResize(){
		$(window).resize(function(){
			var width = $(window).width();
				if(width > 768){
						$("#toggle-nav-filter").removeClass("visible");
						$("#toggle-nav-filter").addClass("hidden");
						$(".toggle-nav").removeClass("open");
						$("body").removeClass("overflow-y-hidden");
						$(".toggle-nav").addClass("background-transparent");
						$("body").addClass("overflow-y-auto");
						$(".toggle-nav").removeClass("hidden");
				}else{
						$(".toggle-nav").addClass("hidden");
				}
		});
	}

	function phoneResize(){
		$(window).resize(function(){
			var width = $(window).width();
				if(width > 768){
						$("#toggle-nav-filter").removeClass("visible");
						$("#toggle-nav-filter").addClass("hidden");
						$(".toggle-nav").removeClass("open");
						$("body").removeClass("overflow-y-hidden");
						$(".toggle-nav").addClass("background-transparent");
						$("body").addClass("overflow-y-auto");
						$(".toggle-nav").addClass("hidden");
				}else{
						$(".toggle-nav").removeClass("hidden");
				}
		});
	}

	$("#computer-platform").click(function(){
		$(".view-website").css("width","1920px");
		$(".toggle-nav").removeClass("view-website-menu");
		$(".toggle-open").toggleClass("toggle-open toggle");
		$(".toggle-nav").addClass("background-transparent");
		$(".toggle-nav").removeClass("hidden");
		$(".footer-width").removeClass("column");

		noPhoneResize();
	});

	$("#laptop-platform").click(function(){
		$(".view-website").css("width","1300px");
		$(".toggle-nav").removeClass("view-website-menu");
		$(".toggle-open").toggleClass("toggle-open toggle");
		$(".toggle-nav").addClass("background-transparent");
		$(".toggle-nav").removeClass("hidden");
		$(".footer-width").removeClass("column");

		noPhoneResize();
	});

	$("#tablet-platform").click(function(){
		$(".view-website").css("width","900px");
		$(".toggle-nav").removeClass("view-website-menu");
		$(".toggle-open").toggleClass("toggle-open toggle");
		$(".toggle-nav").addClass("background-transparent");
		$(".toggle-nav").removeClass("hidden");
		$(".footer-width").removeClass("column");

		noPhoneResize();
	});

	$("#phone-platform").click(function(){
		$(".view-website").css("width","400px");
		$(".toggle-nav").addClass("view-website-menu");
		$(".toggle").toggleClass("toggle toggle-open");
		$(".toggle-nav").addClass("background-transparent");
		$(".toggle-nav").addClass("hidden");
		$(".footer-width").addClass("column");

		phoneResize();
	});

});