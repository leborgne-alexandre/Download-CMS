$(document).ready(function(){
    $("#element-submit-creation-annonce-6028").click(function(){
        var title = $('#element-input-titre-creation-annonces-6005').val();
        var phone = $('#element-input-telephone-creation-annonces-6012').val(); 
        var day = $('#element-input-creation-annonces-jours-6014').val(); 
        var hours = $('#element-input-creation-annonces-heurs-6015').val(); 
        var price = $('#element-input-prix-creation-annonces-6007').val(); 
        var prestation = $('#element-select-heure-creation-annonces-6010').val(); 
        var date = $('#element-input-creation-annonces-date-6017').val();
        var place = $('#element-input-creation-annonces-lieu-6019').val(); 
        var state = $('#element-input-creation-annonces-departement-6027').val(); 
        var skill = $('#element-input-creation-annonces-competence-6021').val(); 
        var charge = $('#element-select-creation-annonces-charge-6023').val(); 
        var description = CKEDITOR.instances.description.getData();

        $.ajax({
            url: 'zz-addAnnounce?title='+ encodeURIComponent(title) +
            '&phone='+ encodeURIComponent(phone) +
            '&day=' + encodeURIComponent(day) +
            '&hours=' + encodeURIComponent(hours) +
            '&price=' + encodeURIComponent(price) +
            '&prestation=' + encodeURIComponent(prestation) +
            '&date=' + encodeURIComponent(date) +
            '&place=' + encodeURIComponent(place) + 
            '&state=' + encodeURIComponent(state) +
            "&skill=" + encodeURIComponent(skill) +
            "&charge=" + encodeURIComponent(charge) +
            "&description=" + encodeURIComponent(description)
            ,
            type:'GET',
            success: function(data){
                $('#displayErrors').html(data);
            }
        });
    });
});