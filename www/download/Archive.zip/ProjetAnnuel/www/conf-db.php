<?php
									/***
									***********
									*	VAR CONNEXION A LA BDD
									***********
									***
									*/
									////////////////////////////////////////
									/////////* NE PAS MODIFIER !!!!! *//////
									////////////////////////////////////////
									/****/ const DBDRIVER = "pgsql"; //// // driver postgreSQL
									///////////////////////////////////////
									///////////////////////////////////////
									//////////////////////////////////////

							/*** VOUS POUVEZ MODIFIER CES VALEURS EN CAS DE CHANGEMENT DE BDD ***/
													//		  |*|
													//		  |*|
													//		  |*|
													//		  |*|
													//		\ |*| /
													//		 \|*|/
													//		  \*/
										const DBHOST = "db";	// hote de la base de données
										const DBNAME = "CMS";	// nom de la base de données
										const DBUSER = "postgres";	// utilisateur de la base de données
										const DBPWD = "root";	// mot de passe de la base de données
										const DBPORT = 5432;	// port de la base de données
									
									/***
									*
									*	VAR HOTE 
									*/
									const HOST = "http://localhost/";	// nom de domaine du site
									/*
									***/