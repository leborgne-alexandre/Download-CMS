<?php

//declare (strict_types=1);

class DbPagesController{
	
	public function dbPagesAction(){

		$v = new View("dbPage", "front");

	}

}