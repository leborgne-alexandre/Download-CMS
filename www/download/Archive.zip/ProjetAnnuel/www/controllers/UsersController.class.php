<?php

//declare (strict_types=1);

/******
*******
	Controller du site
*******
******/

class UsersController{

	/*
	*
	*
	*
	*
	*
	***
		Action de la page "Home" du site
	**/
	//public function defaultAction(){
		/**** affichage de la view correspondante ****/
		//$v = new View("home", "front");
		
	//}

	/*
	*
	*
	*
	*
	*
	***
		Action de la page "inscription" du site
	**/
	public function testFrontLucasAction(){

		$v = new View("testFrontLucas", "front");
		
	}

	public function testFrontAlexAction(){

		$v = new View("testFrontAlex", "front");
		
	}

	public function testFrontTheoAction(){

		$v = new View("testFrontTheo", "front");
		
	}

	public function testBackLucasAction(){

		$v = new View("testBackLucas", "back");
		
	}

	public function testBackAlexAction(){

		$v = new View("testBackAlex", "back");
		
	}

	public function testBackTheoAction(){
		
		$v = new View("testBackTheo", "back");
		
	}
}