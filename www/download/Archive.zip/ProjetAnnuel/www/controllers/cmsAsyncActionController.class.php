<?php

//declare (strict_types=1);

/******
 *******
	Controller des requetes ajax du dashborad (admin doit etre connecté)
 *******
 ******/

class cmsAsyncActionController
{

	/*
	*
	*
	*
	*
	*
	***
		Async recherhe page dans page-list
	**/
	public function searchPagesAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$pages = new Pages();
			$query = $pages->removeUnwantedString($_GET['q']);
			print_r($result = $pages->getSearchedPages($query));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/page-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async supprimé page dans page-list
	**/
	public function deletePageInPageListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$pages = new Pages();
			$pageId = $pages->getThePageId($_GET['page']);
			$pages->deletePageInPageList($_GET['page']);
			$elements = new Elements();
			$elements->deleteElementIfPageDeleted($pageId);
			$styles = new Styles();
			$styles->deleteElementIfPageDeleted($pageId);
			$styles_hover = new Styles_hover();
			$styles_hover->deleteElementIfPageDeleted($pageId);
			$pages->generateSitemap();
			unset($_SESSION["first-choice-alert"]);
			session_destroy();
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/page-list").'');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recherhe annonces dans announce-list
	**/
	public function searchAnnouncesAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$annonces = new Annonces();
			$query = $annonces->removeUnwantedString($_GET['q']);
			print_r($result = $annonces->getSearchedAnnounces($query));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/announce-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async afficher annonces avec nouveau offset
	**/
	public function getAnnouncesWithNewOffsetAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$annonces = new Annonces();
			print_r($result = $annonces->getAllAnnounces($_GET['offset']));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/announce-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async supprimé annonces dans announce-list
	**/
	public function deleteAnnounceInPageListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$annonces = new Annonces();
			$result = $annonces->deleteAnnounceInPageList($_GET['a']);
			$pages = new Pages();
			$pages->generateSitemap();
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/announce-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async active annonce dans announce-list
	**/
	public function activateAnnounceAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$annonces = new Annonces();
			if(isset($_GET["all"]) && $_GET["all"] == "true")
				$result = $annonces->activateAnnounce(null, TRUE);
			else
				$result = $annonces->activateAnnounce($_GET['announce']);

			if(isset($_GET["notif"]) && $_GET["notif"] == "true"){
				$notifications = new Notifications();
				if(isset($_GET["all"]) && $_GET["all"] == "true")
					$notifications->deleteNewAnnounceNotif(null, TRUE);
				else
					$notifications->deleteNewAnnounceNotif($_GET['announce']);
			}
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/announce-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async desactive annonce dans announce-list
	**/
	public function desactivateAnnounceAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$annonces = new Annonces();
			$result = $annonces->desactivateAnnounce($_GET['announce']);

			if(isset($_GET["notif"]) && $_GET["notif"] == "true"){
				$notifications = new Notifications();
				$notifications->deleteNewAnnounceNotif($_GET['announce']);
			}
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/announce-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recuperer user et moderator avec nouveau offset dans page-list
	**/
	public function getUsersModeratorsWithNewOffsetAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			if (isset($_GET['role']))
				print_r($result = $siteUsers->getAllUsers($_GET['offset'], $_GET['role']));
			else
				print_r($result = $siteUsers->getAllUsers($_GET['offset']));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recherche user dans user-list
	**/
	public function searchUsersAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			$query = $siteUsers->removeUnwantedString($_GET['q']);
			print_r($result = $siteUsers->getSearchedUsers($query));
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/user-list").'');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		Async supprimé user ou moderateur dans user-list
	**/
	public function banUserOrModeratorInUserListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			$result = $siteUsers->banUser($_GET['u']);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recherhe moderateurs dans user-list
	**/
	public function searchModeratorsAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			$query = $siteUsers->removeUnwantedString($_GET['q']);
			print_r($result = $siteUsers->getSearchedUsers($query, ID_ROLE_MODERATOR)); // ID_ROLE_MODERATOR => id_role (moderateur)
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/user-list").'');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recuperer administrateur avec nouveau offset dans page-list
	**/
	public function getAdminWithNewOffsetAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			print_r($result = $usr->getAdmin($_GET['offset']));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recherhe admin dans user-list
	**/
	public function searchAdminsAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$query = $usr->removeUnwantedString($_GET['q']);
			print_r($result = $usr->getSearchedAdmin($query));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async supprimé moderateur dans user-list
	**/
	public function banAdminInUserListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			if($_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN)
				$result = $usr->banUser($_GET['a']);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recuperer utilisateurs et moderateurs bannis avec nouveau offset dans page-list
	**/
	public function getUsersModeratorsBannedWithNewOffsetAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			print_r($result = $siteUsers->getBannedUsersAndModerators($_GET['offset']));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recherche user et moderateurs banni dans user-list
	**/
	public function searchUsersModeratorBannedAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			$query = $siteUsers->removeUnwantedString($_GET['q']);
			print_r($result = $siteUsers->getSearchedBannedUsers($query));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async supprimé user et moderateurs banni dans user-list
	**/
	public function deleteUserAndModeratorBannedAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$siteUsers = new Siteusers();
			$userId = $siteUsers->selectUserId($_GET['u']);
			$result = $siteUsers->deleteBanned($_GET['u']);
			$announces = new Annonces();
			$announces->deleteAnnounceFromUser($userId);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recuperer administrateurs bannis avec nouveau offset dans page-list
	**/
	public function getAdminBannedWithNewOffsetAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			print_r($result = $usr->getBannedAdmin($_GET['offset']));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recherche user et moderateurs banni dans user-list
	**/
	public function searchAdminBannedAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$query = $usr->removeUnwantedString($_GET['q']);
			print_r($result = $usr->getSearchedBannedAdmin($query));
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async supprimé admin banni dans user-list
	**/
	public function deleteAdminBannedAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			if($_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN)
				$result = $usr->deleteBanned($_GET['a']);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async debannir admin banni dans user-list
	**/
	public function unbanAdminAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			if($_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN)
				$result = $usr->unbanUser($_GET['a']);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async debannir utilisateur ou modérateur banni dans user-list
	**/
	public function unbanUserModeratorAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();
		if ($isValid) {
			$siteUsers = new Siteusers();
			$result = $siteUsers->unbanUser($_GET['u']);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/user-list") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		Async recuperer les styles correspondant a l element selectionné et l afficher dans le menu d'edit
	**/
	public function getEditableStylesAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$styles = new Styles();
			$stylesHover = new Styles_hover();
			print_r($styles->getEditableStyles($_GET['id']));
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		Async insere les nouveaux styles (styles modifié par l user)
	**/
	public function insertNewStyleAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$styles = new Styles();
			$insertStyle = $styles->insertNewStyle($_GET['style'], $_GET['value'], $_GET['element']);
			if($_GET['style'] == "contenu" || $_GET['style'] == "placeholder")
				print_r($insertStyle);
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		Async insere les nouveaux styles en hover (styles modifié par l user)
	**/
	public function insertNewStyleHoverAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$stylesHover = new Styles_hover();
			$stylesHover->insertNewStyle($_GET['style'], $_GET['value'], $_GET['element']);
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		enleve une transition en bdd
	**/
	public function removeTransitionAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$styles = new Styles();
			$styles->updateTransitionField($_GET['style'], "", $_GET['id']);
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		affichage details user et moderator
	**/
	public function getUserModeratorDetailsAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$siteUsers = new Siteusers();
			$details = $siteUsers->getUserDetails($_GET['u']);
			$v = new View("userAccountUserList", "inCMS");
			$v->assign("detailsForm", $details);
			print_r($v->addModalBack("detailsForm", $details));
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/users-list").'');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		affichage details admin
	**/
	public function changeRoleAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			if($_GET["role"] == ID_ROLE_MODERATOR || $_GET["role"] == ID_ROLE_USER){
				$siteUsers = new Siteusers();
				$siteUsers->changeRole($_GET["mail"], $_GET["role"]);
			}
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/users-list").'');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		active la page
	**/
	public function activatePageAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$pages = new Pages();
			$pages->activatePage($_GET["page"]);
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/page-list").'');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		désactive la page
	**/
	public function desactivatePageAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$pages = new Pages();
			$pages->desactivatePage($_GET["page"]);
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/page-list").'');
		}	
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la modification des infos d une page
	**/

	public function updatePageInfosAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$pages = new Pages();
			$announces = new Annonces();

			$pageName = $pages->removeUnwantedString(trim($_GET["name"]));
			$checkPageNameLength = $pages->stringLengthValidator($pageName, 100);
			$pageTitle = $pages->removeUnwantedString(trim($_GET["title"]));
			$pageSlug = trim($_GET["slug"]);
			$pageDescription = $pages->removeUnwantedString(trim($_GET["description"]));
			$initialName = $_GET["initial_name"];
			$initialSlug = $_GET["initial_slug"];

			$pageNameExists = $pages->checkIfPageNameExists($pageName);

			if(!$checkPageNameLength){
				echo "Le nom de la page est trop long (maximum autorisé : 100 caractères)";
				return;
			}

			if($pageSlug != ""){
				$convertStringToSlug = new ConvertStringToSlug($pageSlug);
				$slugStructureVerified = $convertStringToSlug->slug;
				$pageSlugExistsInPages = $pages->checkIfSlugExists($slugStructureVerified);
				$pageSlugExistsInAnnounces = $announces->checkIfSlugExists($slugStructureVerified);
				$pageSlug = $slugStructureVerified;
			}else{
				$convertStringToSlug = new ConvertStringToSlug($pageName);
				$nameConvertToSlug = $convertStringToSlug->slug;
				$pageNameAsSlugExistsInPages = $pages->checkIfSlugExists($nameConvertToSlug);
				$pageNameAsSlugExistsInAnnounces = $announces->checkIfSlugExists($nameConvertToSlug);
				$pageSlug = $nameConvertToSlug;
			}
			
			if($pageNameExists && $pageName != $initialName){
				echo "Le nom de cette page existe déja";
			}elseif(($pageSlug != $initialSlug) && (isset($pageSlugExistsInPages) && $pageSlugExistsInPages) 
			|| (isset($pageNameAsSlugExistsInPages) && $pageNameAsSlugExistsInPages)
			|| (isset($pageSlugExistsInAnnounces) && $pageSlugExistsInAnnounces)
			|| (isset($pageNameAsSlugExistsInAnnounces) && $pageNameAsSlugExistsInAnnounces)){
				echo "Cette page existe déja";
			}else{
				echo "Les informations ont bien été modifiées";
				$pages->updatePageInfos($initialSlug, $pageName, $pageTitle, $pageSlug, $pageDescription);
				$pages->generateSitemap();
			}
	
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		ajoute un element dans l edition de page
	**/
	
	public function addElementAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$elements = new Elements();
			$elementName = $elements->removeUnwantedString(trim($_GET["element_name"]));
			$checkElementNameLength = $elements->stringLengthValidator($elementName, 100);
			$convertedElementName = new ConvertStringToElementName($elementName);

			if(!$checkElementNameLength){
				echo 0;
			}else{
				$elementHtml = $elements->addElement($_GET["element"], $convertedElementName->elementName, $_GET["slug"], $_GET["file_name"], $_GET["path"]);
				print_r($elementHtml);
			}
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/*
	*
	*
	*
	*
	*
	***
		recupere les medias a a jouter en fonction du type renseigné
	**/
	
	public function getMediasToAddAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$medias = new Media();
			$mediasFounds = $medias->getMediasToAdd($_GET["type"]);
			echo json_encode($mediasFounds);
		}else{
			header('Location: /zz-sign_in');
		}	
	}

	/**
	 * 
	 * supprime un element
	 * 
	 * 
	 */

	public function deleteElementAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$elements = new Elements();

			$isDeletable = $elements->checkIfElementIsDeletable($_GET["element"]);

			if($isDeletable){
				$pages = new Pages();
				$pages->updateLastChangeDate($_GET["element"]);

				$elements->deleteElement($_GET["element"]);
				$styles = new Styles();
				$styles->deleteElement($_GET["element"]);
				$styles_hover = new Styles_hover();
				$styles_hover->deleteElement($_GET["element"]);

			}
			
		}else{
			header('Location: /zz-sign_in');
		}	

	}

	/**
	 * 
	 * verifie et envoi la redirection d un lien en bdd
	 * 
	 * 
	 */

	public function sendLinkAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			$elements = new Elements();
			if($_GET["type"] == "internal")
				$isURLvalid = $elements->checkIfUrlValid($_GET["value"], TRUE); // true signifie qu il s agit d une url interne
			else
				$isURLvalid = $elements->checkIfUrlValid($_GET["value"]);
			if($isURLvalid){
				$elements->insertLink($_GET["value"], $_GET["element"]);
				echo "true";
			}else{
				echo "false";
			}
		}else{
			header('Location: /zz-sign_in');
		}

	}

	/*
	*
	*
	*
	*
	*
	***
		Async Verifie si le favicon est envoyé au serveur, et si c'est avec l'extension .ico
	**/
	public function faviconSendAction()
	{
		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("faviconVerif", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/faviconSend") . '');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		recupere les notes
	**/
	public function getNotesAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$notes = new Notes();
			$text = $notes->getNotes();
			echo $text;
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		sauvegarde les notes
	**/
	public function saveNotesAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();
		
		if ($isValid) {
			$notes = new Notes();
			if(!isset($_GET["title"])){
				$notes->saveNotes($_GET["text"]);
				echo "<i class='fas fa-check'></i> notes sauvegardées";
			}else{
				$notes->saveNotes($_GET["text"], $_GET["title"], true);
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		verifie le media et visualisation. Ou upload direct si video
	**/
	public function beforeAddImageOrDwnlVideoAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();
		
		if ($isValid) {
			$media = new Media();
			$mediaErrors = $media->checkIfMediaIsValid($_FILES['select-file']['name'], $_FILES['select-file']['size'], $_FILES['select-file']['error']);
			if($mediaErrors["hasErrors"] === 0){
				$preview = $media->showMediaPreview($_FILES['select-file']['name'], $_FILES['select-file']['size']);
				if(strstr($_FILES['select-file']['type'], "video")){
					$file = $media->insertMedia($_FILES['select-file']['name'], $_FILES['select-file']['size']);
					$media->createMediaFile($file["fileName"], $_FILES['select-file']['tmp_name'], true);
					$newMediaId = $media->getMediaId($file["fileName"]);
					$preview["newFileName"] = $file["fileName"];
					$preview["newMediaId"] = $newMediaId;
				}
				echo json_encode($preview);
			}else{
				echo json_encode($mediaErrors);
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		insere le media en bdd
	**/
	public function addMediaAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			if($_POST["title"] != ""){
				$media = new Media();
				$mediaErrors = $media->checkIfMediaIsValid($_POST["file_name"], $_POST["file_size"], 0, true);
				if($mediaErrors["hasErrors"] === 0){
					$result = [];
					$file = $media->insertMedia($_POST["file_name"], $_POST["file_size"], $_POST["title"]);
					$media->createMediaFile($file["fileName"], $_POST["media"]);
					$newMediaId = $media->getMediaId($file["fileName"]);
					$result["newFileName"] = $file["fileName"];
					$result["newMediaId"] = $newMediaId;
					$result["fileTitle"] = $file["fileTitle"];
					$result["fileSize"] = $file["fileSize"];
					echo json_encode($result);
				}else{
					echo 0;
				}
			}else{
				echo 0;
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/*
	*
	*
	*
	*
	*
	***
		supprime un media
	**/
	public function deleteMediaAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$media = new Media();
			$media->deleteMedia($_GET["file_name"], $_GET["path"]);
		} else {
			header('Location: /zz-sign_in');
		}

	}

	/*
	*
	*
	*
	*
	*
	***
		modifie le media d'un element en edition
	**/
	public function updateMediaInEditionAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			if($_GET["is_background"] == "false"){
				$elements = new Elements();
				$elements->updateMediaInEdition($_GET["path"], $_GET["file_name"], $_GET["id_element"]);
			}else{
				$styles = new Styles();
				$styles->updateMediaInEdition($_GET["path"], $_GET["file_name"], $_GET["id_element"], $_GET["is_background"], $_GET["is_unable"]);
			}
		} else {
			header('Location: /zz-sign_in');
		}

	}
}
