<?php

//declare (strict_types=1);

/******
 *******
	Controller du compte Administrateur de CMS (quand l admin est loggé)
 *******
 ******/

class cmsUserAccountController
{

	/*
	*
	*
	*
	*
	*
	***
		Action de la page "Home" du CMS (page apres loggin de l'admin)
	**/
	public function dashboardAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountDashboard", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/dashboard") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "Statistics" du CMS
	**/
	public function statisticsAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountStatistics", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/statistics") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "website" du CMS
	**/
	public function websiteAction()
	{

		if (!isset($_GET["page"]) || empty($_GET["page"])) {
			header('Location: /zz-admin/website?page=home');
		}

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountViewSite", "back");
		} else {
			$currentSlug = new GetCurrentSlug(TRUE);
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/website?page=" . $currentSlug->slug . "") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "pageList" du CMS
	**/
	public function pageListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountPageList", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/page-list") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "addNewPage"
	**/

	public function addNewPageAction(){

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if($isValid){
			
			$pages = new Pages();
			$announces = new Annonces();
			$addNewPageForm = $pages->getCreatePageForm();
			$method = strtoupper($addNewPageForm["config"]["method"]);
			$data = $GLOBALS["_".$method];

			if( $_SERVER['REQUEST_METHOD']==$method && !empty($data) ){

				$validator = new Validator($addNewPageForm, $data);
				$addNewPageForm["errors"] = $validator->errors;

				if(empty($validator->errors)){
					$pages->setPageName($pages->removeUnwantedString(trim($data["name"])));
					$pages->setTitle($pages->removeUnwantedString(trim($data["title"])));
					$pages->setDescription($pages->removeUnwantedString(trim($data["description"])));
					$templateName = $data["template-list"];

					$pageNameExists = $pages->checkIfPageNameExists($pages->nom_page);

					if(trim($data["slug"]) != ""){
						$slug = $pages->removeUnwantedString(trim($data["slug"]));
						$convertStringToSlug = new ConvertStringToSlug($slug);
						$slugStructureVerified = $convertStringToSlug->slug;
						$pageSlugExistsInPages = $pages->checkIfSlugExists($slugStructureVerified);
						$pageSlugExistsInAnnounces = $announces->checkIfSlugExists($slugStructureVerified);
						$pages->setSlug($slugStructureVerified);
					}else{
						$convertStringToSlug = new ConvertStringToSlug($pages->nom_page);
						$nameConvertToSlug = $convertStringToSlug->slug;
						$pageNameAsSlugExistsInPages = $pages->checkIfSlugExists($nameConvertToSlug);
						$pageNameAsSlugExistsInAnnounces = $announces->checkIfSlugExists($nameConvertToSlug);
						$pages->setSlug($nameConvertToSlug);
					}
					
					if($pageNameExists){
						$validator->errors = ["le nom de cette page existe déja"];
						$addNewPageForm["errors"] = $validator->errors;
					}elseif((isset($pageSlugExistsInPages) && $pageSlugExistsInPages) 
					|| (isset($pageNameAsSlugExistsInPages) && $pageNameAsSlugExistsInPages)
					|| (isset($pageSlugExistsInAnnounces) && $pageSlugExistsInAnnounces)
					|| (isset($pageNameAsSlugExistsInAnnounces) && $pageNameAsSlugExistsInAnnounces)){
						$validator->errors = ["Cette page existe déja"];
						$addNewPageForm["errors"] = $validator->errors;
					}else{
						$pages->createNewPage($templateName);
						$pages->generateSitemap();
						header('Location: /zz-admin/website?page='.$pages->slug);
					}
				}

			}

			$v = new View("addNewPage", "back");
			$v->assign("inCmsForm", $addNewPageForm);
	
		}else{
			header('Location: /zz-sign_in?action='.urlencode("/zz-admin/add-new-page").'');
		}	
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "announceList" du CMS
	**/
	public function announceListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountAnnounceList", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/announce-list") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "announceList" du CMS
	**/
	public function usersListAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountUserList", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/users-list") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "medias" du CMS
	**/
	public function mediasAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountMedias", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/medias") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "notifications" du CMS
	**/
	public function notificationsAction()
	{

		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountNotifications", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/notifications") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "parametres" du CMS
	**/
	public function parametersAction()
	{

		$user = new Usr();
		$isValid = $user->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountParameters", "back");

			//Formulaire de changement d'Email'
			$newEmailForm = $user->getParameterChangeEmailForm();

			$method = strtoupper($newEmailForm["config"]["method"]);
			$data = $GLOBALS["_" . $method];

			if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
				$validator = new Validator($newEmailForm, $data);
				$newEmailForm["errors"] = $validator->errors;

				if (empty($validator->errors)) {
					$user->setMail($data["mail"]);
					$user->checkMatchingPassword($user->getMail(), $data["confirm-password"]);
					$user->updateEmail($data["mail"]);
				} else {
					$validator->errors = ["Le mot de passe est incorrect ou l'email est invalide"];
					$newEmailForm["errors"] = $user->errors;
				}
			}

			$v->assign("formEmail", $newEmailForm);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/parameters") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "profil" du CMS
	**/
	public function profilAction()
	{

		$user = new Usr();
		$isValid = $user->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountProfil", "back");

			//Formulaire de changement d'Email'
			$newEmailForm = $user->getParameterChangeEmailForm();

			$method = strtoupper($newEmailForm["config"]["method"]);
			$data = $GLOBALS["_" . $method];

			if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
				$validator = new Validator($newEmailForm, $data);
				$newEmailForm["errors"] = $validator->errors;

				if (empty($validator->errors)) {
					$user->setMail($data["mail"]);
					$user->checkMatchingPassword($user->getMail(), $data["confirm-password"]);
					$user->updateEmail($data["mail"]);
				} else {
					$validator->errors = ["Le mot de passe est incorrect ou l'email est invalide"];
					$newEmailForm["errors"] = $user->errors;
				}
			}

			$v->assign("formEmail", $newEmailForm);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/profil") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "parametres/password" du CMS
	**/
	public function userAccountProfilPasswordAction()
	{

		$user = new Usr();
		$isValid = $user->checkIfUserConnected();

		if ($isValid) {
			$v = new View("userAccountProfilPassword", "back");

			//Formulaire de changement de mot de passe
			$resetPasswordForm = $user->getParameterChangePasswordForm();

			$method = strtoupper($resetPasswordForm["config"]["method"]);
			$data = $GLOBALS["_" . $method];

			if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
				$validator = new Validator($resetPasswordForm, $data);
				$resetPasswordForm["errors"] = $validator->errors;

				if (empty($validator->errors)) {
					$user->setPassword($data['confirm-password']);
					$user->checkMatchingPassword($user->getAccountUserEmail(), $user->getPassword());
					$user->CheckEqualPassword($data['new-password'], $data['confirm-new-password']);
					$user->updatePassword($data['new-password'], $user->getAccountUserEmail());
				} else {
					$validator->errors = ["Le mot de passe est incorrect"];
					$resetPasswordForm["errors"] = $user->errors;
				}
			}

			$v->assign("formPassword", $resetPasswordForm);
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/userAccountProfilPassword") . '');
		}
	}			

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "parametres/database" du CMS
	**/
	public function parametersDatabaseAction()
	{

		$user = new Usr();
		$isValid = $user->checkIfUserConnected();

		if ($isValid) {

			if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN){
				$v = new View("parametersDatabase", "back");

				//Formulaire de changements d'accès base de donnée & nom de domaine
				$newBddAccessForm = $user->getNewBddAccessForm();

				$method = strtoupper($newBddAccessForm["config"]["method"]);
				$data = $GLOBALS["_" . $method];

				if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
					$validator = new Validator($newBddAccessForm, $data);
					$newBddAccessForm["errors"] = $validator->errors;

					if (empty($validator->errors)) {
						$user->parametersChangeBddName($data['new-bdd-name']);
						$user->parametersChangeBddId($data['new-id']);
						$user->parametersChangeBddPassword($data['new-password']);
						$user->parametersChangeBddHost($data['new-host']);
						$user->parametersChangeDomainName($data['new-domain-name']);
					} else {
						$validator->errors = ["Les infos ne sont pas valides"];
						$newBddAccessForm["errors"] = $user->errors;
					}
				}

				$v->assign("formNewBddAccess", $newBddAccessForm);
			}else{
				header('Location: /zz-admin/parameters');
			}
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/parametersDatabase") . '');
		}
	}	

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Redirection vers ChangeFavicon
	**/
	public function faviconAction()
	{
		$usr = new Usr();
		$isValid = $usr->checkIfUserConnected();

		if ($isValid) {
			$v = new View("faviconUpdate", "back");
		} else {
			header('Location: /zz-sign_in?action=' . urlencode("/zz-admin/favicon") . '');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page "log_out" du CMS
	**/
	public function logOutAction()
	{

		$logOut = new LogOut();
		$logOut->destroySession();
		header('Location: /zz-sign_in');
	}
}
