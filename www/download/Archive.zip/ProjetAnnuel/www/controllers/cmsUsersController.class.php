<?php

//declare (strict_types=1);

/******
 *******
	Controller du loggin au CMS + services associés (perte mot de passe ...)
	et de la configuration de l'administrateur (creation compte)
 *******
 ******/

class cmsUsersController
{

	/*
	*
	*
	*
	*
	*
	***
		Action de la page "login" au CMS
	**/
	public function loginAction(){
		$user = new Usr();
		$isUserExisting = $user->checkExistingUser();
		if(!empty($isUserExisting)){
			$blacklist = new Blacklist();
			$loginForm = $user->getLoginForm();
			$method = strtoupper($loginForm["config"]["method"]);
			$data = $GLOBALS["_".$method];
			if( $_SERVER['REQUEST_METHOD']==$method && !empty($data) ){
					$user->setMail($data["mail"]);	
					$user->setPassword($data["password"]);
					$user->access($user->getMail(), $user->getPassword(), "/zz-admin/dashboard");
					$loginForm["errors"] = $user->errors;
			}
			$v = new View("login", "back");
			$v->assign("form", $loginForm);
		}else{
			header('Location: zz-sign_up');
		}
		
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page perte de mot de passe du CMS
	**/
	public function forgetPasswordAction()
	{

		$user = new Usr();

		$forgetPasswordForm = $user->getForgetPasswordForm();

		$method = strtoupper($forgetPasswordForm["config"]["method"]);
		$data = $GLOBALS["_" . $method];

		if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
			$validator = new Validator($forgetPasswordForm, $data);
			$forgetPasswordForm["errors"] = $validator->errors;

			if (empty($validator->errors)) {
				$user->setMail($data["mail"]);
				$users = $user->checkUser($user->getMail());

				if (!empty($users)) {
					$resetPassword = new ResetPassword();
					$resetPassword->setMail($data["mail"]);
					$resetPassword->sendMailAskResetPassword($resetPassword->getMail());
				} else {
					$validator->errors = ["L'adresse mail renseignée n'est pas connu de la base de données"];
					$forgetPasswordForm["errors"] = $validator->errors;
				}
			}
		}

		$v = new View("forgetPassword", "back");
		$v->assign("form", $forgetPasswordForm);
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page reinitialisation du mot de passe du CMS
	**/
	public function resetPasswordAction()
	{

		$user = new Usr();

		$resetPasswordForm = $user->getResetPasswordForm();

		$resetPassword = new ResetPassword();

		$resetPassword->setMail($_GET["u"]);
		$resetPassword->setKey($_GET["k"]);
		$isUserInResetPasswordTable = $resetPassword->checkUserInResetPasswordTable($resetPassword->getMail(), $resetPassword->getKey());

		if (empty($isUserInResetPasswordTable))
			header('Location: /zz-sign_in');

		$method = strtoupper($resetPasswordForm["config"]["method"]);
		$data = $GLOBALS["_" . $method];

		if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
			$validator = new Validator($resetPasswordForm, $data);
			$resetPasswordForm["errors"] = $validator->errors;

			if (empty($validator->errors)) {
				$resetPassword->updatePasswordAndDeleteAsk($data["password"], $resetPassword->getMail());
			}
		}

		$v = new View("resetPassword", "back");
		$v->assign("form", $resetPasswordForm);
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page inscription et ajout d'un administrateur du CMS
	**/
	public function signUpAction()
	{

		$user = new Usr();

		$isUserExisting = $user->checkExistingUser();
		$isVerifiedAskNewUser = NULL;

		if (isset($_GET['u']) && isset($_GET['k'])) {
			$askNewUser = new AskNewUser();
			/*
			*	k = cle unique
			*/
			/*
			*	u = mail de l admin
			*/
			$askNewUser->setMail($_GET['u']);
			$askNewUser->setKey($_GET['k']);
			$isVerifiedAskNewUser = $askNewUser->verifAskNewUser($askNewUser->getMail(), $askNewUser->getKey());
		}

		if (empty($isUserExisting) || !empty($isVerifiedAskNewUser)) {
			$signUpform = $user->getSignUpForm();
			$method = strtoupper($signUpform["config"]["method"]);
			$data = $GLOBALS["_" . $method];

			if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
				$validator = new Validator($signUpform, $data);
				$signUpform["errors"] = $validator->errors;

				if (empty($validator->errors)) {
					$user->setUsername($data["username"]);
					$user->setPassword($data["password"]);
					$user->setMail($data["mail"]);
					$users = $user->checkUser($user->getMail());

					if (empty($users)) {
						if (!empty($isUserExisting))
							$isAdded = $user->addUser($user->getMail());
						else
							$isAdded = $user->addUser($user->getMail(), TRUE); // TRUE signifie que l'on ajoute le premier utilisateur dans la table usr et sera donc l unique SuperAdmin

						if (isset($_GET['u']) && isset($_GET['k']) && $isAdded) {
							$askNewUser = new AskNewUser();
							$askNewUser->setMail($_GET['u']);
							$askNewUser->setKey($_GET['k']);
							$askNewUser->deleteAskNewUser($askNewUser->getMail(), $askNewUser->getKey());
						}
					} else {
						$validator->errors = ["Cet utilisateur est déja enregistré"];
						$signUpform["errors"] = $validator->errors;
					}
				}
			}

			$v = new View("signUp", "back");
			$v->assign("form", $signUpform);
		} else {
			header('Location: zz-ask_new_user');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page de demande d'ajout d'un nouvel administrateur au CMS
	**/
	public function askNewUserAction()
	{

		$user = new Usr();

		$askNewUserForm = $user->getAskNewUserForm();
		$method = strtoupper($askNewUserForm["config"]["method"]);
		$data = $GLOBALS["_" . $method];

		if ($_SERVER['REQUEST_METHOD'] == $method && !empty($data)) {
			$validator = new Validator($askNewUserForm, $data);
			$askNewUserForm["errors"] = $validator->errors;

			$askNewUser = new AskNewUser();

			$mailSuperAdmin = trim($data["mail-superadmin"]);
			$askNewUser->setMail($data["mail-user"]);

			if (empty($validator->errors)) {
				$user->setMail($data["mail-superadmin"]);
				$users = $user->checkUser($user->getMail());

				$isAlreadyAsked = $askNewUser->checkIfAlreadyAsked($askNewUser->getMail());

				if($isAlreadyAsked){
					$validator->errors = ["Il y a déjà eu une demande avec cette adresse mail"];
					$askNewUserForm["errors"] = $validator->errors;
				}else if(!empty($users)) {
					$token = new Token();
					$secretKey = $token->token;
					$askNewUser->setKey($secretKey);
					$askNewUser->insert();
					$currentTime = new GetCurrentTime();
					$notifications = new Notifications();
					$notifications->setTypeNotification(ASK_NEW_ADMIN_NOTIFICATION_TYPE);
					$notifications->setDate($currentTime->currentTime);
					$notifications->setMail($askNewUser->getMail());
					$notifications->setKey($secretKey);
					$notifications->createNotif();
					$askNewUser->sendMailAcceptOrNoSignUp($mailSuperAdmin, $askNewUser->getMail(), $secretKey);
				} else {
					$validator->errors = ["L'adresse mail renseignée ne correspond pas à un SuperAdministrateur"];
					$askNewUserForm["errors"] = $validator->errors;
				}
			}
		}

		$v = new View("askNewUser", "back");
		$v->assign("form", $askNewUserForm);
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page lorsque qu'un utilisateur a été autorisé a s inscrire en tant que super admin au CMS
	**/
	public function sendAutorisedSignUpAction()
	{
		if (isset($_GET['u']) && isset($_GET['k'])) {
			$askNewUser = new AskNewUser();
			$askNewUser->setMail($_GET['u']);
			$askNewUser->setKey($_GET['k']);
			$isInTable = $askNewUser->verifAskNewUser($askNewUser->getMail(), $askNewUser->getKey());

			if (!empty($isInTable)) {
				$askNewUser->sendMailToAccessToSignUpPage($askNewUser->getMail(), $askNewUser->getKey());
				$notifications = new Notifications();
				$notifications->deleteAskNewUserNotif($askNewUser->getMail(), $askNewUser->getKey());

				if(!isset($_GET["notif"])){
					$v = new View("autorisedSignUpMail", "back");
				}
			} else {
				header('Location: /zz-sign_in');
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page lorsque qu'un utilisateur n'a pas été autorisé a s inscrire en tant que super admin au CMS
	**/
	public function refusedSignUpAction()
	{
		if (isset($_GET['u']) && isset($_GET['k'])) {
			$askNewUser = new AskNewUser();
			$askNewUser->setMail($_GET['u']);
			$askNewUser->setKey($_GET['k']);
			$isInTable = $askNewUser->verifAskNewUser($askNewUser->getMail(), $askNewUser->getKey());

			if (!empty($isInTable)) {
				$askNewUser->sendMailRefusedSignUp($askNewUser->getMail());
				$askNewUser->deleteAskNewUser($askNewUser->getMail(), $askNewUser->getKey());
				$notifications = new Notifications();
				$notifications->deleteAskNewUserNotif($askNewUser->getMail(), $askNewUser->getKey());

				if(!isset($_GET["notif"])){
					$v = new View("refusedSignUpMail", "back");
				}
			} else {
				header('Location: /zz-sign_in');
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/*
	*
	*
	************************************************************************************
	*
	*
	***
		Action de la page de validation du compte
	**/
	public function validateAccountSignUpAction()
	{

		if (isset($_GET['u']) && isset($_GET['k'])) {
			$user = new Usr();
			$user->setMail($_GET['u']);
			$user->setVerifAccountKey($_GET['k']);
			$keyFound = $user->verifKeyAccount($user->getMail(), $user->getVerifAccountKey());

			if (!empty($keyFound)) {
				$user->validateAccount($user->getMail());
			} else {
				header('Location: /');
			}

			$v = new View("validateAccountSignUp", "back");
		} else {
			header('Location: /zz-sign_in');
		}
	}
}
