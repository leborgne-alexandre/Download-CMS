<?php

//declare (strict_types=1);

/******
*******
	Controller de la creation et configuration de la bdd)
*******
******/

class configBddController{

	/*
	*
	*
	*
	*
	*
	***
		Action de la page "zz-config-cms"
		PAGE DE CONFIGURATION DU CMS (config BDD)
	**/
	public function configCmsAction(){

		$fileConfDb = "conf-db.php";
		if(file_exists($fileConfDb)){
			header('Location: zz-sign_in');
		}else{

			$configBdd = new ConfigBdd();
			$configBddForm = $configBdd->getConfigBddForm();
			$method = strtoupper($configBddForm["config"]["method"]);
			$data = $GLOBALS["_".$method];

			if( $_SERVER['REQUEST_METHOD']==$method && !empty($data) ){
				$validator = new Validator($configBddForm,$data);
				$configBddForm["errors"] = $validator->errors;

				if(empty($validator->errors)){

					try{
						new PDO("pgsql:host=".$data["host"].";port=".$data["port"].";dbname=".$data["name-bdd"],$data["id"],$data["password-bdd"]);

						try{

							$connect = new PDO("pgsql:host=".$data["host"].";port=".$data["port"].";dbname=".$data["name-bdd"],$data["id"],$data["password-bdd"]);

							$sql = file_get_contents("sql/build-db-cms.sql");

							$result = $connect->exec($sql);

							//print_r($connect->errorInfo());

							if($result === 0){

								$confFile = fopen('conf-db.php', 'a');

								fputs($confFile,

									'<?php
									/***
									***********
									*	VAR CONNEXION A LA BDD
									***********
									***
									*/
									////////////////////////////////////////
									/////////* NE PAS MODIFIER !!!!! *//////
									////////////////////////////////////////
									/****/ const DBDRIVER = "pgsql"; //// // driver postgreSQL
									///////////////////////////////////////
									///////////////////////////////////////
									//////////////////////////////////////

							/*** VOUS POUVEZ MODIFIER CES VALEURS EN CAS DE CHANGEMENT DE BDD ***/
													//		  |*|
													//		  |*|
													//		  |*|
													//		  |*|
													//		\ |*| /
													//		 \|*|/
													//		  \*/
										const DBHOST = "'.$data["host"].'";	// hote de la base de données
										const DBNAME = "'.$data["name-bdd"].'";	// nom de la base de données
										const DBUSER = "'.$data["id"].'";	// utilisateur de la base de données
										const DBPWD = "'.$data["password-bdd"].'";	// mot de passe de la base de données
										const DBPORT = '.$data["port"].';	// port de la base de données
									
									/***
									*
									*	VAR HOTE 
									*/
									const HOST = "'.$data["domain-name"].'";	// nom de domaine du site
									/*
									***/'

								);

								fclose($confFile);

								$fileConfDb = "conf-db.php";
								include $fileConfDb;

								$user = new Usr();

								$user->setUsername($data["username"]);	
								$user->setPassword($data["password"]);
								$user->setMail($data["mail"]);

								$token = new Token();
								$secretKey = $token->token;
								
								$isAdded = $user->addUser($data["mail"], TRUE, $secretKey); // TRUE signifie que l'on ajoute le premier utilisateur dans la table usr et sera donc l unique SuperAdmin

								$medias = new Media();
								$medias->getInitialMedias();

								//session_start();
								$_SESSION["db-downloaded"] = $data["mail"];

							}else{
	  							session_start();
								$_SESSION["error-db-downloaded"]="error";
							}

						}catch(PDOException $e){
							$configBddForm["errors"] = [$e->getMessage()];
						}
						
					}catch(Exception $e){
						$configBddForm["errors"] = [$e->getMessage()];
					}
				}

			}

			$v = new View("configCms", "back");
			$v->assign("configBddForm", $configBddForm);
		}
	}
	/***********************************
	************************************
	***********************************/
}