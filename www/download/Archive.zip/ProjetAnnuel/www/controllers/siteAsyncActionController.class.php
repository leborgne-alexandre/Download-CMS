<?php

//declare (strict_types=1);

/******
 *******
	Controller des requetes ajax du site
 *******
 ******/

class siteAsyncActionController
{
   
   /**
	 * 
	 * 
	 * 
	 * Ajoute une annonce sur le site
	 * 
	 */

	public function addAnnounceAction(){

		$usr = new Siteusers();
		$isValid = $usr->checkIfUserConnected();

		//if($isValid){
			$annonces = new Annonces();
			$annonces->setDescription($_GET["description"]);
			$annonces->setTitre($_GET["title"]);
			$annonces->setTel($_GET["phone"]);
			$annonces->setNbJours($_GET["day"]);
			$annonces->setNbHeures($_GET["hours"]);
			$annonces->setPrix($_GET["price"]);
			$annonces->setHeurePrestation($_GET["prestation"]);
			$annonces->setDate($_GET["date"]);
			$annonces->setLieu($_GET["place"]);
			$annonces->setDepartement($_GET["state"]);
			$annonces->setCompetences($_GET["skill"]);
			$annonces->setCharge($_GET["charge"]);
			$errorTab = $annonces->insertAnnonces();
			if(empty($errorTab)){
				echo('<div class="validate">Votre annonce a été créée. Elle sera validé et accessible dans les plus bref délais</div>');
				$pages = new Pages();
				$pages->generateSitemap();
				$notifications = new Notifications(); 
				$notifications->setContain("L'annonce \"<a href='/zz-admin/website?page=".$annonces->getSlug()."'>".$annonces->getTitre()."</a>\" a été créée. Valider l'annonce ?");
				$notifications->setDate(date("d-m-Y H:i"));
				$notifications->setSlug($annonces->getSlug());
				$notifications->setTypeNotification(NEW_ANNOUNCE_NOTIFICATION_TYPE);
				$notifications->createNotif();
				return;
			}
			$htmlErrors = '';
			foreach($errorTab as $key => $value){
				$htmlErrors .='<div class="error">'.$value.'</div>';
			}
			echo ($htmlErrors);
		/*}else{
			header('Location: /log_in');
		}*/
  }
}