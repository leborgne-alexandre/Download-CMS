<?php

//declare (strict_types=1);

class CheckUser{

	public function __construct(){

	}
}