<?php

//declare (strict_types=1);

class ConfigBdd
{

	/**********************************************
	 **** FORMULAIRE DE CONFIGURATON DE LA BDD ****
	 **********************************************/

	/**
	 * 
	 *	fomulaire de configuration de la bdd
	 * 
	 *	@return array formulaire
	 * 
	 */

	public function getConfigBddForm()
	{

		return [
					"config" => [ 
						"method"=>"POST", 
						"action"=>Routing::getSlug("Users", "validateConfigBdd"),
						"class"=>"form-config-bdd", 
						"id"=>"form-config-bdd",
						"submit"=>"Confirmer la configuration de la BDD"
						],

					"data"=>[

								"name-bdd"=>[
										"type"=>"text",
										"placeholder"=>"Nom de la base de données PostgresSQL",
										"id"=>"name-bdd",
										"name"=>"name-bdd",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"Le nom de la base de donnée est incorrect"
									],

								"id"=>[
										"type"=>"text",
										"placeholder"=>"Identifiant PostgresSQL",
										"id"=>"id",
										"name"=>"id",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"L'identifiant n'est pas valide"
									],

								"password-bdd"=>[
										"type"=>"text",
										"placeholder"=>"Mot de passe PostgresSQL",
										"id"=>"password",
										"name"=>"password",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"Le mot de passe n'est pas valide"
									],

								"host"=>[
										"type"=>"text",
										"placeholder"=>"Hôte de la base de données PostgresSQL",
										"id"=>"host",
										"name"=>"host",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"L'hôte n'est pas valide"
									],

								"port"=>[
										"type"=>"text",
										"placeholder"=>"Port de la base de données PostgresSQL",
										"id"=>"port",
										"name"=>"port",
										"class"=>"form-elements",
										"required"=>true,
										"error"=>"Le port doit comporter uniquement des numéros"
									],

								"domain-name"=>[
										"type"=>"text",
										"placeholder"=>"Nom de domaine du site",
										"id"=>"domain-name",
										"name"=>"domain-name",
										"value"=>"http://exemple.com/",
										"class"=>"form-elements",
										"required"=>true,
										"error"=>"Le nom de domaine n'est pas valide. Il doit commencer par http:// ou https:// et doit se finir par /"
									],

								"title-create-superadmin"=>[
										"class"=>"title-config",
										"name"=>"title-create-superadmin",
										"value"=>"Title create SuperAdmin"
									],

								"username"=>[
										"type"=>"text",
										"placeholder"=>"Entrer un nom d'utilisateur",
										"id"=>"username",
										"name"=>"username",
										"class"=>"form-elements",
										"maxlength"=>50,
										"required"=>true,
										"error"=>"Le nom d'utilisateur doit faire moins de 50 caractères"
									],
	
								"mail"=>[
										"type"=>"email",
										"placeholder"=>"Entrer une adresse eMail",
										"id"=>"mail",
										"name"=>"mail",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"L'eMail est invalide ou doit faire moins de 100 caractères"
								],

								"password"=>[
										"type"=>"password",
										"placeholder"=>"Entrer un mot de passe",
										"id"=>"password",
										"name"=>"password",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"Le mot de passe doit contenir au moins 7 caractères / 1 majuscule / 1 numéro"
								],

								"confirm-password"=>[
										"type"=>"password",
										"placeholder"=>"Confirmer le mot de passe",
										"id"=>"confirm-password",
										"name"=>"confirm-password",
										"class"=>"form-elements",
										"maxlength"=>100,
										"required"=>true,
										"confirm"=>"password",
										"error"=>"Les mots de passe ne sont pas identiques"
								]
					
							]
				];


	}
}
