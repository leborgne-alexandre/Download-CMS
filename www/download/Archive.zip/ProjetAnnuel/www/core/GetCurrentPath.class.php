<?php

//declare (strict_types=1);

class GetCurrentPath{

    public $path;

	/**
     * 
     *  recupere le chemin actuellement en url
     * 
     *  @return string chemin en url
     * 
     * 
     */

	public function __construct(){

        $path = $_SERVER["REQUEST_URI"];
        $pathExploded = explode("?", $path);
        $path = $pathExploded[0];
    
        $this->path = $path;
    }
}