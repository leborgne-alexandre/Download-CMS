<?php

//declare (strict_types=1);

class GetCurrentSlug{
	
	public $slug;

	/**
     * 
     *  recupere le slug actuellement en url. Si le slug n est pas connu alors celui ci est considéré comme "error404"
     * 
     *  @param bool $pageEdition si on souhaite le slug du site ou alors le slug de la page du site en edition
     * 
     * 
     */

	public function __construct($pageEdition = FALSE){

		if(!$pageEdition){
			
			$slug = $_SERVER["REQUEST_URI"];
			$slugExploded = explode("?", $slug);
			$slug = $slugExploded[0];
			$slugExploded2 = explode("/", $slug);
			$slug = $slugExploded2[1];

			if($slug == "zz-config-cms"){
				$this->slug = "zz-config-cms";
				return;
			}

			$pages = new Pages();
			$pageExists = $pages->checkIfSlugExists($slug);
			$annonces = new Annonces();
			$announceExists = $annonces->checkIfSlugExists($slug);
		}else{
			$slug = explode("page=", $_SERVER["REQUEST_URI"])[1];
			$pages = new Pages();
			$pageExists = $pages->checkIfSlugExists($slug, TRUE); // true signifie que l on verifie le slug d une page a editer
			$annonces = new Annonces();
			$announceExists = $annonces->checkIfSlugExists($slug, TRUE);
		}

		if($slug == "zz-config-cms"){
			$this->slug = "zz-config-cms";
			return;
		}
		
		if(($pageExists && !is_string($pageExists)) || $announceExists)
			$this->slug = $slug;
		elseif(is_string($pageExists))
			$this->slug = "maintenance";
		elseif(empty($slug))
			$this->slug = "";
		else
			$this->slug = "error404";

	}

}