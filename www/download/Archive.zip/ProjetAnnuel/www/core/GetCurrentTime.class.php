<?php

//declare (strict_types=1);

class GetCurrentTime{
	
    public $currentTime;
    public $format = "Y-m-d H:i:s";

	/**
     * 
     *  recupere la date et l'heure actuelle du serveur au format timestamp
     * 
     * 
     */

	public function __construct(){

        $time = date($this->format);
        $this->currentTime = $time;

    }

}