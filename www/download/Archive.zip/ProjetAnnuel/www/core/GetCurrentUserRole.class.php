<?php

//declare (strict_types=1);

class GetCurrentUserRole extends ConnectBDD{

	/**
	 * 
	 * recuperation du role de l utilisateur des le chargement de la page
	 * 
	 * 
	 */

	public function __construct(){

		if(isset($_SESSION['username']))
			self::getRoleAdminOrSuperAdmin();

		if(isset($_SESSION['prenom']))
			self::getRoleUserOrAdministrator();

	}

	/**
	 * 
	 * en fonction des variables de session on cherche le role (admin ou superadmin)
	 * 
	 * 
	 */

	public function getRoleAdminOrSuperAdmin(){

		$user = new Usr();
		$role = $user->getRole();

		$_SESSION['role_admin_or_superadmin'] = $role;

	}

	/**
	 * 
	 * en fonction des variables de session on cherche le role (user ou moderateur)
	 * 
	 * 
	 */

	public function getRoleUserOrAdministrator(){

		$siteUsers = new Siteusers();
		$role = $siteUsers->getRole();

		$_SESSION['role_user_or_moderator'] = $role;

	}

}