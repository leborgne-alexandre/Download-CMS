<?php

//declare (strict_types=1);

class GlobalFunctions extends ConnectBDD{


}