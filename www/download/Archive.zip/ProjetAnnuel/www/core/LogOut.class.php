<?php

//declare (strict_types=1);

class LogOut{

	/**
	 * 
	 * destruction des variables de session et des cookies pour la deconnexion
	 * 
	 * 
	 */

	public function destroySession(){

		session_start();

		if(isset($_COOKIE['token_f_kc']))
			setcookie('token_f_kc', '', time() - 3600, '/');

		if(isset($_COOKIE['token_b_kc']))
			setcookie('token_b_kc', '', time() - 3600, '/');

		$_SESSION = array();

		if (ini_get("session.use_cookies")) {
		    $params = session_get_cookie_params();
		    setcookie(session_name(), '', time() - 42000,
		        $params["path"], $params["domain"],
		        $params["secure"], $params["httponly"]
		    );
		}

		session_destroy();

	}

}