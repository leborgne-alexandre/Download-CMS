<?php
class Parameters{

    /**
     * 
     * 
     * Enregistrement du nom du favicon (.ico) dans le fichier faviconName
     * 
     */
    public function faviconSave($fileName){
        $fileToEdit = fopen('faviconName.php', 'r+');
        fputs($fileToEdit, $fileName. '
        <?php //nouveau favicon ci-dessus.........................');
        fclose($fileToEdit);
    }

    /**
     * 
     * 
     * Remplace le nom du favicon dans le head
     * 
     */
    public function getFaviconName(){
        $fileToEdit = fopen('faviconName.php', 'r+');
        $fileNameToReturn = fgets($fileToEdit);
        fseek($fileToEdit, 0);
        fclose($fileToEdit);
        
        return $fileNameToReturn;
    }

}