<?php

//declare (strict_types=1);

class Routing extends ConnectBDD{

	public static $routeFile = "slugs.yml";

	/**
	 * 
	 * recherche de page correspondant au slug dans les tables : pages / annonces et dans le fichier slugs.yml. Si aucune page trouvé on redirige vers page 404
	 * 
	 * @param string $slug	slug dans l url
	 * 
	 * @return array nom du controller / nom de l action / chemin du fichier controller
	 * 
	 * 
	 */

	public static function getRoute($slug){
		//récuperer toutes les routes dans le fichier yml

		$routes = yaml_parse_file(self::$routeFile);
		if(isset($routes[$slug])){
			if(empty($routes[$slug]["controller"]) || empty($routes[$slug]["action"])){
				die("Il y a une erreur dans le fichier routes.yml");
			}
			$c = $routes[$slug]["controller"]."Controller";
			$a = $routes[$slug]["action"]."Action";
			$cPath = "controllers/".$c.".class.php";

			return ["c"=>$c, "a"=>$a,"cPath"=>$cPath];

		}else{
			$currentSlug = new GetCurrentSlug();
			$slug = $currentSlug->slug;

			self::launchStats($slug);

			if(empty($slug)){
				header('Location: /home');
			}else{
					
				$fileConfDb = "conf-db.php";
				if(file_exists($fileConfDb)){

					$slug = explode("/", $slug);
					$slug = implode($slug);

					$pageRouteInDb = self::getPageSlugInDb($slug);
					
					/*if(!empty($pageRouteInDb))
						$pageRouteInDb = (String)$pageRouteInDb[0]["slug"];
					else
						$pageRouteInDb = NULL;*/

					// si route present dans table Page alors return
					if($pageRouteInDb == $slug && $pageRouteInDb != "header" && $pageRouteInDb != "footer"){

						$c = "DbPagesController";
						$a = "dbPagesAction";
						$cPath = "controllers/".$c.".class.php";

						return ["c"=>$c, "a"=>$a,"cPath"=>$cPath];
					}

					$announceRouteInDb = self::getAnnounceSlugInDb($slug);

					if(!empty($announceRouteInDb))
						$announceRouteInDb = (String)$announceRouteInDb[0]["slug"];
					else
						$announceRouteInDb = NULL;
					// SINON si route present dans table Annonces alors return
					if($announceRouteInDb == $slug){

						$c = "DbPagesController";
						$a = "dbPagesAction";
						$cPath = "controllers/".$c.".class.php";

						return ["c"=>$c, "a"=>$a,"cPath"=>$cPath];
					}

					$errorRouteInDb = self::getPageSlugInDb("error404");

					$errorRouteInDb = (String)$errorRouteInDb;
					// SI AUCUNE ROUTE TROUVER return page erreur
					if($errorRouteInDb == "error404"){

						$c = "DbPagesController";
						$a = "dbPagesAction";
						$cPath = "controllers/".$c.".class.php";

						return ["c"=>$c, "a"=>$a,"cPath"=>$cPath];
					}
				}
			}
		}
	}

	/**
	 * 
	 * recuperation des slugs dans le fichier slugs.yml
	 * 
	 * @param string $c	controller dans le fichier yml
	 * @param string $a action dans le fichier yml
	 * 
	 * @return string si slug trouve alors retourne slug
	 * @return null si slug non trouvé
	 * 
	 * 
	 */

	public static function getSlug($c, $a){
		$routes = yaml_parse_file(self::$routeFile);

		foreach ($routes as $slug => $cAndA) {
			
			if( !empty($cAndA["controller"]) && 
				!empty($cAndA["action"]) && 
				$cAndA["controller"] == $c &&
				$cAndA["action"] == $a){
					return $slug;
				}

		}

		return null;

	}

	/**
	 * 
	 * récuperation du slug dans la table pages (pour verifier si slug actuel present dans la table pages)
	 * 
	 * @param string $slug slug acuellement en url
	 * 
	 * @return array slug si trouvé OU array vide si non trouvé
	 * 
	 * 
	 */

	public static function getPageSlugInDb($slug){

		$pages = new Pages();
		return $pages->getElementsFromBdd("slug", $slug);
		
	}

	/**
	 * 
	 * récuperation du slug dans la table annonces (pour verifier si slug actuel present dans la table annonces)
	 * 
	 * @param string $slug slug acuellement en url
	 * 
	 * @return array slug si trouvé OU array vide si non trouvé
	 * 
	 * 
	 */

	public static function getAnnounceSlugInDb($slug){

		$annonces = new Annonces();
		return $annonces->getSlugInDb($slug);
		
	}

	/**
	 * 
	 * lance l action des statitistiques
	 * 
	 * @param string $slug slug de la page
	 * 
	 * 
	 */

	 public static function launchStats($slug){
		$stats_count_user_per_day = new Stats_visited_pages();
		$stats_count_user_per_day->start($slug);
	 }

}
