<?php

//declare (strict_types=1);

class StylesImport extends ConnectBDD{

	public $mainCSS;
	public $containText;

	/**
	 * 
	 * recuperation des styles de la page au chargement
	 * 
	 * 
	 */

	public function __construct($slug = NULL, $edition = FALSE){

		if($slug == NULL){
			$getCurrentSlug = new GetCurrentSlug();
			$slug = $getCurrentSlug->slug;
		
			if($slug != "header" && $slug != "footer"){
				$styles = self::getStyles($slug);
				$stylesHover = self::getStylesHover($slug);
			}else{
				$styles = self::getStyles("error404");
				$stylesHover = self::getStylesHover("error404");
			}

		}else{
			$pages = new Pages();
			$announces = new Annonces();

			if(!$edition)
				$isSlugExists = $pages->checkIfSlugExists($slug);
			else
				$isSlugExists = $pages->checkIfSlugExists($slug, TRUE); // true signifie qu il s agit d une page en edition

			$isSlugExistsInAnnounces = $announces->checkIfSlugExists($slug);

			if($isSlugExists || $isSlugExistsInAnnounces){
				if(!$isSlugExists){
					$styles = self::getStyles($slug, TRUE); // true signifie qu il s agit d une annonce
					$stylesHover = self::getStylesHover($slug, TRUE);
				}else{
					$styles = self::getStyles($slug);
					$stylesHover = self::getStylesHover($slug);
				}
			}else{
				$styles = self::getStyles("error404");
				$stylesHover = self::getStylesHover("error404");
			}
		}

		self::setStylesToSite($styles, $stylesHover);
	}

	/**
	 * 
	 * recuperation des styles dans la table styles
	 * 
	 * @param string $slug 	slug de la page actuel
	 * 
	 * @return array styles
	 * 
	 * 
	 */

	public function getStyles($slug, $announce = FALSE){

		$styles = new Styles();

		if(!$announce)
			return $styles->getStylesAndStylesHoverFromDb($slug);

		return $styles->getStylesAndStylesHoverFromDb($slug, TRUE); // true signifie qu il s agit d une annonce
	}

	/**
	 * 
	 * recuperation des styles en hover sur un element dans la table styles_hover
	 * 
	 * @param string $slug 	slug de la page actuel
	 * 
	 * @return array styles en hover
	 * 
	 * 
	 */

	public function getStylesHover($slug, $announce = FALSE){

		$stylesHover = new Styles_hover();

		if(!$announce)
			return $stylesHover->getStylesAndStylesHoverFromDb($slug);

		return $stylesHover->getStylesAndStylesHoverFromDb($slug, TRUE); // true signifie qu il s agit d une annonce
	}

	/**
	 * 
	 * convertit les styles non hover en css valide
	 * 
	 * @param array $styles tableau des styles
	 * 
	 * @return string $cssPage css valide
	 * 
	 * 
	 * 
	 */

	public function setNoHoverStyles($styles){

		$cssPage = "";
		$notRight = ["id", "id_element", "id_page", "contenu", "placeholder", "nom_element", "type", "link", "edit_text_enable"];

		foreach($styles as $key => $value){

			$css = "#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."{";

			foreach($styles[$key] as $key2 => $value){

				if(!in_array($key2, $notRight) && !empty($value)){
					
					$css .= $key2.":".str_replace("&sbquo;", ",", $value).";";

				}

			}

			$css .= "}";

			$cssPage .= $css;

		}

		return $cssPage;
	}

	/**
	 * 
	 * convertit les styles en hover en css valide
	 * 
	 * @param array $styles tableau des styles
	 * 
	 * @return string $cssHoverPage css valide
	 * 
	 * 
	 * 
	 */

	public function setHoverStyles($stylesHover){

		$cssHoverPage = "";
		$notRight = ["id", "id_element", "id_page", "nom_element", "type", "link", "contenu", "edit_text_enable"];

		foreach($stylesHover as $key => $value){

			$css = "#element-".$stylesHover[$key]["nom_element"]."-".$stylesHover[$key]["id_element"].":hover{";

			foreach($stylesHover[$key] as $key2 => $value){

				if(!in_array($key2, $notRight) && !empty($value)){
					
					$css .= $key2.":".$value.";";

				}

			}

			$css .= "}";

			$cssHoverPage .= $css;

		}

		return $cssHoverPage;
	}

	/**
	 * 
	 * cree le script pour afficher le texte d un element
	 * 
	 * @param array $styles tableau des styles
	 * 
	 * @return string $contain script valide
	 * 
	 * 
	 * 
	 */

	public function setTextContain($styles, $key){

		$contain = "$('#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."').html(\"";

		foreach($styles[$key] as $key2 => $value){

			if($key2 == "contenu" && !empty($value)){
				
				$contain .= $value;

			}

		}

		$contain .= "\");";

		$contain .= "$('#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."').val(\"";

		foreach($styles[$key] as $key2 => $value){

			if($key2 == "contenu" && !empty($value)){
				
				$contain .= $value;

			}

		}

		$contain .= "\");";

		return $contain;

	}

	/**
	 * 
	 * cree le script pour afficher le placeholder d un element
	 * 
	 * @param array $styles tableau des styles
	 * 
	 * @return string $contain script valide
	 * 
	 * 
	 * 
	 */

	public function setPlaceholderContain($styles, $key){

		$placeholder = "$('#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."').attr(\"placeholder\", \"";

		foreach($styles[$key] as $key2 => $value){

			if($key2 == "placeholder" && !empty($value)){
				
				$placeholder .= $value;

			}

		}

		$placeholder .= "\");";

		return $placeholder;

	}

	/**
	 * 
	 * convertit les textes en script
	 * 
	 * @param array $styles tableau des styles
	 * 
	 * @return string $text script valide
	 * 
	 * 
	 * 
	 */

	public function setContain($styles){

		$text = "";

		foreach($styles as $key => $value){

			if(!empty($styles[$key]["contenu"])){
				$text .= $this->setTextContain($styles, $key);
			}

			if(!empty($styles[$key]["placeholder"])){
				$text .= $this->setPlaceholderContain($styles, $key);
			}

		}

		return $text;
	}

	/**
	 * 
	 * convertit les liens en script
	 * 
	 * @param array $styles tableau des styles (dont les liens)
	 * 
	 * @return string $links script valide
	 * 
	 * 
	 * 
	 */

	public function setLinks($styles){

		$links = "";

		foreach($styles as $key => $value){

			if(!empty($styles[$key]["link"])){

				if($styles[$key]["type"] == "link")
					$links .= "$('#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."').attr(\"href\", \"";
				elseif($styles[$key]["type"] == "video" || $styles[$key]["type"] == "image")
					$links .= "$('#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."').attr(\"src\", \"";

				foreach($styles[$key] as $key2 => $value){

					if($key2 == "link" && !empty($value)){
						
						$links .= $value;
						$pathToMedia = $value;

					}

				}

				$links .= "\");";

				if($styles[$key]["type"] == "image"){
					$media = new Media();
					$title = $media->getMediaTitleWithPath($pathToMedia);
					$links .= "$('#element-".$styles[$key]["nom_element"]."-".$styles[$key]["id_element"]."').attr(\"alt\", \"".$title."\");";
				}

			}

		}

		return $links;
	}

	/**
	 * 
	 * convertit les tableaux des styles et styles_hover en syntaxe css valide. Resultat stocké dans la variable $mainCSS
	 * 
	 * @param array $styles tableau des styles
	 * @param array $stylesHover tableau des styles en hover
	 * 
	 * 
	 * 
	 */

	public function setStylesToSite($styles, $stylesHover){

		$this->mainCSS = $this->setNoHoverStyles($styles);
		$this->mainCSS .= $this->setHoverStyles($stylesHover);
		$this->containText = $this->setContain($styles);
		$this->containText .= $this->setLinks($styles);

	}

}