<?php

//declare (strict_types=1);

class Token{

	public $token;

	/**
	 * 
	 * creation d un token aleatoire. Valeur stocké dans la variable $token
	 * 
	 * 
	 */

	public function __construct(){

		$date = new DateTime();
		$timestamp = $date->getTimestamp();

		$token_value = md5(mt_rand()."lkuyait9847pokopiuçy_p".$timestamp.rand()."/897iuu");
		$token_value=substr($token_value, rand(-28, -23), rand(-1, -5));
		$token_value = hash('sha256', "ilfyrs4566iklfy-èç_(".mt_rand().$timestamp."gbivutjfiokgjuyàà-è'èçoç_").$token_value;

		$this->token = $token_value;

	}
}