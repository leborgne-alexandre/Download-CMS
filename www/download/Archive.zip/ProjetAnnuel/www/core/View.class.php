<?php

//declare (strict_types=1);

class View extends ConnectBDD{

	private $v;
	private $t;
	private $data = [];
	private $currentSlug;

	/**
	 * 
	 * attribue une view en fonction du template (back, front ou inCMS) inCMS signifie que la page est en edition 
	 * et que l on ne desire donc pas recuperer certaines infos correspondant au back ou au front (head par exemple)
	 * 
	 * @param string $v	view demandé
	 * @param string $t template demandé (back, front ou inCMS)
	 * 
	 * 
	 */

	public function __construct($v, $t="back"){
		if($t == "front")
			$this->setViewFront($v);
		elseif($t == "back"){
			$this->setViewBack($v);
		}

		new GetCurrentUserRole();

		$getSlug = new GetCurrentSlug();
		$this->currentSlug = $getSlug->slug;

		if($t != "inCMS")
			$this->setTemplate($t);
	}

	/**
	 * 
	 * attribution de la view coté back (cms). Stockage de la view dans $v
	 * 
	 * @param string $v	view demandé
	 * 
	 * 
	 */

	public function setViewBack($v){
		$viewPath = "views/back/".$v.".view.php";
		if( file_exists($viewPath)){
			$this->v=$viewPath;
		}else{
			die("Attention le fichier view n'existe pas ".$viewPath);
		}
	}

	/**
	 * 
	 * attribution de la view coté front (site). Stockage de la view dans $v
	 * 
	 * @param string $v	view demandé
	 * 
	 * 
	 */

	public function setViewFront($v){
		$viewPath = "views/front/".$v.".view.php";
		if( file_exists($viewPath)){
			$this->v=$viewPath;
		}else{
			die("Attention le fichier view n'existe pas ".$viewPath);
		}
	}

	/**
	 * 
	 * attribution du template. Stockage du template dans $t
	 * 
	 * @param string $t	template demandé
	 * 
	 * 
	 */

	public function setTemplate($t){
	
		$templatePath = "views/templates/".$t.".tpl.php";
		if( file_exists($templatePath)){
			$this->t=$templatePath;
		}else{
			die("Attention le fichier template n'existe pas ".$templatePath);
		}

	}

	/**
	 * 
	 * ajout d un modal en back
	 * 
	 * @param string $modal	nom du modal
	 * @param array $config form du modal
	 * 
	 * 
	 */

	public function addModalBack($modal, $config = NULL){
		//form.mod.php
		$modalPath = "views/back/modals/".$modal.".mod.php";
		if( file_exists($modalPath)){
			include $modalPath;
		}else{
			die("Attention le fichier modal n'existe pas ".$modalPathCms);
		}
	}

	/**
	 * 
	 * ajout d un modal en front
	 * 
	 * @param string $modal	nom du modal
	 * @param array $config form du modal
	 * 
	 * 
	 */

	public function addModalFront($modal, $config = NULL){
		//form.mod.php
		$modalPath = "views/front/modals/".$modal.".mod.php";
		if( file_exists($modalPath)){
			include $modalPath;
		}else{
			die("Attention le fichier modal n'existe pas ".$modalPathCms);
		}
	}

	public function assign($key, $value){
		$this->data[$key]=$value;
	}

	/**
	 * 
	 * recupere le html correspondant a une page en bdd
	 * 
	 * @param string $slug	page demandé. Si null alors recuperation du slug actuel
	 * 
	 * @return string $getHtmlFromBdd	html recuperé en bdd
	 * 
	 * 
	 */

	public function getHtmlFromDb($slug = NULL, $edition = FALSE){

		$pages = new Pages();
		$annonces = new Annonces();

		if($slug == NULL){

			$slugExistsInPagesList = $pages->checkIfSlugExists($this->currentSlug);
			$slugExistsInAnnounceList = $annonces->checkIfSlugExists($this->currentSlug);

			if($slugExistsInPagesList){
				if($this->currentSlug != "header" && $this->currentSlug != "footer"){
					$getHtmlFromBdd = $pages->getElementsFromBdd("contenu", $this->currentSlug);
				}else{
					$getHtmlFromBdd = $pages->getElementsFromBdd("contenu", "error404");
				}
			}elseif($slugExistsInAnnounceList){
				$getHtmlFromBdd = $annonces->getElementsFromBdd("*", $this->currentSlug);
			}else{
				$getHtmlFromBdd = $pages->getElementsFromBdd("contenu", "error404");
			}
		}else{

			if(!$edition){
				$slugExistsInPagesList = $pages->checkIfSlugExists($slug);
				$slugExistsInAnnounceList = $annonces->checkIfSlugExists($slug);
			}else{
				$slugExistsInPagesList = $pages->checkIfSlugExists($slug, TRUE);
				$slugExistsInAnnounceList = $annonces->checkIfSlugExists($slug, TRUE);
			}

			if($slugExistsInPagesList)
				$getHtmlFromBdd = $pages->getElementsFromBdd("contenu", $slug);
			elseif($slugExistsInAnnounceList)
				$getHtmlFromBdd = $annonces->getElementsFromBdd("*", $slug);
			else
				$getHtmlFromBdd = $pages->getElementsFromBdd("contenu", "error404");
		}

		return $getHtmlFromBdd;
	}

	/**
	 * 
	 * recupere le html du header
	 * 
	 * @return string $getHeaderFromBdd	html recuperé en bdd
	 * 
	 * 
	 */

	public function getHeaderFromDb(){

		$pages = new Pages();
		$getHeaderFromBdd = $pages->getElementsFromBdd("contenu", "header");

		return $getHeaderFromBdd;
	}

	/**
	 * 
	 * recupere le html du footer
	 * 
	 * @return string $getFooterFromBdd	html recuperé en bdd
	 * 
	 * 
	 */

	public function getFooterFromDb(){

		$pages = new Pages();
		$getFooterFromBdd = $pages->getElementsFromBdd("contenu", "footer");

		return $getFooterFromBdd;
	}

	/**
	 * 
	 * recupere le titre de la page (<title>)
	 * 
	 * @return string $getTitleFromBdd	titre recuperé en bdd
	 * 
	 * 
	 */

	public function getPageTitleFromDb(){

		$pages = new Pages();
		$annonces = new Annonces();

			$slugExistsInPagesList = $pages->checkIfSlugExists($this->currentSlug);
			$slugExistsInAnnounceList = $annonces->checkIfSlugExists($this->currentSlug);

			if($slugExistsInPagesList){
				if($this->currentSlug != "header" && $this->currentSlug != "footer"){
					$getTitleFromBdd = $pages->getElementsFromBdd("title", $this->currentSlug);
				}else{
					$getTitleFromBdd = $pages->getElementsFromBdd("title", "error404");
				}
			}else{
				$getTitleFromBdd = $annonces->getElementsFromBdd("title", $this->currentSlug);
			}
		
			return $getTitleFromBdd;

	}

	public function __destruct(){
		extract($this->data);
		if($this->t != NULL)
			include $this->t;
	}
}



