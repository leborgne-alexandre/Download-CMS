<?php
//declare (strict_types=1);

class Annonces extends ConnectBDD{
	use global_security;
	use page_announce;
	
	public $id_siteusers = 1;
	public $slug;
	public $description;
	public $now_date;
	public $titre;
	public $tel;
	public $nb_jours;
	public $nb_heures;
	public $prix;
	public $heure_prestation;
	public $date;
	public $lieu;
	public $departement;
	public $competences;
	public $charge;
	public $is_verified = 0;

	
	
    public function __construct(){
        parent::__construct();
    }

    public function setIdSiteUsers($id){
        $this->id_siteusers = trim((int)$id);
    }
    public function getIdSiteUsers(){
        return $this->id_siteusers;
    }
    public function setSlug($string){
        $slug = new ConvertStringToSlug(trim($string));
        $this->slug = $slug->slug;
    }
    public function getSlug(){
        return $this->slug;
    }

    public function getDescription(){
        return $this->description;
    }
    public function setDescription($description){
        $this->description = trim($description);
    } 

    public function getTitre(){
        return $this->titre;
    }
    public function setTitre($titre){
        $this->titre = trim($titre);
        $this->slug = strtolower(str_replace(' ','',$titre));
    } 

    public function getTel(){
        return $tel->tel;
    }
    public function setTel($tel){
        $this->tel = trim($tel);
    }

    public function getNbJours(){
        return $nb_jours->nb_jours;
    }
    public function setNbJours($nb_jours){
        $this->nb_jours = trim($nb_jours);
    }

    public function getNbHeures(){
        return $nbHeures->nbHeures;
    }
    public function setNbHeures($nb_heures){
        $this->nb_heures = trim($nb_heures);
    }

    public function getPrix(){
        return $prix->prix;
    }
    public function setPrix($prix){
        $this->prix = trim($prix);
    }

    public function getHeurePrestation(){
        return $heure_prestation->heure_prestation;
    }
    public function setHeurePrestation($heure_prestation){
        $this->heure_prestation = trim($heure_prestation);
    }

    public function getDate(){
        return $date->date;
    }
    public function setDate($date){
        $this->date = trim($date);
    }

    public function getLieu(){
        return $lieu->lieu;
    }
    public function setLieu($lieu){
        $this->lieu = trim($lieu);
    }

    public function getDepartement(){
        return $departement->departement;
    }
    public function setDepartement($departement){
        $this->departement = trim($departement);
    }

    public function getCompetences(){
        return $competences->competences;
    }
    public function setCompetences($competences){
        $this->competences = trim($competences);
    }

    public function getCharge(){
        return $charge->charge;
    }
    public function setCharge($charge){
        $this->charge = trim($charge);
    }
    
    public function insertAnnonces(){
        $time = new GetCurrentTime();
        $currentTime = $time->currentTime;
        $this->now_date = $currentTime;
        $verrif = new Annonces();
        $verrif = $this;
        $verrifError = $this->validatorAnnonce($verrif);
        
        if(empty($verrifError)){
            $this->insert();
            return;
        }
        return $verrifError;
    }
    
    public function validatorAnnonce($data){
        $minlen = 3;
        $maxlen = 50;
        $dataTel = preg_match("#[0-9]#", $data->tel);
        $dataVille = preg_match("#[0-9]#", $data->lieu);
        $dataSlug = preg_match("#^zz-*#",$data->slug);
        $dataTitle = preg_match("#^[a-zA-Z0-9\sàçéèêïî-]+$#",$data->titre);
        $time = new GetCurrentTime();
        $currentTime = $time->currentTime;
        $checkError = [];
        $select = array("slug");
        $where = array("slug = ?"=>$data->slug);
        $checkSlug = $this->select($select,$where);


        // check slug
        if(!empty($checkSlug) || !empty($dataSlug)){
            array_push($checkError,'Ce titre est déjà utilisé');
        }

        //check desc
        if(empty($data->description)===true){
            array_push($checkError,'La description est vide');
        }
        
        
        //check titre

        if(strlen($data->titre) > $maxlen ){
            array_push($checkError,'Votre titre est trop long');
        };
        if(strlen($data->titre) < $minlen || empty($data->titre)){
            array_push($checkError,'Votre titre est trop court ou vide');
        };

        if(empty($dataTitle)){
            array_push($checkError,'Votre titre ne doit pas contenir de caractères spéciaux');
        }  
        
        //check slug 
        if($dataSlug === true){
            array_push($checkError,'Cette annonce existe déja');
        }

        //check telephone
        if(!$dataTel){
            array_push($checkError,'Le numéro de téléphone n\'est pas bon');
        };
        if(empty($data->tel)===true){
            array_push($checkError,'Le numero de telephone est vide');
        }
        if(strlen($data->tel) != 10){
            array_push($checkError,'Votre numero de telephone doit etre composé de 10 chiffres');
        }
        //check price
        if(empty($data->prix)===true){
            array_push($checkError,'Le prix est vide');
            $flagError = true;
        }

        //check prestation
        if(empty($data->heure_prestation)===true){
            array_push($checkError,'La selection d\'heure ou prestation est vide');
            $flagError = true;
        }

        //check date
        if(empty($data->date)===true){
            array_push($checkError,'La date est vide');
            $flagError = true;
        }

        
        $dataCurrentTime = new dateTime($currentTime);
        $dataDate = new dateTime($data->date." 00:00:00");
        $interval = $dataCurrentTime->diff($dataDate);
        $diffDate = $interval->format('%R%a');

        if($diffDate <= 0){
            array_push($checkError,'La date doit est superieur à la date actuel');
            $flagError = true;
        }

        //check num dans ville 
        if($dataVille === 1){
            array_push($checkError,'Le nom de la ville ne doit pas contenir de nombre');
            $flagError = true;
        }
        if(strlen($data->lieu) < 3 && $data->lieu !== 'Y'){
            array_push($checkError,'Le nom de la ville est trop court');
            $flagError = true;
        }
        if(empty($data->lieu)===true){
            array_push($checkError,'Le champs du lieu est vide');
            $flagError = true;
        }

        //check skill
        if(empty($data->competences)===true){
            array_push($checkError,'Les compétences sont vides');
            $flagError = true;
        }
        /*
        if(preg_match("#^[a-zA-Z0-9]+$#",$data->competences)===false){
            array_push($checkError,'Les compétences doivent contenir uniquement des lettres et des chiffres');
            $flagError = true;
        } 
        */
        return $checkError;
        
    }

    public static function notEmpty($string){
        return !empty(trim($string));
    } 
    /**
     * 
     * recupere toute les annonces
     * 
     * @param integer $offset offset de demarrage de la recherche en bdd
     * 
     * @return array $result si offset = 0
     * @return string $listAnnouncesOffset si offset > 0
     * 
     * 
     */
    
    public function getAllAnnounces($offset){

        $select = array("s.mail AS creator", "a.slug", "a.description", "a.titre", "a.date", "a.is_verified AS etat");
        $tag = "a";
        $innerJoin = array("siteusers s ON s.id = a.id_siteusers");
        $orderByLimitOffset = array("ORDER BY a.titre ASC LIMIT 20 OFFSET ".$offset."");

        $result = $this->select($select, null, $orderByLimitOffset, $innerJoin, $tag);
        
        $listAnnouncesOffset = "";

		if($offset > 0){

			$i = 0;
			foreach($result as $key => $value){
								
				$listAnnouncesOffset .= "<tr id='announce-".$i."'>
                <td>".htmlentities($value['titre'], ENT_QUOTES)."</td>
                <td>".htmlentities($value['creator'], ENT_QUOTES)."</td>
                <td>".$value['date']."</td>
                <td id='announce-state-".$i."'>".(($value['etat']) ? "Active" : "Non active")."</td>
                <td>
                <div>";
                if($value['etat']){
					$listAnnounces .= "<button data-slug='".htmlentities($value['slug'], ENT_QUOTES)."' id='activated-announce-in-page-list-".$i."' class='cta-activate-desactivate-announce-in-page-list' title='Désactiver l'annonce ?' value='desactivate' onclick='activateOrDesactivateAnnounce(this);'><i class='fas fa-battery-full cta-announce-activated'></i></button>";
				}else{
					$listAnnounces .= "<button data-slug='".htmlentities($value['slug'], ENT_QUOTES)."' id='no-activated-announce-in-page-list-".$i."' class='cta-activate-desactivate-announce-in-page-list' title='Activer l'annonce ?' value='activate' onclick='activateOrDesactivateAnnounce(this);'><i class='fas fa-battery-empty cta-announce-desactivated'></i></button>";
                }
                $listAnnounces .= "<a href='website?page=".htmlentities($value['slug'], ENT_QUOTES)."' title='Visualiser'><i class='fas fa-eye'></i></a>
                <a href='website?page=".htmlentities($value['slug'], ENT_QUOTES)."' title='Editer'><i class='fas fa-edit'></i></a>
                <button onclick='deleteInPageListAnnounceWhileSearch(this);' name='".htmlentities($value['slug'], ENT_QUOTES)."' id='delete-page-in-page-list' class='cta-delete-page-in-page-list' title='Supprimer' value='".$i."'><i class='fas fa-trash-alt'></i></button>
                </div>
                </td>
                </tr>";

				$i++;
							
			}

			return $listAnnouncesOffset;

		}

		return $result;

    }
    
     /**
     * 
     * supprime une annonce dans la liste des annonces
     * 
     * @param string $slug  slug de la page selectionne
     * 
     * 
     */
    public function deleteAnnounceInPageList($slug){
        $where = array('slug = ?'=>$slug);
        $this->delete($where);
    }
    /**
     * 
     * recupere le slug dans la table annonces dans la bdd
     * 
     * @param string $slug slug de la page selectionne
     * 
     * @return array slug trouvé ou null si aucun slug trouvé
     * 
     * 
     */
    
    public function getSlugInDb($slug){
        $select = array("slug");
        $where = array("slug = ?"=>$slug);
        return $this->select($select, $where);
    
    }

    /**
     * 
     * verifie si l user qui a créé l annonce est banni ou pas
     * 
     * @param string $slug slug de l annonce
     * 
     * @return boolean true si l user est banni
     * 
     * 
     * 
     * 
     */

     public function checkIfAnnounceCreatorIsBanned($slug){

        $select = array("s.is_banned");
        $tag = "a";
        $innerJoin = array("siteusers s ON s.id = a.id_siteusers");
        $where = array("a.slug = ?"=>$slug);

        $result = $this->select($select, $where, null, $innerJoin, $tag);

        if(@!$result[0]["is_banned"])
            return false;

        return true;

     }

    /**
     * 
     * verifie si le slug existe dans la table annonces
     * 
     * @param string $slug slug selectionné
     * 
     * @return bool true si slug existe et false si slug n existe pas
     * 
     * 
     */
    
    public function checkIfSlugExists($slug, $edition = FALSE){

        $select = array("slug");

        if(!$edition){
            $isBanned = $this->checkIfAnnounceCreatorIsBanned($slug);
            if($isBanned)
                return FALSE;
            $where = array("slug = ?"=>$slug, "AND is_verified = ?"=>"TRUE");
        }else{
            $where = array("slug = ?"=>$slug);
        }

        $result_get_slugs = $this->select($select, $where);
    
        if(!empty($result_get_slugs))
            return TRUE;
      
        return FALSE;
    }
    /**
     * 
     * recupere les champs d une annonce en bdd en fonction de la colonne selectionné
     * 
     * @param string $column colonne
     * @param string $slug slug de la page demandé
     * @param integer $templateId id du template (non utilisé)
     * 
     * @return string valeur du champ si champ non vide
     * @return null si champ vide
     * 
     * 
     */
    
    public function getPageElementsFromBdd($column, $slug, $templateId){
        $select = array($column);
        $where = array("slug = ?"=>$slug);
        $pageElements = $this->select($select, $where);
        if(!empty($pageElements))
            return implode($pageElements[0]);
        
        return;
    }
    /**
     * 
     * recupere toute les annonces
     * 
     * @param integer $offset offset de demarrage de la recherche en bdd
     * 
     * @return array $result si offset = 0
     * @return string $listAnnouncesOffset si offset > 0
     * 
     * 
     */
    
    public function getSearchedAnnounces($value){
        $select = array("s.mail AS creator", "a.slug", "a.description", "a.titre", "a.date", "a.is_verified AS etat");
        $tag = "a";
        $innerJoin = array("siteusers s ON s.id = a.id_siteusers");
        $where = array(
                        "(lower(a.titre) LIKE lower(?)"=>"".$value."%",
                        "OR lower(s.mail) LIKE lower(?))"=>"".$value."%"
                    );
        $orderBy = array("ORDER BY a.titre ASC");
        $result = $this->select($select, $where, $orderBy, $innerJoin, $tag);
        $listAnnounces = "";
        $i = 0;
        foreach($result as $key => $value){
                            
                $listAnnounces .= "<tr id='announce-".$i."'>
                <td>".htmlentities($value['titre'], ENT_QUOTES)."</td>
                <td>".htmlentities($value['creator'], ENT_QUOTES)."</td>
                <td>".$value['date']."</td>
                <td id='announce-state-".$i."'>".(($value['etat']) ? "Active" : "Non Active")."</td>
                <td>
                <div>";
                if($value['etat']){
					$listAnnounces .= "<button data-slug='".htmlentities($value['slug'], ENT_QUOTES)."' id='activated-announce-in-page-list-".$i."' class='cta-activate-desactivate-announce-in-page-list' title='Désactiver l'annonce ?' value='desactivate' onclick='activateOrDesactivateAnnounce(this);'><i class='fas fa-battery-full cta-announce-activated'></i></button>";
				}else{
					$listAnnounces .= "<button data-slug='".htmlentities($value['slug'], ENT_QUOTES)."' id='no-activated-announce-in-page-list-".$i."' class='cta-activate-desactivate-announce-in-page-list' title='Activer l'annonce ?' value='activate' onclick='activateOrDesactivateAnnounce(this);'><i class='fas fa-battery-empty cta-announce-desactivated'></i></button>";
                }
                $listAnnounces .= "<a href='website?page=".htmlentities($value['slug'], ENT_QUOTES)."' title='Visualiser'><i class='fas fa-eye'></i></a>
                <a href='website?page=".htmlentities($value['slug'], ENT_QUOTES)."' title='Editer'><i class='fas fa-edit'></i></a>
                <button onclick='deleteInPageListAnnounceWhileSearch(this);' name='".htmlentities($value['slug'], ENT_QUOTES)."' id='delete-page-in-page-list' class='cta-delete-page-in-page-list' title='Supprimer' value='".$i."'><i class='fas fa-trash-alt'></i></button>
                </div>
                </td>
                </tr>";
            $i++;
                        
        }
        return $listAnnounces;
    }
    
    /**
     * 
     * compte le nombre d annonces non supprimé
     * 
     * 
     * @return integer nombre d annonces non supprimé
     * 
     * 
     */
    public function countAllWebsiteAnnounces(){
        $select = array("COUNT(titre)");
        $result = $this->select($select);
        if(!empty($result))
            return $result[0]["count"];
        
        return 0;
    }

    /**
     * 
     * recupere le nombre d annonces ajouté par jour
     * 
     * @param string $date date du jour
     * 
     * @return integer nombre d annonces ajoutés
     * 
     * 
     * 
     */

     public function getAddedAnnouncesPerDay($date){

        $select = array("COUNT(DATE(now_date))");
        $where = array("DATE(now_date) = ?"=>$date);

        $result = $this->select($select, $where);

        if(!empty($result))
            return $result[0]["count"];

        return 0;
     }

     /**
      * 
      * Active une annonce
      *
      * @param string $slug slug de l'annonce
      *
      *
      */

      public function activateAnnounce($slug, $all = false){

        $set = array("is_verified"=>"TRUE");

        if(!$all){
            $where = array("slug = ?"=>$slug);
            $this->update($set, $where);
        }else{
            $this->update($set);
        }

      }

      /**
      * 
      * desactive une annonce
      *
      * @param string $slug slug de l'annonce
      *
      *
      */

      public function desactivateAnnounce($slug){

        $set = array("is_verified"=>"FALSE");
        $where = array("slug = ?"=>$slug);

        $this->update($set, $where);

      }

      /**
      * 
      * compte les annonces desactivées
      *
      * @return integer nombre d annonces desactivées
      *
      *
      */

      public function countDesactivateAnnounces(){

        $select = array("COUNT(id)");
        $where = array("is_verified = ?"=>"FALSE");

        $result = $this->select($select, $where);

        return $result[0]["count"];

      }

    /**
     * 
     * supprime les annonces d un user
     * 
     * @param integer $userId id de l user
     * 
     * 
     */

    public function deleteAnnounceFromUser($userId){

        $where = array("id_siteusers = ?"=>$userId);

        $this->delete($where);
    }
}
