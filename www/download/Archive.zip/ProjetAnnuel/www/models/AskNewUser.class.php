<?php

//declare (strict_types=1);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class AskNewUser extends ConnectBDD
{


	public $mail;
	public $key;

	public function setMail($mail)
	{
		$this->mail = trim($mail);
	}

	public function getMail()
	{
		return $this->mail;
	}

	public function setKey($key)
	{
		$this->key = trim(htmlspecialchars($key));
	}

	public function getKey()
	{
		return $this->key;
	}

	/**
	 * 
	 * envoi un mail de validation de compte apres inscription
	 * 
	 * @param string $mail mail de l utilisateur
	 * @param string $secretKey clé unique attribué a l utilisateur
	 * 
	 * 
	 * @return bool true si envoyé et false si erreur
	 * 
	 * 
	 */

	public function sendValidationSignUpMail($mail, $secretKey, $isFirstAdd = FALSE)
	{

		if (!empty($mail)) {

			if (!$isFirstAdd)
				$this->insert();

			$mailFryzzer = new PHPMailer(TRUE);
			$mailFryzzer->isSMTP();
			try {
				$mailFryzzer->Host = MAIL_FRYZZER_HOST;
				$mailFryzzer->Port = MAIL_FRYZZER_PORT;
				$mailFryzzer->SMTPAuth = true;
				$mailFryzzer->Username = MAIL_FRYZZER_USERNAME;
				$mailFryzzer->Password = MAIL_FRYZZER_PASSWORD;
				$mailFryzzer->SMTPSecure = MAIL_FRYZZER_SMTP_SECURE;
				$mailFryzzer->CharSet = MAIL_FRYZZER_CHARSET;

				// Expéditeur
				$mailFryzzer->SetFrom(MAIL_FRYZZER_SET_FROM_MAIL, MAIL_FRYZZER_SET_FROM_NAME);
				// Destinataire
				$mailFryzzer->AddAddress($mail);
				// Objet
				$mailFryzzer->Subject = 'Validation du compte';
				// message
				$mailFryzzer->MsgHTML("Cliquez sur le lien suivant pour valider la création de votre compte :<br><a href='" . HOST . "zz-validation_account_sign_up?u=" . $mail . "&k=" . $secretKey . "'>Valider la création du compte</a>");
				// envoi
				$isSend = $mailFryzzer->send();

				if ($isSend) {
					return TRUE;
				} else {
					return FALSE;
				}
			} catch (phpmailerException $e) {
				echo $e->errorMessage();
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		} else {
			header('Location: /');
		}
	}

	/**
	 * 
	 * envoi un mail a un admin pour accepté ou non l inscription d un nouveau admin
	 * 
	 * @param string $mailAdmin mail de l administrateur
	 * @param string $mailUser mail de l user qui demande
	 * 
	 * 
	 */

	public function sendMailAcceptOrNoSignUp($mailSuperAdmin, $mailUser, $secretKey)
	{

		if (!empty($mailSuperAdmin) && !empty($mailUser)) {

			$mailFryzzer = new PHPMailer(TRUE);
			$mailFryzzer->isSMTP();
			try {
				$mailFryzzer->Host = MAIL_FRYZZER_HOST;
				$mailFryzzer->Port = MAIL_FRYZZER_PORT;
				$mailFryzzer->SMTPAuth = true;
				$mailFryzzer->Username = MAIL_FRYZZER_USERNAME;
				$mailFryzzer->Password = MAIL_FRYZZER_PASSWORD;
				$mailFryzzer->SMTPSecure = MAIL_FRYZZER_SMTP_SECURE;
				$mailFryzzer->CharSet = MAIL_FRYZZER_CHARSET;

				// Expéditeur
				$mailFryzzer->SetFrom(MAIL_FRYZZER_SET_FROM_MAIL, MAIL_FRYZZER_SET_FROM_NAME);
				// Destinataire
				$mailFryzzer->AddAddress($mailSuperAdmin);
				// Objet
				$mailFryzzer->Subject = 'Ajouter un administrateur';
				// message
				$mailFryzzer->MsgHTML("L'utilisateur " . $mailUser . " a fait une demande pour devenir administrateur. Souhaitez-vous accepter ?<br><a href='" . HOST . "zz-send_autorised_sign_up?u=" . $mailUser . "&k=" . $secretKey . "'>Accepter</a><br><a href='" . HOST . "zz-refused_sign_up?u=" . $mailUser . "&k=" . $secretKey . "'>Refuser</a>");
				// envoi
				$isSend = $mailFryzzer->send();

				if ($isSend) {
					session_start();
					$_SESSION["mailSend"] = "mailSend";
				} else {
					session_start();
					$_SESSION["errorMailSend"] = "errorMailSend";
				}
			} catch (phpmailerException $e) {
				echo $e->errorMessage();
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/**
	 * 
	 * envoi un mail d acceptation d inscription en tant que admin
	 * 
	 * @param string $mail mail de l user
	 * @param string $key clé unique attribué a l user
	 * 
	 * 
	 */

	public function sendMailToAccessToSignUpPage($mail, $key)
	{

		if (!empty($mail) && !empty($key)) {

			$mailFryzzer = new PHPMailer(TRUE);
			$mailFryzzer->isSMTP();
			try {
				$mailFryzzer->Host = MAIL_FRYZZER_HOST;
				$mailFryzzer->Port = MAIL_FRYZZER_PORT;
				$mailFryzzer->SMTPAuth = true;
				$mailFryzzer->Username = MAIL_FRYZZER_USERNAME;
				$mailFryzzer->Password = MAIL_FRYZZER_PASSWORD;
				$mailFryzzer->SMTPSecure = MAIL_FRYZZER_SMTP_SECURE;
				$mailFryzzer->CharSet = MAIL_FRYZZER_CHARSET;

				// Expéditeur
				$mailFryzzer->SetFrom(MAIL_FRYZZER_SET_FROM_MAIL, MAIL_FRYZZER_SET_FROM_NAME);
				// Destinataire
				$mailFryzzer->AddAddress($mail);
				// Objet
				$mailFryzzer->Subject = 'Votre demande a été accepté';
				// message
				$mailFryzzer->MsgHTML("Votre demande d'inscription en tant qu'administrateur a été accepté. Pour vous inscrire cliquez sur le lien ci dessous :<br><a href='" . HOST . "zz-sign_up?u=" . $mail . "&k=" . $key . "'>S'inscrire en tant qu'administrateur</a>");
				// envoi
				$isSend = $mailFryzzer->send();

				if ($isSend) {
					session_start();
					$_SESSION["autorisedSignUpMailSent"] = $mail;
				} else {
					session_start();
					$_SESSION["errorAutorisedSignUpMailSent"] = "error";
				}
			} catch (phpmailerException $e) {
				echo $e->errorMessage();
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		} else {
			header('Location: /zz-sign_in');
		}
	}

	/**
	 * 
	 * envoi un mail de refus d inscription en tant que admin
	 * 
	 * @param string $mail mail de l user
	 * 
	 * 
	 */

	public function sendMailRefusedSignUp($mail)
	{
		// si mail valide on execute le script d envoi
		if (!empty($mail)) {

			$mailFryzzer = new PHPMailer(TRUE);
			$mailFryzzer->isSMTP();
			try {
				$mailFryzzer->Host = MAIL_FRYZZER_HOST;
				$mailFryzzer->Port = MAIL_FRYZZER_PORT;
				$mailFryzzer->SMTPAuth = true;
				$mailFryzzer->Username = MAIL_FRYZZER_USERNAME;
				$mailFryzzer->Password = MAIL_FRYZZER_PASSWORD;
				$mailFryzzer->SMTPSecure = MAIL_FRYZZER_SMTP_SECURE;
				$mailFryzzer->CharSet = MAIL_FRYZZER_CHARSET;

				// Expéditeur
				$mailFryzzer->SetFrom(MAIL_FRYZZER_SET_FROM_MAIL, MAIL_FRYZZER_SET_FROM_NAME);
				// Destinataire
				$mailFryzzer->AddAddress($mail);
				// Objet
				$mailFryzzer->Subject = 'Votre demande a été refusée';
				// message
				$mailFryzzer->MsgHTML("Votre demande d'inscription en tant qu'administrateur a été refusée");
				// envoi
				$isSend = $mailFryzzer->send();

				if ($isSend) {
					session_start();
					$_SESSION["refusedCreateSuperAdminAccount"] = $mail;
				} else {
					session_start();
					$_SESSION["errorRefusedCreateSuperAdminAccount"] = "error";
				}
			} catch (phpmailerException $e) {
				echo $e->errorMessage();
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		} else { // si mail non valide on refuse l envoi et on redirige
			header('Location: /zz-sign_in');
		}
	}

	/**
	 * 
	 * supprime la demande d inscription dans askNewUser
	 * 
	 * @param string $user mail de l user
	 * 
	 * 
	 */

	public function deleteAskNewUser($user)
	{

		$where = array('mail = ?' => $user);

		$this->delete($where);
	}

	/**
	 * 
	 * verifie si l user a bien fait une demande d inscription
	 * 
	 * @param string $user mail de l user
	 * @param string $key clé unique attribué a l user
	 * 
	 * @return array retourne le mail et la cle unique de l user ayant fais la demande
	 * 
	 * 
	 */

	public function verifAskNewUser($user, $key)
	{

		$select = array("*");
		$where = array("mail = ?" => $user, "AND key = ?" => $key);

		return $this->select($select, $where);
	}

	/**
	 * 
	 * 
	 * 
	 * 
	 * 
	 */

	 public function checkIfAlreadyAsked($mail){

		$select = array("id");
		$where = array("mail = ?"=>$mail);

		$result = $this->select($select, $where);

		if(!empty($result))
			return true;

		return false;

	 }
}
