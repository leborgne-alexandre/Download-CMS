<?php

//declare (strict_types=1);

class Blacklist extends ConnectBDD{

	public $ip;
	public $counter = 0;
	public $timetounlock = "1000-01-01 00:00:00";

	/**
	 * 
	 *	recupere l ip de l utilisateur au chargement de la page
	 * 
	 * 
	 */

	public function __construct(){

		parent::__construct();

		// recuperation ip visiteur

			/*if (isset($_SERVER['HTTP_CLIENT_IP'])) {
				 self::setIp($_SERVER['HTTP_CLIENT_IP']);
			}
			// IP derrière un proxy
			elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				 self::setIp($_SERVER['HTTP_X_FORWARDED_FOR']);
			}
			// Sinon : IP normale
			else {*/
				 self::setIp(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '');
			//}

			$result = $this->checkIPinTable();

			if(empty($result)){
				$this->insertIPinTable();
			}
			
	}

	public function setIp($ip){
		$this->ip = trim(filter_var($ip, FILTER_VALIDATE_IP));
	}

	public function getIp(){
		return $this->ip;
	}

	public function setCounter($counter){
		$this->counter = $counter;
	}

	public function getCounter(){
		return $this->counter;
	}

	public function setTimeToUnlock($timeToUnlock){
		$this->timetounlock = $timeToUnlock;
	}

	public function getTimeToUnlock(){
		return $this->timetounlock;
	}

	/**
	 * 
	 * Insere l ip dans la table Blacklist
	 * 
	 */

	public function insertIPinTable(){

		$this->insert();

	}

	/**
     * 
     * verifie si l ip est deja presente dans la table blacklist
	 * 
	 * @return array ip si trouvé ou null
     * 
     * 
     */

	public function checkIPinTable(){

		$select = array("ip");
		$where = array("ip = ?"=>$this->ip);

		return $this->select($select, $where);

	}

	/**
     * 
     * remet le compteur d echec de connexion a 0
	 *
     * 
     * 
     */

	public function resetCounter(){

		$set = array("counter"=>0, "timetounlock"=>"1000-01-01 00:00:00");
		$where = array("ip = ?"=>$this->ip);

		$this->update($set, $where);

	}

	/**
     * 
     * incremente le compteur d echec de connexion
	 *
     * 
     * 
     */

	public function incrementCounter(){

		$value = $this->getCounterValue();
		
		$value = (int)implode(',', $value[0]);

		$newValue = $value + 1;

		$reqSet = array('counter'=>$newValue);
		$reqWhere = array('ip = ?'=>$this->ip);

		if($value >= 5){
			$this->banUserIP($this->ip);
		}else{
			$this->update($reqSet, $reqWhere);
		}

	}

	/**
     * 
     * recupere la valeur du compteur d echec de connexion
	 * 
	 * @return array valeur du compteur
     * 
     * 
     */

	public function getCounterValue(){

		$select = array("counter");
		$where = array("ip = ?"=>$this->ip);

		return $this->select($select, $where);

	}

	/**
     * 
     * banni une ip temporairement
	 * 
	 * @param string $ip ip de l'user banni
     * 
     * 
     */

	public function banUserIP($ip){

		$time = new GetCurrentTime();
		$format = $time->format;
		$bannedToTime = date($format, time() + 1800);

		$set = array("timetounlock"=>$bannedToTime, "counter"=>0);
		$where = array("ip = ?"=>$ip);

		$this->update($set, $where);

	}

	/**
     * 
     * check si l'ip de l user est deja banni
	 * 
	 * @param string $ip ip de l'user banni
     * 
     * 
     */

	public function checkIfIPBanned(){

		$select = array("timetounlock");
		$where = array("ip = ?"=>$this->ip);

		$result = $this->select($select, $where);

		$time = new GetCurrentTime();
		$currentTime = $time->currentTime;

		$bannedToTime = $result[0]["timetounlock"];

		if($bannedToTime > $currentTime)
			return TRUE;

		return FALSE;

	}

}