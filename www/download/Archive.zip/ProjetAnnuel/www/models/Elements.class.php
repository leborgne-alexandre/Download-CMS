<?php

//declare (strict_types=1);

class Elements extends ConnectBDD{
    use global_security;
    use element_style__style_hover;

    public $id_element;
    public $nom_element;
    public $id_page;
    public $is_deletable = 1;
    public $type;
    public $contenu;
    public $link = null;

    public function setElementId($id){
        $this->id_element = trim($id);
    }

    public function getElementId(){
        return $this->id_element;
    }

    public function setElementName($name){

        $this->nom_element = trim($name);
    }

    public function getElementName(){
        return $this->nom_element;
    }

    public function setPageId($id){
        $this->id_page = trim($id);
    }

    public function getPageId(){
        return $this->id_page;
    }

    public function setIsDeletable($isDeletable){
        $this->is_deletable = $isDeletable;
    }

    public function getIsDeletable(){
        return $this->is_deletable;
    }

    public function setType($type){
        $this->type = trim($type);
    }

    public function getType(){
        return $this->type;
    }

    public function setContain($contain){
        $this->contenu = $contain;
    }

    public function getContain(){
        return $this->contenu;
    }

    public function setLink($link){
        $this->link = $link;
    }

    public function getLink(){
        return $this->link;
    }

    /**
     * 
     * recuperer les elements editable
	 * 
	 * @param string $slug slug de la page demandé
     * 
     * @return array elements editables
     * 
     * 
     */

    public function getEditableElementsIdFromDb($slug){

        $select = array("id_element", "nom_element", "is_deletable", "type");
        $where = array("id_page IN (SELECT id_page FROM pages WHERE slug = ?)"=>$slug);
        $orderBy = array("ORDER BY id ASC");

        return $this->select($select, $where, $orderBy);

    }

    /**
     * 
     * Recupere le prochain id d un element de la table en suivant l ordre croissant
     * 
     * @return integer $id prochain id de la table
     * 
     */

     public function getNextElementId(){

        $select = array("MAX(id_element)");
        
        $result = $this->select($select);

        $nextId = $result[0]["max"] + 1;

        return $nextId;

     }

     /**
     * 
     * check si l element est supprimable
     * 
     * @param integer $element id de l element
     * 
     * @return boolean true si supprimable ou false si non supprimable
     * 
     */

     public function checkIfElementIsDeletable($element){

        $select = array("is_deletable");
        $where = array("id_element = ?"=>$element);

        $result = $this->select($select, $where);

        return $result[0];

     }

     /**
      * 
      * recupere le type de l element
      *
      * @param integer $idElement id de l element
      *
      * @return string type de l element
      *
      *
      */

      public function getElementType($idElement){

        $select = array("type");
        $where = array("id_element = ?"=>$idElement);

        $result = $this->select($select, $where);

        return $result[0]["type"];


      }

      /**
       * 
       * recupere la redirection du lien
       * 
       * @param integer $idElement id de l element
       * 
       * @return string lien de la redirection
       * 
       * 
       */

       public function getElementLink($idElement){

         $select = array("link");
         $where = array("id_element = ?"=>$idElement);

         $result = $this->select($select, $where);

         return $result[0]["link"];

       }

       /**
        * 
        * insere en bdd le nouveau lien
        *
        * @param string $value url
        * @param integer $element id de l element
        *
        *
        */

        public function insertLink($value, $element){

            $set = array("link"=>$value);
            $where = array("id_element = ?"=>$element, "AND (type = ?"=>"link", "OR type = ?)"=>"video");

            $this->update($set, $where);

        }

        /**
      * 
      * ajoute un text
      *
      * @param integer $id id du nouveau element
      *
      * @return array $htmlElement html du nouvel element en bdd et affichage en js
      *
      */

      public function addText($id, $elementName){

        $bddHtml = '<div id="element-'.$elementName.'-'.$id.'"></div>';
        $viewHtml = '<div id="element-'.$elementName.'-'.$id.'" onmouseover="mouseHoverAddedElement(this);" onmouseout="mouseOutAddedElement(this);" >Texte...</div>';
        $htmlElement = ["htmlBdd" => $bddHtml, "htmlView" => $viewHtml];

        return $htmlElement;

      }

      /**
      * 
      * ajoute une image
      *
      * @param integer $id id du nouveau element
      *
      * @return string $htmlElement html du nouvel element
      *
      */

      public function addImage($id, $elementName, $fileName, $path){

        $bddHtml = '<img class="image-view" id="element-'.$elementName.'-'.$id.'" />';
        $viewHtml = '<img class="image-view" src="'.$path.$fileName.'" onmouseover="mouseHoverAddedElement(this);" onmouseout="mouseOutAddedElement(this);" id="element-'.$elementName.'-'.$id.'" />';
        $htmlElement = ["htmlBdd" => $bddHtml, "htmlView" => $viewHtml];

        return $htmlElement;

     }

    /**
      * 
      * ajoute une video
      *
      * @param integer $id id du nouveau element
      *
      * @return string $htmlElement html du nouvel element
      *
      */

      public function addVideo($id, $elementName, $fileName, $path){

        $bddHtml = '<video class="video-player" id="element-'.$elementName.'-'.$id.'" controls></video>';
        $viewHtml = '<video class="video-player" onmouseover="mouseHoverAddedElement(this);" onmouseout="mouseOutAddedElement(this);" id="element-'.$elementName.'-'.$id.'" src="'.$path.$fileName.'" controls></video>';
        $htmlElement = ["htmlBdd" => $bddHtml, "htmlView" => $viewHtml];

        return $htmlElement;

    }

    /**
      * 
      * ajoute un lien
      *
      * @param integer $id id du nouveau element
      *
      * @return string $htmlElement html du nouvel element
      *
      */

      public function addLink($id, $elementName){

        $bddHtml = '<a href="" id="element-'.$elementName.'-'.$id.'"></a>';
        $viewHtml = '<a id="element-'.$elementName.'-'.$id.'" onmouseover="mouseHoverAddedElement(this);" onmouseout="mouseOutAddedElement(this);">lien...</a>';
        $htmlElement = ["htmlBdd" => $bddHtml, "htmlView" => $viewHtml];

        return $htmlElement;

    }

     /**
     * 
     * ajoute un element en bdd
     * 
     * @param string $element type d element a ajouter
     * 
     * 
     */

    public function addElement($type, $elementName, $slug, $fileName, $path){
       
        $elements = new Elements();
        $pages = new Pages();

        $nextId = $elements->getNextElementId();

        $nextId = $nextId + 2000;

        $elementHtml = [];

        if($type == "text"){
            $elementHtml = $this->addText($nextId, $elementName);
        }elseif($type == "image"){
            $elementHtml = $this->addImage($nextId, $elementName, $fileName, $path);
        }elseif($type == "video"){
            $elementHtml = $this->addVideo($nextId, $elementName, $fileName, $path);
        }elseif($type == "link"){
            $elementHtml = $this->addLink($nextId, $elementName);
        }

        if($type == "video" || $type == "image")
            $contain = '<div class="generated-element" style="text-align: center;">'.$elementHtml["htmlBdd"].'</div>';
        else
            $contain = '<div class="generated-element">'.$elementHtml["htmlBdd"].'</div>';

        $pageId = $pages->getElementsFromBdd("id_page", $slug);

        $elements->insertElementInEachTable(null, $nextId, $pageId, $elementName, $type, $contain, $fileName, $path);
        $styles = new Styles();
        $styles->insertElementInEachTable($type, $nextId, $pageId);
        $styles_hover = new Styles_hover();
        $styles_hover->insertElementInEachTable(null, $nextId, $pageId);

		$pages->updateLastChangeDate($nextId);

        if($type == "video" || $type == "image")
            return '<div id="generated-element-'.$nextId.'" style="text-align: center;" class="generated-element">'.$elementHtml["htmlView"].'</div>';
        else
            return '<div id="generated-element-'.$nextId.'" class="generated-element">'.$elementHtml["htmlView"].'</div>';
        
     }

}