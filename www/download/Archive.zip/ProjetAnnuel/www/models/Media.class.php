<?php

//declare (strict_types=1);

class Media extends ConnectBDD{
    use global_security;

    public $title = "";
    public $file_name;
    public $type;
    public $size;
    public $is_initial = 0;
    public $path = "";

    public function setTitle($title){
        $this->title = trim($title);
    }

    public function getTitle(){
        return $this->title;
    }

    public function setFileName($file_name){
        $this->file_name = trim($file_name);
    }

    public function getFileName(){
        return $this->file_name;
    }

    public function setType($type){
        $this->type = trim($type);
    }

    public function getType(){
        return $this->type;
    }

    public function setSize($size){
        $this->size = trim($size);
    }

    public function getSize(){
        return $this->size;
    }

    public function setIsInitial($isInitial){
        $this->is_initial = $isInitial;
    }

    public function getIsInitial(){
        return $this->is_initial;
    }

    public function setPath($path){
        $this->path = trim($path);
    }

    public function getPath(){
        return $this->path;
    }


    /**
     * 
     * converti la taille initial (octet) en mo
     * 
     * @param integer $size taille initial en octet
     * 
     * @return float $convertedSize taille convertit en mo
     * 
     * 
     */

     public function convertKoToMo($size){

        $convertedSize = round($size / 1000000, 2);

        return $convertedSize;

     }

    /**
     * 
     * verifie que le media correspond aux criteres
     * 
     * @param string $fileName nom du fichier
     * @param integer $fileSize taille du fichier
     * @param integer $fileError erreur au dl
     * 
     * @return array $errors tableau des erreurs
     * 
     * 
     */

    public function checkIfMediaIsValid($fileName, $fileSize, $fileError = 0, $afterPreview = false){

        $errors = [];
        $extend = strtolower(substr(strrchr($fileName, '.'), 1));
        $errors["hasErrors"] = 0;

        if($fileError > 0){
            $errors["error_while_dl"] = "Erreur lors du téléchargement";
            $errors["hasErrors"] = 1;
            return $errors;
        }

        if(!in_array($extend, AUTHORIZED_IMAGE_EXTENDS) && !in_array($extend, AUTHORIZED_VIDEO_EXTENDS)){
            $errors["extend_invalid"] = "L'extension du fichier n'est pas valide";
            $errors["hasErrors"] = 1;
        }

        if(!$afterPreview){
            if((in_array($extend, AUTHORIZED_IMAGE_EXTENDS) && $fileSize > MAX_FILE_SIZE_IMAGE) 
            || (in_array($extend, AUTHORIZED_VIDEO_EXTENDS) && $fileSize > MAX_FILE_SIZE_VIDEO)){
                $errors["file_too_loud"] = "Le fichier est trop lourd";
                $errors["hasErrors"] = 1;
            }
        }else{
            $fileSize = $fileSize * 1000000;
            if((in_array($extend, AUTHORIZED_IMAGE_EXTENDS) && $fileSize > MAX_FILE_SIZE_IMAGE) 
            || (in_array($extend, AUTHORIZED_VIDEO_EXTENDS) && $fileSize > MAX_FILE_SIZE_VIDEO)){
                $errors["file_too_loud"] = "Le fichier est trop lourd";
                $errors["hasErrors"] = 1;
            }
        }

        return $errors;

    }

    /**
     * 
     * verifie que le media correspond aux criteres
     * 
     * @param string $fileName nom du fichier
     * @param integer $fileSize taille du fichier
     * 
     * @return string $html html de l apercu
     * 
     * 
     */

    public function showMediaPreview($fileName, $fileSize){

        $size = $this->convertKoToMo($fileSize);
        $extend = strtolower(substr(strrchr($fileName, '.'), 1));

        $html = "";
        $type = "";
        if(in_array($extend, AUTHORIZED_IMAGE_EXTENDS)){
            $type = "image";

            $html = "<div class='bloc-display-preview flex'>
            <div id='bloc-infos-preview-media' class='flex column'>
            <span class='text-infos-preview-media'><label>Nom :</label> $fileName</span>
            <span class='text-infos-preview-media'><label>Taille :</label> $size Mo</span>
            <input type='text' id='text-field-preview-media' placeholder='Titre de l&rsquo;image (obligatoire)' class='text-field-preview-media' />
            <label id='error-title-preview-media'></label>
            <input type='button' class='cta-preview-media' id='validate-download-media' value='Valider' onclick='validateDownloadMedia(\"$fileName\", $size);' />
            <input type='button' class='cta-preview-media' id='cancel-download-media' value='Annuler' onclick='cancelDownloadMedia();' />
            <input type='hidden' id='media-in-base64'/>
            </div>
            </div>";
        }else{  
            $type = "video";
            $html = "";
        }

        return ["html"=>$html, "type"=>$type, "fileName"=>$fileName, "fileSize"=>$size, "hasErrors"=>0];
    }

    /**
     * 
     * verifie que le media correspond aux criteres
     * 
     * @param string $fileName nom du fichier
     * @param string $fileType type de fichier
     * @param integer $fileSize taille du fichier
     * @param string $pathTemporaryFolder chemin du dossier temporaire
     * @param integer $fileError erreur au dl
     * 
     * 
     * 
     */

    public function insertMedia($fileName, $fileSize, $title = null){

        $title = $this->removeUnwantedString($title);

        $extend = strtolower(substr(strrchr($fileName, '.'), 1));

        if(in_array($extend, AUTHORIZED_IMAGE_EXTENDS)){
            $fileType = "image";
        }else{
            $fileType = "video";
            $fileSize = $this->convertKoToMo($fileSize);
        }

        $date = new DateTime();
		$timestamp = $date->getTimestamp();

        $newFileName = md5($timestamp).".".$extend;

        $this->setTitle($title);
        $this->setFileName($newFileName);
        $this->setType($fileType);
        $this->setSize($fileSize);

        $this->insert();

        return ["fileName"=>$newFileName, "fileTitle"=>$title, "fileSize"=>$fileSize];

    }

    /**
     * 
     * cré le fichier du media dans le dossier des medias dl
     * 
     * @param string $fileName nom du fichier
     * @param string $media base64 du media si image ou fakePath si video
     * @param boolean $isVideo false si image et true si video
     * 
     * 
     * 
     */

    public function createMediaFile($fileName, $media, $isVideo = false){

        if(!$isVideo){
            $imageDecode64 = base64_decode(substr($media, 22));
            file_put_contents('.'.PATH_DL_MEDIAS.$fileName, $imageDecode64);
        }else{
            move_uploaded_file($media, '.'.PATH_DL_MEDIAS.$fileName.'');
        }
    }

     /**
     * 
     * recupere tout les medias
     * 
     * @return array $result tableau avec toute les données des medias
     * 
     * 
     * 
     */

    public function getAllMedias(){

        $select = array("*");
        $orderBy = array("ORDER BY id DESC");

        $result = $this->select($select, NULL, $orderBy);

        return $result;
    }

    /**
     * 
     * supprime un média
     * 
     * @param string $mediaName nom du média
     * 
     * 
     * 
     */

    public function deleteMedia($mediaName, $path){

        if($path === PATH_DL_MEDIAS){
            $where = array('file_name = ?'=>$mediaName);
            unlink('.'.PATH_DL_MEDIAS.$mediaName.'');
        }else{
            $where = array('file_name = ?'=>$mediaName, 'AND path = ?'=>$path);
            unlink('.'.$path.$mediaName.'');
        }

        $this->delete($where);
    }

    /**
     * 
     * recupere l'id d un media
     * 
     * @param string $mediaName nom du média
     * 
     * 
     * 
     */

    public function getMediaId($mediaName){

        $select = array("id");
        $where = array("file_name = ?"=>$mediaName);

        $result = $this->select($select, $where);

        return $result[0]["id"];
    }

    /**
     * 
     * compte les medias
     * 
     * @param string $type type de media a compter
     * 
     * 
     * 
     */

    public function countMedias($type){

        $select = array("COUNT(id)");
        $where = array("type = ?"=>$type);

        $result = $this->select($select, $where);

        return $result[0]["count"];
    }

    /**
     * 
     * recupere les medias selon le type
     * 
     * @param string $type type de media recherché
     * 
     * 
     * 
     */

    public function getMediasToAdd($type){

        $select = array("file_name", "type", "is_initial", "path");
        $where = array("type = ?"=>$type);

        $result = $this->select($select, $where);

        return $result;

    }

    /**
     * 
     * recupere le titre d une image grace au chemin
     * 
     * @param string $path chemin de l image
     * 
     * @return string titre de l'image
     * 
     * 
     * 
     */

     public function getMediaTitleWithPath($path){

        $fileName = explode("/", $path);
        $fileName = end($fileName);

        $select = array("title");
        $where = array("file_name = ?"=>$fileName);

        $result = $this->select($select, $where);

        if(!empty($result))
            return $result[0]["title"];
        else
            return null;

     }

     /**
      * 
      * recupere les medias initiaux du cms
      *
      *
      *
      *
      *
      */

      public function getInitialMedias(){

        $mediasDirectory = opendir(".".PATH_INITIAL_MEDIAS);

        while($childrenDirectory = readdir($mediasDirectory)){

            if($childrenDirectory != "." && $childrenDirectory != ".."){
                $eachMediasDirectory = opendir(".".PATH_INITIAL_MEDIAS.$childrenDirectory);

                while($media = readdir($eachMediasDirectory)){
                    if($media != "." && $media != ".."){
                        $fileSize = $this->convertKoToMo(fileSize(".".PATH_INITIAL_MEDIAS.$childrenDirectory."/".$media));
                        $extend = strtolower(substr(strrchr($media, '.'), 1));

                        if(in_array($extend, AUTHORIZED_IMAGE_EXTENDS))
                            $type = "image";
                        elseif(in_array($extend, AUTHORIZED_VIDEO_EXTENDS))
                            $type = "video";

                        $this->setFileName($media);
                        $this->setType($type);
                        $this->setSize($fileSize);
                        $this->setIsInitial(true);
                        $this->setPath(PATH_INITIAL_MEDIAS.$childrenDirectory."/");
                        $this->insert();
                    }
                }
            }

        }

      }
}