<?php
class Notes extends ConnectBDD{
    use global_security;

    /**
     * 
     * recupere les notes
     * 
     * @return string $notes notes récupérées
     * 
     * 
     */

    public function getNotes(){

        $select = array("notes");

        $result = $this->select($select);

        return $result[0]["notes"];

    }

    /**
     * 
     * sauvegarde les notes
     * 
     * @param string $text notes
     * 
     * 
     */

    public function saveNotes($text, $title = "", $isFastNoteInsert = false){

        $notes = $this->removeUnwantedStringInCKEditor($text);

        if($isFastNoteInsert){
            $title = $this->removeUnwantedStringInCKEditor($title);

            $select = array("notes");

            $result = $this->select($select);

            $this->fastNoteInsert($result[0]["notes"], $text, $title);

            return;
        }

        $set = array("notes"=>$notes);

        $this->update($set);

    }

    /**
     * 
     * insert une nouvelle note rapide
     * 
     * @param string $currentNotes notes deja en bdd
     * @param string $newNote nouvelle note a inserer
     * @param string $newTitle nouveau titre a inserer
     * 
     * 
     */

     public function fastNoteInsert($currentNotes, $newNote, $newTitle){

        $newNote = "<p>".$newNote."</p>";
        $newTitle = "<p><b>".$newTitle."</b></p>";

        $newNotes = $currentNotes.$newTitle.$newNote;

        $set = array("notes"=>$newNotes);

        $this->update($set);

     }

}