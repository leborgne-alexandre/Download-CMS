<?php
class Notifications extends ConnectBDD{

    public $id_notification = 0;
    public $id_user = 0;
    public $type_notification;
    public $contenu = "";
    public $mail = "";
    public $key = "";
    public $date;
    public $slug = "";

    public function setIdNotif($id){
        $this->id_notification = $id;
    }

    public function getIdNotif(){
        return $this->id_notification;
    }

    public function setIdUser($id){
        $this->id_user = $id;
    }

    public function getIdUser(){
        return $this->id_user;
    }

    public function setTypeNotification($type){
        $this->type_notification = trim($type);
    }

    public function getTypeNotification(){
        return $this->type_notification;
    }

    public function setContain($contain){
        $this->contenu = trim($contain);
    }

    public function getContain(){
        return $this->contenu;
    }

    public function setMail($mail){
        $this->mail = trim($mail);
    }

    public function getMail(){
        return $this->mail;
    }

    public function setKey($key){
        $this->key = trim($key);
    }

    public function getKey(){
        return $this->key;
    }

    public function setDate($date){
        $this->date = $date;
    }

    public function getDate(){
        return $this->date;
    }

    public function setSlug($slug){
        $this->slug = $slug;
    }

    public function getSlug(){
        return $this->slug;
    }

    /**
     * 
     * récupère les notifications
     * 
     * @return array toutes les notifications
     * 
     *  
     * */ 

     public function getAllNotifs($isDisplayInDashboard = false){

        $select = array("*");

        if(!$isDisplayInDashboard){
            $orderByLimit = array("ORDER BY id DESC LIMIT 30");
        }else{
            $orderByLimit = array("ORDER BY id DESC LIMIT 10");
        }
       
        $result = $this->select($select, null, $orderByLimit);

        if(!empty($result))
            return $result;

        return "Aucune notification";
     }

     /**
     * 
     * compte le nombre de notifications
     * 
     * @return integer nombre de notifs
     * 
     *  
     * */ 

    public function countNotifications(){

        $select = array("COUNT(id)");
       
        $result = $this->select($select);

        return $result[0]["count"];
     }

    /**
    * 
    * crée la notif d ajout d un admin
    *
    *
    *
    */

    public function createNotif(){

        $this->insert();

    }

    /**
     * 
     * supprime la notif de demande d ajout d un admin
     * 
     * @param string $mail mail de l user dont il faut supprimer la notif de demande d ajout
     * @param string $key cle secrete de demande d ajout
     * 
     * 
     * 
     */

    public function deleteAskNewUserNotif($mail, $key){

        $where = array("mail = ?"=>$mail, "AND key = ?"=>$key, "AND type_notification = ?"=>ASK_NEW_ADMIN_NOTIFICATION_TYPE);

        $this->delete($where);

    }

    /**
     * 
     * Supprime la notif de nouvelle annonce
     * 
     * @param string $slug slug de l annonce ajoutée
     * 
     * 
     * 
     */

    public function deleteNewAnnounceNotif($slug, $all = false){

        if(!$all)
            $where = array("slug = ?"=>$slug, "AND type_notification = ?"=>NEW_ANNOUNCE_NOTIFICATION_TYPE);
        else
            $where = array("type_notification = ?"=>NEW_ANNOUNCE_NOTIFICATION_TYPE);

        $this->delete($where);

    }

}