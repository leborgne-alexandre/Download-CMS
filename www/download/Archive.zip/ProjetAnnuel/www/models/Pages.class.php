<?php

//declare (strict_types=1);

class Pages extends ConnectBDD{
    use global_security;
    use page_announce;

    public $id_page;
    public $nom_page;
    public $slug;
    public $id_template;
    public $contenu = "";
    public $title;
    public $last_update;
    public $creator;
    public $description;
    public $etat = "non active";
    public $is_deletable = 1;

    public function setIdPage($id){
        $this->id_page = $id;
    }

    public function getIdPage(){
        return $this->id_page;
    }

    public function setPageName($name){
        $this->nom_page = trim($name);
    }

    public function getPageName(){
        return $this->nom_page;
    }

    public function setSlug($string){

        $slug = new ConvertStringToSlug(trim($string));
        $this->slug = $slug->slug;

    }

    public function getSlug(){
        return $this->slug;
    }

    public function setIdTemplate($id){
        $this->id_template = $id;
    }

    public function getIdTemplate(){
        return $this->id_template;
    }

    public function setContain($contain){
        $this->contenu = $contain;
    }

    public function getContain(){
        return $this->contenu;
    }

    public function setTitle($title){
        $this->title = trim($title);
    }

    public function getTitle(){
        return $this->title;
    }

    public function setLastUpdate($date){
        $this->last_update = $date;
    }

    public function getLastUpdate(){
        return $this->last_update;
    }

    public function setCreator($creator){
        $this->creator = trim($creator);
    }

    public function getCreator(){
        return $this->creator;
    }

    public function setDescription($description){
        $this->description = trim($description);
    }

    public function getDescription(){
        return $this->description;
    }

    public function setCondition($condition){
        $this->etat = trim($condition);
    }

    public function getCondition(){
        return $this->etat;
    }

    public function setIsDeletable($isDeletable){
        $this->is_deletable = $isDeletable;
    }

    public function getIsDeletable(){
        return $this->is_deletable;
    }

    public function deletePageInPageList($slug){

        $where = array("slug = ?"=>$slug, "AND is_deletable = ?"=>"TRUE");
        
        $this->delete($where);
    }

    /**
     * 
     * recupere le formulaire de creation d une page
     * 
     * 
     * @return array formulaire
     * 
     * 
     */

    public function getCreatePageForm(){

		return [
					"config"=>[ 
						"method"=>"POST", 
						"action"=>Routing::getSlug("Users", "validateCreatePage"),
						"class"=>"form-create-page flex column", 
						"id"=>"form-create-page",
						"submit"=>"Créer la nouvelle page"
						],

					"data"=>[

								"name"=>[
										"type"=>"text",
										"placeholder"=>"Nom de la nouvelle page",
										"id"=>"page-name",
										"name"=>"page-name",
										"class"=>"form-elements-in-cms",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"Le nom de la page ne doit pas dépasser 100 caractères"
									],

								"slug"=>[
										"type"=>"text",
										"placeholder"=>"Personnaliser l'url de la page (facultatif)",
										"id"=>"page-slug",
										"name"=>"page-slug",
										"class"=>"form-elements-in-cms",
										"maxlength"=>100,
										"required"=>false,
										"error"=>"L'url de la page ne doit pas dépasser 100 caractères"
                                    ],
                                    
                                "title"=>[
										"type"=>"text",
										"placeholder"=>"Titre de la page",
										"id"=>"page-title",
										"name"=>"page-title",
										"class"=>"form-elements-in-cms",
										"maxlength"=>100,
										"required"=>true,
										"error"=>"Le titre de la page ne doit pas dépasser 100 caractères"
                                    ],
                                    
                                "description"=>[
										"type"=>"text",
										"placeholder"=>"Description de la page",
										"id"=>"page-description",
										"name"=>"page-description",
										"class"=>"form-elements-in-cms",
										"maxlength"=>300,
										"required"=>true,
										"error"=>"La description de la page ne doit pas dépasser 300 caractères"
                                ],
                                    
                                "template"=>[
										"id"=>"template-list",
										"name"=>"template-list"
									]

							]

					];


	}

    /**
     * 
     * recupere toute les pages 
     * 
     * @return array tableau des pages trouvé
     * 
     * 
     */
   
    public function getAllPages(){

        $select = array("nom_page", "slug", "title", "last_update", "creator", "description", "etat", "is_deletable");
        $where = array("slug != ?"=>"footer", "AND slug != ?"=>"header");
        $orderBy = array("ORDER BY nom_page ASC");

        return $this->select($select, $where, $orderBy);

    }

    /**
     * 
     * verifie si le slug recherché existe
     * 
     * @param string $slug slug recherché
     * 
     * @return bool true si trouvé et false si non trouvé
     * 
     * 
     */
    
    public function checkIfSlugExists($slug, $edition = FALSE){

        $select = array("slug");

        if(!$edition){
            $where = array("slug = ?"=>$slug);
            $result = $this->select($select, $where);
            
            if(!empty($result)){
                $where = array("slug = ?"=>$slug, "AND etat = ?"=>"active");
                $result_is_maintenance = $this->select($select, $where);
                
                if(empty($result_is_maintenance)){
                    return "desactivated";
                }
            }else{
                $where = array("slug = ?"=>$slug, "AND etat = ?"=>"active");
            }
            
        }else{
            $where = array("slug = ?"=>$slug);
        }

        $result_get_slugs = $this->select($select, $where);
	
		if(!empty($result_get_slugs))
			return TRUE;
        
        return FALSE;
    }

    /**
     * 
     * verifie si le nom de la page existe
     * 
     * @param string $name nom de la page
     * 
     * @return bool true si trouvé et false si non trouvé
     * 
     * 
     */
    
    public function checkIfPageNameExists($name){

        $select = array("nom_page");
        $where = array("nom_page = ?"=>$name);

        $result_get_page_name = $this->select($select, $where);
	
		if(!empty($result_get_page_name))
			return TRUE;
            
        return FALSE;
    }

    /**
    *
    * actualise la date de la derniere modification
    *
    * @param integer $idElementChanged id de l element modifié avant l update
    *
    *
    */

    public function updateLastChangeDate($idElementChanged){

        $this->generateSitemap();
        $currentTime = new GetCurrentTime();
        $newLastUpdateDate = $currentTime->currentTime;

        $set = array("last_update"=>$newLastUpdateDate);
        $where = array("id_page = (SELECT id_page FROM styles WHERE id_element = ?)"=>$idElementChanged);

        $this->update($set, $where);

    }

    /**
     * 
     * recupere les pages recherché dans la barre de recherche
     * 
     * @param string $value valeur de la barre de recherche
     * 
     * @return string pages trouvé
     * 
     * 
     */
    
    public function getSearchedPages($value){

        $select = array("id", "nom_page", "slug", "last_update", "creator", "description", "etat", "is_deletable");
        $where = array(
                        "nom_page != ?"=>"footer",
                        "AND nom_page != ?"=>"header",
                        "AND (lower(nom_page) LIKE lower(?)"=>"".$value."%",
                        "OR lower(creator) LIKE lower(?)"=>"".$value."%",
                        "OR lower(description) LIKE lower(?)"=>"".$value."%",
                        "OR lower(etat) LIKE lower(?))"=>"".$value."%"
                    );
        $orderBy = array("ORDER BY nom_page ASC");

        $result = $this->select($select, $where, $orderBy);

        $listPages = "";
		$i = 0;
		foreach($result as $key => $value){
							
            $listPages .= "<tr id='searched-page-list-line-".$i."'>
            <td>".$value['nom_page']."</td>
            <td>".$value['creator']."</td>
            <td>".date(EUROPEAN_DATE_FORMAT, strtotime($value['last_update']))."</td>
            <td>".$value['description']."</td>
            <td id='searched-page-state-".$i."'>".$value['etat']."</td>
            <td>
            <div>";
            if($value['slug'] != "error404" && $value['slug'] != "maintenance"){
                if($value['etat'] == "active")
                    $listPages .= "<button id='active-page-".$i."' onclick='activateOrDesactivatePage(this, \"desactivate\");' class='active-no-active-button' title='Désactiver la page ?' name='".$value['slug']."' value='desactivate'><i class='fas fa-battery-full active-page active-no-active-icon'></i></button>";
                else
                    $listPages .= "<button id='no-active-page-".$i."' onclick='activateOrDesactivatePage(this, \"activate\");' class='active-no-active-button' title='Activer la page ?' name='".$value['slug']."' value='activate'><i class='fas fa-battery-empty no-active-page active-no-active-icon'></i></button>";
            }
            $listPages .= "<a href='/".$value['slug']."' title='Visualiser'><i class='fas fa-eye'></i></a>
            <a href='website?page=".$value['slug']."' title='Editer'><i class='fas fa-edit'></i></a>";
            if($value['is_deletable'])
                $listPages .= "<button onclick='deleteInPageListPageWhileSearch(this);' name='".$value['slug']."' id='delete-page-in-page-list' class='cta-delete-page-in-page-list' title='Supprimer' value='".$i."'><i class='fas fa-trash-alt'></i></button>";
            $listPages .= "</div>
            </td>
            </tr>";

			$i++;
						
		}

		return $listPages;

    }

    /**
     * 
     * compte toute les pages du site non supprimé
     * 
     * @return integer nombre de pages trouvé
     * 
     * 
     */
    
    public function countAllWebsitePages(){

        $select = array("COUNT(nom_page)");
        $where = array("nom_page != ?"=>"footer", "AND nom_page != ?"=>"header");

        $result = $this->select($select, $where);

		if(!empty($result))
			return $result[0]["count"];
		
		return 0;

    }

    /**
     * 
     * compte toute les pages du site non active
     * 
     * @return integer nombre de pages trouvé
     * 
     * 
     */
    
    public function countWebsitePagesNonActive(){

        $select = array("COUNT(nom_page)");
        $where = array("nom_page != ?"=>"footer", "AND nom_page != ?"=>"header", "AND etat != ?"=>"active");

        $result = $this->select($select, $where);

		if(!empty($result))
			return $result[0]["count"];
		
		return 0;
    }

    /**
     * 
     * recupere l id de la page grace au slug
     * 
     * @return integer id de la page
     * 
     * 
     */

     public function getThePageId($slug){

        $select = array("id_page");
        $where = array("slug = ?"=>$slug, "AND is_deletable = ?"=>"TRUE");

        $result = $this->select($select, $where);

        return $result[0]["id_page"];

     }

    /**
     * 
     * Affilie le prochain id_page en suivant l ordre croissant
     * 
     * @return integer $nextId nouvel id faisant suite aux precedents
     * 
     * 
     */

     public function getNextPageId(){

        $select = array("MAX(id_page)");

        $result = $this->select($select);

        $nextId = $result[0]["max"] + 1;
        
        return $nextId;

     }
    
    /**
     * 
     * verifie les champs et crée une nouvelle page
     * 
     * @param string $templateName nom du template de la page a créé
     * 
     * 
     */
    
    public function createNewPage($templateName){

        $template = new Templates();
        $currentTime = new GetCurrentTime();

        $this->setIdPage($this->getNextPageId());
        $this->setIdTemplate($template->getIdTemplateWithTemplateName($templateName));
        $this->setLastUpdate($currentTime->currentTime);
        $this->setCreator($_SESSION["mail"]);
       
        $this->insert();

    }
    
    /**
     * 
     * active la page
     * 
     * @param string $page page a activer
     * 
     * 
     */
    
    public function activatePage($page){

            $set = array("etat"=>"active");
            $where = array("slug = ?"=>$page, "AND slug != ?"=>"error404", "AND slug != ?"=>"maintenance");
       
            $this->update($set, $where);

    }
    
    /**
     * 
     * desactive la page
     * 
     * @param string $page page a desactiver
     * 
     * 
     */
    
    public function desactivatePage($page){

        $set = array("etat"=>"non active");
        $where = array("slug = ?"=>$page, "AND slug != ?"=>"error404", "AND slug != ?"=>"maintenance");
       
        $this->update($set, $where);

    }
    
    /**
     * 
     * met a jour les informations de la page
     * 
     * @param string $pageName nom de la page modifie
     * @param string $pageTitle titre de la page modifie
     * @param string $pageSlug slug de la page modifie
     * @param string $pageDescription description de la page modifie
     * 
     * 
     */

     public function updatePageInfos($initialSlug, $pageName, $pageTitle, $pageSlug, $pageDescription){
       
        $set = array("nom_page"=>"$pageName", "title"=>"$pageTitle", "slug"=>"$pageSlug", "description"=>"$pageDescription");

        if($initialSlug != $pageSlug)
            $where = array("slug = ?"=>"$initialSlug", "AND is_deletable = ?"=>"TRUE");
        else
            $where = array("slug = ?"=>"$initialSlug");

        $this->update($set, $where);
        
     }

     /**
      * 
      * génère le sitemap.xml
      *
      *
      */

      public function generateSitemap(){

        $pageSlugs = $this->getAllSlugs();
        $announces = new Annonces();
        $announceSlugs = $announces->getAllSlugs();

        $xml = "";
        foreach($pageSlugs as $key => $value){
            if($value["slug"] != "header" && $value["slug"] != "footer"){
                $xml .= '<url>
                <loc>'.HOST.$value["slug"].'</loc>
                <lastmod>'.date('Y-m-d\TH:i:sO', strtotime($value["last_update"])).'</lastmod>
                </url>
                ';
            }
        }

        foreach($announceSlugs as $key => $value){
            $xml .= '<url>
            <loc>'.HOST.$value["slug"].'</loc>
            <lastmod>'.date('Y-m-d\TH:i:sO', strtotime($value["now_date"])).'</lastmod>
            </url>
            ';
        }

        unlink("sitemap.xml");
        $sitemap = fopen('sitemap.xml', 'a');
        fwrite($sitemap, '<?xml version="1.0" encoding="UTF-8"?>
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
        </urlset>');

        $dom = new DOMDocument();
        $dom->load('sitemap.xml');

        $fragment = $dom->createDocumentFragment(); 

        $fragment->appendXML($xml);
        $dom->documentElement->appendChild($fragment);

        $dom->save('sitemap.xml');

      }

}