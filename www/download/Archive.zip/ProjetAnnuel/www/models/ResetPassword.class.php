<?php

//declare (strict_types=1);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class ResetPassword extends ConnectBDD{

	public $mail;
	public $key;

	public function setMail($mail){
		$this->mail = trim($mail);
	}

	public function getMail(){
		return $this->mail;
	}

	public function setKey($key){
		$this->key = trim(htmlspecialchars($key));
	}

	public function getKey(){
		return $this->key;
	}

	/**
     * 
     * envoi du mail de reinitialisation de mot de passe
	 * 
	 * @param string $mail mail de l user ayant fais la demande
     * 
     * 
     * 
     */

	public function sendMailAskResetPassword($mail){
				// si mail valide on execute le script d envoi
			if(!empty($mail)){

				$token = new Token();
				$secretKey = $token->token;
				
				$this->setKey($secretKey);
				
				$this->insert();

				$mailFryzzer = new PHPMailer(TRUE);
				$mailFryzzer->isSMTP();
				try{
					$mailFryzzer->Host = MAIL_FRYZZER_HOST;
					$mailFryzzer->Port = MAIL_FRYZZER_PORT;
					$mailFryzzer->SMTPAuth = true;
					$mailFryzzer->Username = MAIL_FRYZZER_USERNAME;
					$mailFryzzer->Password = MAIL_FRYZZER_PASSWORD;
					$mailFryzzer->SMTPSecure = MAIL_FRYZZER_SMTP_SECURE;
					$mailFryzzer->CharSet = MAIL_FRYZZER_CHARSET;
					
					// Expéditeur
					$mailFryzzer->SetFrom(MAIL_FRYZZER_SET_FROM_MAIL, MAIL_FRYZZER_SET_FROM_NAME);
					// Destinataire
					$mailFryzzer->AddAddress($mail);
					// Objet
					$mailFryzzer->Subject = 'Réinitialisation du mot de passe';
					// message
					$mailFryzzer->MsgHTML("Si vous avez fait une demande de récupération de mot de passe, cliquez sur le lien suivant pour le réinitialiser :<br><a href='".HOST."zz-reset_password?u=".$mail."&k=".$secretKey."'>Réinitialiser le mot de passe</a>");
					// envoi
					$isSend = $mailFryzzer->send();

					if($isSend){
						session_start();
						$_SESSION["mailSend"] = "mailSend";
					}else{
						session_start();
						$_SESSION["errorMailSend"] = "error";
					}
				} catch (phpmailerException $e) {
					echo $e->errorMessage();
				} catch (Exception $e) {
					echo $e->getMessage();
				}

			}else{ // si mail non valide on refuse l envoi et on redirige
				header('Location: /zz-sign_in');
			}

	}

	/**
     * 
     * met a jour le mot de passe en bdd et supprime la demande dans la table ResetPassword
	 * 
	 * @param string $password nouveau mot de passe
	 * @param string $mail mail de l user ayant fais la demande
     * 
     * 
     * 
     */

	public function updatePasswordAndDeleteAsk($password, $mail){
		
		$usr = new Usr();
		$usr->updatePassword($password, $mail);

		try{

			$where = array('mail = ?'=>$mail);

			$this->delete($where);

			session_start();
			$_SESSION["validateResetPassword"]="validateResetPassword";

		}catch(Exception $e){
			session_start();
			$_SESSION["errorValidateResetPassword"]="errorValidateResetPassword";
		}
	}

	/**
     * 
     * verifie si l user a bien fais une demande
	 * 
	 * @param string $user mail de l user ayant fais la demande
	 * @param string clé unique attribué a l user
     * 
     * @return array user si trouvé ou vide si non trouvé
     * 
     * 
     */

	public function checkUserInResetPasswordTable($user, $key){

		$select = array("*");
		$where = array("mail = ?"=>$user, "AND key = ?"=>$key);

		return $this->select($select, $where);

	}

}