<?php

//declare (strict_types=1);

class Siteusers extends ConnectBDD{
    use users;
    use global_security;

    public $nom;
    public $prenom;
    public $age;
    public $password;
    public $mail;
    public $adresse;
    public $telephone;
    public $ville;
    public $code_postal;
    public $description;
    public $id_region;
    public $id_departement;
    public $id_role = ID_ROLE_USER;
    public $token;
    public $verified = 0;
    public $verifaccountkey;
    public $is_banned = 0;
    public $sign_up_date;

    public function setLastName($lastName){
        $this->nom = trim($lastName);
    }

    public function getLastName(){
        return $this->nom;
    }

    public function setFirstName($firstName){
        $this->prenom = trim($firstName);
    }

    public function getFirstName(){
        return $this->prenom;
    }

    public function setAge($age){
        $this->age = $age;
    }

    public function getAge(){
        return $this->age;
    }

    public function setPassword($password){
        $this->password = $password;
    }

    public function getPassword(){
        return $this->password;
    }

    public function setMail($mail){
        $this->mail = trim($mail);
    }

    public function getMail(){
        return $this->mail;
    }

    public function setAdress($adress){
        $this->adresse = trim($adress);
    }

    public function getAdress(){
        return $this->adress;
    }

    public function setPhone($phone){
        $this->telephone = trim($phone);
    }

    public function getPhone(){
        return $this->telephone;
    }

    public function setCity($city){
        $this->ville = trim($city);
    }

    public function getCity(){
        return $this->ville;
    }

    public function setPostalCode($postalCode){
        $this->code_postal = trim($postalCode);
    }

    public function getPostalCode(){
        return $this->code_postal;
    }

    public function setDescription($description){
        $this->description = trim($description);
    }

    public function getDescription(){
        return $this->description;
    }

    public function setRegionId($regionId){
        $this->id_region = trim($regionId);
    }

    public function getRegionId(){
        return $this->id_region;
    }

    public function setDepartmentId($departmentId){
        $this->id_departement = trim($departmentId);
    }

    public function getDepartmentId(){
        return $this->id_departement;
    }

    public function setRoleId($roleId){
        $this->id_role = trim($roleId);
    }

    public function getRoleId(){
        return $this->id_role;
    }

    public function setToken($token){
        $this->token = $token;
    }

    public function getToken(){
        return $this->token;
    }

    public function setVerified($verified){
        $this->verified = $verified;
    }

    public function getVerified(){
        return $this->verified;
    }

    public function setVerifAccountKey($Key){
        $this->verifaccountkey = $Key;
    }

    public function getVerifAccountKey(){
        return $this->verifaccountkey;
    }

    public function setIsBanned($isBanned){
        $this->is_banned = $isBanned;
    }

    public function getIsBanned(){
        return $this->is_banned;
    }

    public function setSignUpDate($signUpDate){
        $this->sign_up_date = $signUpDate;
    }

    public function getSignUpDate(){
        return $this->sign_up_date;
    }

    /**
     * 
     * crée les sessions utilisateur
     * 
     * @param string $mail mail de l user
     * @param string $token_value token de connexion
     * @param array $found_user infos du user
     * 
     * 
     * 
     */

    public function createSessions($found_user){

        session_start();
        $_SESSION['mail'] = $found_user[0]["mail"];
        $_SESSION['token_f'] = $found_user[0]["token"];
        $_SESSION['prenom'] = $found_user[0]["prenom"];
        $_SESSION['nom'] = $found_user[0]["nom"];
        $_SESSION['age'] = $found_user[0]["age"];
        $_SESSION['adresse'] = $found_user[0]["adresse"];
        $_SESSION['telephone'] = $found_user[0]["telephone"];
        $_SESSION['ville'] = $found_user[0]["ville"];
        $_SESSION['code_postal'] = $found_user[0]["code_postal"];
        $_SESSION['description'] = $found_user[0]["description"];
        $_SESSION['region'] = $found_user[0]["region"];
    }

    /**
     * 
     * verifie si l user est deja connecté
     * 
     * @return bool true si user connecté et false si non connecté
     * 
     * 
     * 
     */

    public function checkIfUserConnected(){

		//session_start();

		if(isset($_SESSION['token_f']) || isset($_COOKIE['token_f_kc'])){

			if(isset($_SESSION['token_f']) && isset($_COOKIE['token_f_kc'])){
				$token = $_SESSION['token_f'];
			}elseif(isset($_SESSION['token_f']) && !isset($_COOKIE['token_f_kc'])){
				$token = $_SESSION['token_f'];
			}elseif(!isset($_SESSION['token_f']) && isset($_COOKIE['token_f_kc'])){
				$token = $_COOKIE['token_f_kc'];
			}

			$found_user = $this->verifTokenAndValidated($token);

			if(!empty($found_user)){

                $this->createSessions($found_user);
				return true;
			}
                
            return false;
		}
            
        return false;
    }

    /**
     * 
     * recupere le detail des utilisateurs et moderateurs
     * 
     * @param integer $mail mail de l user
     * 
     * @return array $result liste des infos
     * 
     * 
     */

    public function getUserDetails($mail){

        $select = array("s.nom", "s.prenom", "s.age", "s.mail", "s.adresse", "s.telephone", "s.ville", "s.code_postal", "s.description", 
                        "r.region_nom", "d.departement_nom", "ro.role", "s.verified AS etat", "s.is_banned AS statut");
        $tag = "s";
        $innerJoin = array(
                            "regions r ON r.id_region = s.id_region",
                            "departements d ON d.id_departement = s.id_departement",
                            "roles ro ON ro.id_role = s.id_role"
                        );
        $where = array("s.mail = ?"=>$mail);

        return $result = $this->select($select, $where, NULL, $innerJoin, $tag);

    }

    /**
     * 
     * recupere le detail des utilisateurs et moderateurs
     * 
     * @param integer $mail mail de l user
     * 
     * @return array $result liste des infos
     * 
     * 
     */

    public function changeRole($mail, $role){

        $set = array("id_role"=>$role);
        $where = array("mail = ?"=>$mail);
        echo $role;
        echo $mail;
        $this->update($set, $where);

    }

    /**
     * 
     * Crée le html des users afficher avec un nouveau offset
     * 
     * @param array $result infos de l user
     * 
     * @return string $listUserOffset html créé
     * 
     * 
     */

    public function displayUsersWithNewOffset($result){

        $listUserOffset = "";

		$i = 0;
		foreach($result as $key => $value){
								
		    $listUserOffset .= "<tr>
			<td>".htmlentities($value['nom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['prenom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td>".(($value['role'] == NAME_ROLE_USER) ? '<i class="fas fa-user icon-user-list" title="Utilisateur" ></i>' :  '<i class="fas fa-user-shield icon-user-list" title="Modérateur"></i>')."</td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>
			<button onclick='getUserDetails(\"".htmlentities($value['mail'], ENT_QUOTES)."\");' class='cta-more-details cta-more-details-user-moderator' title='+ détails'><i class='fas fa-eye'></i></button>
			<button onclick='banInUserListUserWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-user-in-user-list' class='cta-delete-user-in-user-list' title='Bannir cet utilisateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>
			</div>
            </td>
			</tr>";

			$i++;
							
		}

		return $listUserOffset;

    }
    
    /**
     * 
     * recupere tout les utilisateurs et moderateurs
     * 
     * @param integer $offset offset de depart de la recherche en bdd
     * @param integer $roleId role de l utilisateur (3 = moderateur et 4 = user)
     * 
     * @return string  liste des users trouvé si offset > 0
     * @return array infos des users si offset = 0
     * 
     * 
     */
    
    public function getAllUsers($offset, $roleId = NULL){

        $select = array("s.nom", "s.prenom", "s.mail", "ro.role", "s.verified AS etat", "s.is_banned AS statut");
        $tag = "s";
        $innerJoin = array("roles ro ON ro.id_role = s.id_role");
        $where = array("s.is_banned = ?"=>"FALSE");

        if($roleId != NULL)
            $where["AND s.id_role = ?"] = $roleId;

        $orderByLimitOffset = array("ORDER BY s.id ASC LIMIT 20 OFFSET ".$offset."");

        $result = $this->select($select, $where, $orderByLimitOffset, $innerJoin, $tag);

		if($offset > 0){

			return $this->displayUsersWithNewOffset($result);

		}

		return $result;

    }

    /**
     * 
     * Crée le html des users recherché trouvés
     * 
     * @param array $result infos de l user
     * 
     * @return string $listUsers html créé
     * 
     * 
     */

    public function displaySearchedUsers($result){

        $listUsers = "";

		$i = 0;
		foreach($result as $key => $value){
							
		    $listUsers .= "<tr>
			<td>".htmlentities($value['nom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['prenom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td>".(($value['role'] == NAME_ROLE_USER) ? '<i class="fas fa-user icon-user-list" title="Utilisateur" ></i>' :  '<i class="fas fa-user-shield icon-user-list" title="Modérateur"></i>')."</td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
	        <div>
			<button onclick='getUserDetails(\"".htmlentities($value['mail'], ENT_QUOTES)."\");' class='cta-more-details cta-more-details-user-moderator' title='+ détails'><i class='fas fa-eye'></i></button>
			<button onclick='banInUserListUserWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-user-in-user-list' class='cta-delete-user-in-user-list' title='Bannir cet utilisateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>
			</div>
            </td>
			</tr>";

			$i++;
						
		}

		return $listUsers;

    }
    
    /**
     * 
     * recupere les user recherché dans la barre de recherche
     * 
     * @param integer $offset offset de depart de la recherche
     * @param string $value valeur de la barre de recherche
     * @param integer $roleId role de l user (3 = moderateur et 4 = user)
     * 
     * @return string liste des utilisateurs trouvé
     * 
     * 
     */

	public function getSearchedUsers($value, $roleId = NULL){

        $select = array("s.nom", "s.prenom", "s.mail", "ro.role", "s.verified AS etat", "s.is_banned AS statut");
        $tag = "s";
        $innerJoin = array("roles ro ON ro.id_role = s.id_role");
        $where = array(
                        "(lower(s.nom) LIKE lower(?)"=>"".$value."%",
                        "OR lower(s.prenom) LIKE lower(?)"=>"".$value."%",
                        "OR lower(s.mail) LIKE lower(?)"=>"".$value."%",
                        "OR lower(ro.role) LIKE lower(?))"=>"".$value."%",
                        "AND s.is_banned = ?"=>"FALSE"
                    );

        if($roleId != NULL)
            $where["AND s.id_role = ?"] = $roleId;

        $orderBy = array("ORDER BY s.nom ASC");

        $result = $this->select($select, $where, $orderBy, $innerJoin, $tag);

        return $this->displaySearchedUsers($result);

    }

    /**
     * 
     * Crée le html des users et moderateurs bannis trouvés
     * 
     * @param array $result infos de l user
     * 
     * @return string $listBannedOffset html créé
     * 
     * 
     */

    public function displayBannedUsersAndModerators($result){

        $listBannedOffset = "";
        $i = 0;
            
        foreach($result as $key => $value){
								
			$listBannedOffset .= "<tr>
			<td>".htmlentities($value['nom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['prenom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td>".(($value['role'] == NAME_ROLE_USER) ? '<i class="fas fa-user icon-user-list" title="Utilisateur" ></i>' :  '<i class="fas fa-user-shield icon-user-list" title="Modérateur"></i>')."</td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>
			<button onclick='getUserDetails(\"".htmlentities($value['mail'], ENT_QUOTES)."\");' class='cta-more-details cta-more-details-user-moderator' title='+ détails'><i class='fas fa-eye'></i></button>
			<button onclick='deleteInUserListUsersAndModeratorsBannedWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-users-moderators-in-user-list' class='cta-delete-users-moderators-in-user-list' title='Supprimer cet utilisateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>
			</div>
            </td>
			</tr>";

			$i++;

        }
        
        return $listBannedOffset;
    }

    /**
     * 
     * recupere les utilisateurs et moderateurs banni
     * 
     * @param integer $offset offset de depart de la recherche
     * 
     * @return string si offset > 0 html créé
     * @return array $result si offset = 0 infos de l user
     * 
     * 
     */
    
    public function getBannedUsersAndModerators($offset){

        $select = array("s.nom", "s.prenom", "s.age", "s.mail", "s.adresse", "s.telephone", "s.ville", "s.code_postal", 
                        "s.description", "r.region_nom", "d.departement_nom", "ro.role", "s.verified AS etat", "s.is_banned AS statut");
        $tag = "s";
        $innerJoin = array(
                            "regions r ON r.id_region = s.id_region",
                            "departements d ON d.id_departement = s.id_departement",
                            "roles ro ON ro.id_role = s.id_role"
                        );
        $where = array("s.is_banned = ?"=>"TRUE");
        $orderByLimitOffset = array("ORDER BY s.nom ASC LIMIT 20 OFFSET ".$offset."");

        $result = $this->select($select, $where, $orderByLimitOffset, $innerJoin, $tag);

		if($offset > 0){
            return $this->displayBannedUsersAndModerators($result);
		}

		return $result;

    }

    /**
     * 
     * Crée le html des users et moderateurs bannis recherché
     * 
     * @param array $result infos de l user
     * 
     * @return string $listBanned html créé
     * 
     * 
     */

    public function displaySearchedBannedUsersAndModerators($result){

        $listBanned = "";
        $i = 0;
        
		foreach($result as $key => $value){
							
			$listBanned .= "<tr>
			<td>".htmlentities($value['nom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['prenom'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td>".(($value['role'] == NAME_ROLE_USER) ? '<i class="fas fa-user icon-user-list" title="Utilisateur" ></i>' :  '<i class="fas fa-user-shield icon-user-list" title="Modérateur"></i>')."</td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>
			<button onclick='getUserDetails(\"".htmlentities($value['mail'], ENT_QUOTES)."\");' class='cta-more-details cta-more-details-user-moderator' title='+ détails'><i class='fas fa-eye'></i></button>
			<button onclick='unbanInUserListUserModeratorWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='unban-user-moderator-in-user-list' class='cta-unban-in-user-list cta-unban-user-moderator-in-user-list' title='Débannir cet utilisateur' value='".$i."'><i class='fas fa-undo'></i></button>
			<button onclick='deleteInUserListUsersAndModeratorsBannedWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-user-in-user-list' class='cta-delete-user-in-user-list' title='Supprimer cet utilisateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>
			</div>
            </td>
			</tr>";

			$i++;
						
        }
        
        return $listBanned;
    }
    
    /**
     * 
     * compte tous les utilisateurs et moderateurs recherché dans la barre de recherche
     * 
     * @param string $value valeur de la barre de recherche
     * 
     * @return string user et moderateurs trouvé
     * 
     * 
     */

	public function getSearchedBannedUsers($value){

        $select = array("s.nom", "s.prenom", "s.age", "s.mail", "s.adresse", "s.telephone", "s.ville", "s.code_postal", 
                        "s.description", "r.region_nom", "d.departement_nom", "ro.role", "s.verified AS etat", "s.is_banned AS statut");
        $tag = "s";
        $innerJoin = array(
                            "regions r ON r.id_region = s.id_region",
                            "departements d ON d.id_departement = s.id_departement",
                            "roles ro ON ro.id_role = s.id_role"
                        );
        $where = array(
                        "(lower(s.nom) LIKE lower(?)"=>"".$value."%",
                        "OR lower(s.prenom) LIKE lower(?)"=>"".$value."%",
                        "OR lower(s.mail) LIKE lower(?)"=>"".$value."%",
                        "OR lower(ro.role) LIKE lower(?))"=>"".$value."%",
                        "AND s.is_banned = ?"=>"TRUE"
                    );
        $orderBy = array("ORDER BY s.nom ASC");

        $result = $this->select($select, $where, $orderBy, $innerJoin, $tag);

        return $this->displaySearchedBannedUsersAndModerators($result);

    }

    /**
     * 
     * recupere le nombre de nouvelles inscription par jour en moyenne
     * 
     * @return float moyenne de nouvelles inscription par jour
     * 
     * 
     */

     public function countAverageNewSignUpPerDay(){

        $select_first_date = array("MIN(sign_up_date)");

        $first_date = $this->select($select_first_date);

        $today = date("Y-m-d H:i:s");

        $totalUsers = $this->countAllUsers();

        if(empty($first_date) || $totalUsers == 0){
            return 0;
        }

        $first_date = strtotime($first_date[0]["min"]);
        $today = strtotime($today);

        $daysBetweenFirstDateAndToday = ($today - $first_date) / 86400;
        
        return round($totalUsers / $daysBetweenFirstDateAndToday, 1);

     }

     /**
      * 
      * recupere l'id d un user
      *
      * @param string $mail mail de l user
      *
      * @return integer id de l user 
      *
      *
      */

    public function selectUserId($mail){

        $select = array("id");
        $where = array("mail = ?"=>$mail);

        $result = $this->select($select, $where);

        return $result[0]["id"];

    }

}