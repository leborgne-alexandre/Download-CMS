<?php
class Stats_visited_pages extends ConnectBDD{

    public $day;
    public $count = 1;

    public function setDay($day){
        $this->day = trim($day);
    }

    public function getDay(){
        return $this->day;
    }

    public function setCount($count){
        $this->count = $count;
    }

    public function getCount(){
        return $this->count;
    }

    /**
     * 
     * Commence le processus de stats
     * 
     * 
     */

    public function start($slug){

        $today = getdate();

        $theDay = $today["weekday"];

        $currentDay = $this->selectDay($theDay);

        $pages = new Pages();
        $announces = new Annonces();
        $isPageSlugExists = $pages->checkIfSlugExists($slug);
        $isAnnounceSlugExists = $announces->checkIfSlugExists($slug);

        if($isPageSlugExists || $isAnnounceSlugExists){
            if($currentDay){
                $this->updateDayCounter($theDay);
            }else{
                $this->insertNewDay($theDay);
            }
        }

    }

    /**
     * 
     * verifie que le jour est bien en bdd
     * 
     * @param string $day jour a verifier
     * 
     * @return boolean true si deja présent
     * 
     * 
     */

     public function selectDay($day){
        
        $select = array("day");
        $where = array("day = ?"=>$day);

        $result = $this->select($select, $where);

        if(empty($result))
            return false;

        return true;

     }

     /**
      *
      * insert un nouveau jour
      *
      * @param string $day jour a insérer
      *
      *
      *
      */

      public function insertNewDay($day){

        $this->setDay($day);

        $this->insert();

      }

      /**
      *
      * recupere le counter
      *
      * @param string $day jour ou le counter doit etre recuperer
      *
      *
      *
      */

      public function selectDayCounter($day){

        $select = array("count");
        $where = array("day = ?"=>$day);

        $result = $this->select($select, $where);

        if(!empty($result)){
            return $result[0]["count"];
        }

        return 0;
    
     }

      /**
      *
      * met a jour le counter
      *
      * @param string $day jour a insérer
      *
      *
      *
      */

      public function updateDayCounter($day){

        $counter = $this->selectDayCounter($day);
        $set = array("count"=>$counter + 1);
        $where = array("day = ?"=>$day);

        $this->update($set, $where);

      }

}