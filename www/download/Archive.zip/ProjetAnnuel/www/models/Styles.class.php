<?php

//declare (strict_types=1);

class Styles extends ConnectBDD{
	use style__style_hover;
	use element_style__style_hover;

	public $id_element;
	public $id_page;
	public $color = "";
	public $background__color = "";
	public $text__align = "";
	public $contenu = "";
	public $placeholder = "";
	public $box__shadow = "";
	public $border = "";
	public $border__top = "";
	public $border__bottom = "";
	public $border__left = "";
	public $border__right = "";
	public $border__radius = "";
	public $border__top__left__radius = "";
	public $border__bottom__left__radius = "";
	public $border__top__right__radius = "";
	public $border__bottom__right__radius = "";
	public $font__family = "";
	public $font__size = "";
	public $background = "";
	public $background__image = "";
	public $transition = "";
	public $edit_text_enable = 0;

	public function setElementId($idElement){
		$this->id_element = $idElement;
	}

	public function getElementId(){
		return $this->id_element;
	}

	public function setPageId($idPage){
		$this->id_page = $idPage;
	}

	public function getPageId(){
		return $this->id_page;
	}

	public function setColor($color){
		$this->color = trim($color);
	}

	public function getColor(){
		return $this->color;
	}

	public function setBackgroundColor($backgroundColor){
		$this->background__color = trim($backgroundColor);
	}

	public function getBackgroundColor(){
		return $this->background__color;
	}

	public function setTextAlign($textAlign){
		$this->text__align = trim($textAlign);
	}

	public function getTextAlign(){
		return $this->text__align;
	}

	public function setContain($contain){
		$this->contenu = $contain;
	}

	public function getContain(){
		return $this->contenu;
	}

	public function setPlaceholder($placeholder){
		$this->placeholder = trim($placeholder);
	}

	public function getPlaceholder(){
		return $this->placeholder;
	}

	public function setBoxShadow($boxShadow){
		$this->box__shadow = trim($boxShadow);
	}

	public function getBoxShadow(){
		return $this->box__shadow;
	}

	public function setBorder($border){
		$this->border = trim($border);
	}

	public function getBorder(){
		return $this->border;
	}

	public function setBorderTop($borderTop){
		$this->border__top = trim($borderTop);
	}

	public function getBorderTop(){
		return $this->border__top;
	}

	public function setBorderBottom($borderBottom){
		$this->border__bottom = trim($borderBottom);
	}

	public function getBorderBottom(){
		return $this->border__bottom;
	}

	public function setBorderLeft($borderLeft){
		$this->border__left = trim($borderLeft);
	}

	public function getBorderLeft(){
		return $this->border__left;
	}

	public function setBorderRight($borderRight){
		$this->border__right = trim($borderRight);
	}

	public function getBorderRight(){
		return $this->border__right;
	}

	public function setBorderRadius($borderRadius){
		$this->border__radius = trim($borderRadius);
	}

	public function getBorderRadius(){
		return $this->border__radius;
	}

	public function setBorderTopLeftRadius($borderTopLeftRadius){
		$this->border__top__left__radius = trim($borderTopLeftRadius);
	}

	public function getBorderTopLeftRadius(){
		return $this->border__top__left__radius;
	}

	public function setBorderBottomLeftRadius($borderBottomLeftRadius){
		$this->border__bottom__left__radius = trim($borderBottomLeftRadius);
	}

	public function getBorderBottomLeftRadius(){
		return $this->border__bottom__left__radius;
	}

	public function setBorderTopRightRadius($borderTopRightRadius){
		$this->border__top__right__radius = trim($borderTopRightRadius);
	}

	public function getBorderTopRightRadius(){
		return $this->border__top__right__radius;
	}

	public function setBorderBottomRightRadius($borderBottomRightRadius){
		$this->border__bottom__right__radius = trim($borderBottomRightRadius);
	}

	public function getBorderBottomRightRadius(){
		return $this->border__bottom__right__radius;
	}

	public function setFontFamily($fontFamily){
		$this->font__family = trim($fontFamily);
	}

	public function getFontFamily(){
		return $this->font__family;
	}

	public function setFontSize($fontSize){
		$this->font__size = trim($fontSize);
	}

	public function getFontSize(){
		return $this->font__size;
	}

	public function setBackground($background){
		$this->background = trim($background);
	}

	public function getBackground(){
		return $this->background;
	}

	public function setBackgroundImage($backgroundImage){
		$this->background__image = trim($backgroundImage);
	}

	public function getBackgroundImage(){
		return $this->background__image;
	}

	public function setTransition($transition){
		$this->transition = trim($transition);
	}

	public function getTransition(){
		return $this->transition;
	}

	public function setEditTextEnable($is_enable){
		$this->edit_text_enable = $is_enable;
	}

	public function getEditTextEnable(){
		return $this->edit_text_enable;
	}

	/**
	 * 
	 * Casse le css de "border" pour recuperer chaque partie
	 * 
	 * @param string $string border au format css
	 * 
	 * @return array valeurs css splité
	 * 
	 * 
	 * 
	 */

	public function breakCssBorderString($string){

		$sizeArray = explode('px', $string);
		$size = $sizeArray[0];
		$type = $sizeArray[1];
		$typeArray = explode('#', $type);
		$type = $typeArray[0];
		$color = $typeArray[1];

		return ["size"=>trim($size), "type"=>trim($type), "color"=>"#".trim($color)];
	}

	/**
	 * 
	 * Recupere uniquement la valeur d une taille en pixel
	 * 
	 * @param string $string valeur avec px
	 * 
	 * @return string $value valeur sans px
	 * 
	 * 
	 * 
	 */

	public function getValueOnly($string){

		$value = explode('px', $string);

		return $value[0];

	}

	/**
	 * 
	 * Recupere le contenu et le placeholder
	 * 
	 * @param string $string valeur avec px
	 * 
	 * @return string $value valeur sans px
	 * 
	 * 
	 * 
	 */

	public function getSecureContain($value){

		return htmlentities($value, ENT_QUOTES);

	}

	/**
     * 
	 *	check si l edit du texte est activer ou non sur un element
	 *
     *	@param integer $idElement id de l element a verifier 
     *
	 * 	@return boolean true si activé et false si non activé
	 * 
     *
	 */

	 public function checkEditTextEnable($idElement){

		$select = array("edit_text_enable");
		$where = array("id_element = ?"=>$idElement);

		$result = $this->select($select, $where);

		return $result[0];

	 }

	/**
	 * 
	 * Recupere le nom de la police
	 * 
	 * @param string $string valeur police en forme css
	 * 
	 * @return string $value nom de la police
	 * 
	 * 
	 * 
	 */

	public function getFontFamilyName($string = NULL){

		$fontFamilyList = [
			"arial, sans serif"=>"Arial",
			"helvetica, sans-serif"=>"Helvetica",
			"verdana, sans-serif"=>"Verdana",
			"trebuchet ms, sans-serif"=>"Trebuchet MS",
			"gill sans, sans-serif"=>"Gill Sans",
			"noto sans, sans-serif"=>"Noto Sans",
			"avantgarde, tex gyre adventor, urw gothic l, sans-serif"=>"Avantgarde",
			"optima, sans-serif"=>"Optima",
			"arial narrow, sans-serif"=>"Arial Narrow",
			"times, times new roman, serif"=>"Times New Roman",
			"didot, serif"=>"Didot",
			"georgia, serif"=>"Georgia",
			"palatino, urw palladio l, serif"=>"Palatino",
			"bookman, urw bookman l, serif"=>"Bookman",
			"new century schoolbook, tex gyre schola, serif"=>"New Century Schoolbook",
			"american typewriter, serif"=>"American Typewriter",
			"andale mono, monospace"=>"Andale Mono",
			"courier new, monospace"=>"Courier New",
			"courier, monospace"=>"Courier",
			"ocr a std, monospace"=>"OCR A Std",
			"dejavu sans mono, monospace"=>"DejaVu Sans Mono",
			"monospace"=>"Monospace",
			"comic sans ms, comic sans, cursive"=>"Comic Sans MS Cursive",
			"apple chancery, cursive"=>"Apple Chancery",
			"bradley hand, cursive"=>"Bradley Hand",
			"brush script mt, brush script std, cursive"=>"Brush Script MT",
			"snell roundhand, cursive"=>"Snell Roundhand",
			"urw chancery l, cursive"=>"URW Chancery L",
			"cursive"=>"Cursive",
			"impact, fantasy"=>"Impact",
			"luminari, fantasy"=>"Luminari",
			"chalkduster, fantasy"=>"Chalkduster",
			"jazz let, fantasy"=>"Jazz LET",
			"blippo, fantasy"=>"Blippo",
			"stencil std, fantasy"=>"Stencil Std",
			"marker felt, fantasy"=>"Marker Felt",
			"trattatello, fantasy"=>"Trattatello",
			"fantasy"=>"Fantasy"
		];

		$arrayKeys = array_keys($fontFamilyList);

		$options = '';

		foreach($arrayKeys as $key => $value){
			if($string != NULL && strtolower(str_replace("&sbquo;", ",", $string)) == $value){
				$options .= "<option style='font-family: ".$value."' value='".$value."' selected='selected'>".$fontFamilyList[$value]."</option>";
			}else{
				$options .= "<option style='font-family: ".$value."' value='".$value."' >".$fontFamilyList[$value]."</option>";
			}
		}

		return $options;
	}

	/**
	 * 
	 * Casse le css d un "shadow" pour recuperer chaque partie
	 * 
	 * @param string $string valeur box-shadow en forme css
	 * 
	 * @return array valeurs chaque partie qui compose l ombre
	 * 
	 * 
	 * 
	 */

	 public function breakShadowString($string){

		(preg_match("/[inset]/", $string)) ? $inset = 1 : $inset = 0;
		
		$arrayShadow = explode('px', $string);
		$valueXAxis = $arrayShadow[0];
		$valueYAxis = $arrayShadow[1];
		$valueBlur = $arrayShadow[2];

		if(isset($arrayShadow[4]) && !isset($arrayShadow[5])){
			$valueSpread = $arrayShadow[3];
			$color = $arrayShadow[4];
			$color = explode(" ", $color);
			$color = $color[1];

			if($inset == 1)
				return ["xAxis"=>trim($valueXAxis), "yAxis"=>trim($valueYAxis), "blur"=>trim($valueBlur), "spread"=>trim($valueSpread), "color"=>trim($color), "inset"=>1];
			
			return ["xAxis"=>trim($valueXAxis), "yAxis"=>trim($valueYAxis), "blur"=>trim($valueBlur), "spread"=>trim($valueSpread), "color"=>trim($color), "inset"=>0];
		}elseif(!isset($arrayShadow[5]) && !isset($arrayShadow[4])){
			$color = $arrayShadow[3];
			$color = explode(" ", $color);
			$color = $color[1];

			if($inset == 1)
				return ["xAxis"=>trim($valueXAxis), "yAxis"=>trim($valueYAxis), "blur"=>trim($valueBlur), "spread"=>0, "color"=>trim($color), "inset"=>1];
			
			return ["xAxis"=>trim($valueXAxis), "yAxis"=>trim($valueYAxis), "blur"=>trim($valueBlur), "spread"=>0, "color"=>trim($color), "inset"=>0];
		}

	 }

	 /**
	 * 
	 * Recupere les styles et transitions séparement deja presents avant l update
	 * 
	 * @param string $initialStylesAndTransitions le champ transition initial avant l update
	 * 
	 * @return array $arraySeparateStylesAndTransitions tableau associatif des styles et des trnasitions initial
	 * 
	 * 
	 */

	public function getSeparateStylesAndTransitions($stylesAndTransitions){

		$getKeyAndTransition = explode("&amp;sbquo; ", $stylesAndTransitions);

		$arraySeparateStylesAndTransitions = [];
		foreach($getKeyAndTransition as $key => $value){

			$styleAndTransition = explode(" ", $value);
			$style = $styleAndTransition[0];
			$transition = $styleAndTransition[1];

			$arraySeparateStylesAndTransitions[$style] = $transition;

		}

		return $arraySeparateStylesAndTransitions;
	 }

	 /**
	 * 
	 * Recupere chaque element en hover avec leur temps de transition correspondant
	 * 
	 * @param string $string valeur transition en forme css
	 * 
	 * @return array valeurs chaque partie qui compose les elements en transition
	 * 
	 * 
	 * 
	 */

	 public function parseTransitionHover($string){

		$hover = [];

		if(!empty($string)){

			$separatedKeyAndTransition = $this->getSeparateStylesAndTransitions($string);

			$keys = array_keys($separatedKeyAndTransition);
			$values = array_values($separatedKeyAndTransition);
	
			$hover = [];
			for($i = 0; $i < sizeof($separatedKeyAndTransition); $i++){
				$hover[$keys[$i]] = str_replace("s", "", $values[$i]);
			}

			return $hover;
		}
			
		return $hover;

	 }
	
	/**
     * 
     * recupere les styles qui sont editables
     * 
     * @param integer id de l element
     * 
     * @return string champs avec elements modifiables
     * 
     * 
     */
    
    public function getEditableStyles($idElement){

        $idElement = (int)$idElement;
        
        $select = array("*");
        $where = array("id_element = ?"=>$idElement);

        $result = $this->select($select, $where);

		$displayFieldsColors = "";
		$displayFieldsBorders = "";
		$displayFieldsText = "";
		$displayFieldsShadow = "";
		$displayFieldsBackground = "";
		$displayFieldsAnimation = "";

		$fieldsColors = array("color"=>"Couleur du texte :", "background-color"=>"Couleur de fond :");
		$fieldsBorders = array("border"=>"Bordure entière :", "border-top"=>"Bordure haute :", "border-bottom"=>"Bordure basse :", 
								"border-left"=>"Bordure gauche :", "border-right"=>"Bordure droite :", "border-radius"=>"Rayon entier :", 
								"border-top-left-radius"=>"Rayon haut-gauche :", "border-top-right-radius"=>"Rayon haut-droit :", 
								"border-bottom-left-radius"=>"Rayon bas-gauche :", "border-bottom-right-radius"=>"Rayon bas-droite :");
		$fieldsText = array("contenu"=>"Texte :", "placeholder"=>"Placeholder :", "text-align"=>"Alignement du texte :", "font-family"=>"Police :", "font-size"=>"Taille de la police :");
		$fieldsShadow = array("box-shadow"=>"Ombrage :");
		$fieldsBackground = array("background-image"=>"Sélectionner une image :");
		$fieldsAnimation = array("transition"=>"Elements à animer en hover :");
		
		$is_text_enabled = $result[0]["edit_text_enable"];

		foreach($result[0] as $key => $value){

			$value = htmlentities($value, ENT_QUOTES);

			if(in_array($key, array_keys($fieldsColors))){
				$displayFieldsColors .= $this->getEditColor($idElement, $key, $value, $fieldsColors);
			}

			if(in_array($key, array_keys($fieldsBorders))){
				$displayFieldsBorders .= $this->getEditBorder($idElement, $key, $value, $fieldsBorders);
			}

			if(in_array($key, array_keys($fieldsText))){
				$displayFieldsText .= $this->getEditText($idElement, $key, $value, $fieldsText, $is_text_enabled);
			}

			if(in_array($key, array_keys($fieldsShadow))){
				$displayFieldsShadow .= $this->getEditShadow($idElement, $key, $value, $fieldsShadow);
			}

			if(in_array($key, array_keys($fieldsBackground))){
				$displayFieldsBackground .= $this->getEditBackground($idElement, $key, $value, $fieldsBackground);
			}

			if(in_array($key, array_keys($fieldsAnimation))){

				$elementsInHoverAndAnimationTime = $this->parseTransitionHover($value);

				$displayFieldsAnimation .= "<div class='title-styles-in-edition'><h2>".$fieldsAnimation[$key]."</h2></div>
				<div class='editable-style-input flex column' id='editable-style-".$key."-".$idElement."'>";

				///////	ANIMATION COULEUR
				$displayFieldsAnimation .= $this->getEditColorHover($idElement, $key, $value, $elementsInHoverAndAnimationTime);

				///////	ANIMATION COULEUR DE FOND
				$displayFieldsAnimation .= $this->getEditBackgroundColorHover($idElement, $key, $value, $elementsInHoverAndAnimationTime);

				//// BOX-SHADOW
				$displayFieldsAnimation .= $this->getEditShadowHover($idElement, $key, $value, $elementsInHoverAndAnimationTime);

				//// BORDER
				$displayFieldsAnimation .= $this->getEditBorderHover($idElement, $key, $value, $elementsInHoverAndAnimationTime);

				$displayFieldsAnimation .= "</div>";
			}
		}

		$styleFields = "";

		$elementsTable = new Elements();
		$elementType = $elementsTable->getElementType($idElement);

		if($elementType == "link"){
			$redirection = $elementsTable->getElementLink($idElement);
			$isExternal = $elementsTable->checkIfUrlValid($redirection);

			$styleFields .= "<div class='link-part flex column'><div class='title-styles-in-edition'><h2>Redirection :</h2></div>
			<input class='link-input' type='text' id='text-edit-link' value='".$redirection."' onchange='linkField(this, ".$idElement.");'>
			<div id='response-link-field'></div>
			<div class='flex space-between choose-url-type-box'>";
			if($isExternal){
				$styleFields .= "<div><input type='radio' id='external-url' value='external' name='choose-link-type' onchange='linkField(this, ".$idElement.", this.value);' checked='checked' /><label for='external-url'>Externe</label></div>
				<div><input type='radio' id='internal-url' value='internal' name='choose-link-type' onchange='linkField(this, ".$idElement.", this.value);'/><label for='internal-url'>Interne</label></div>";
			}else{
				$styleFields .= "<div><input type='radio' id='external-url' value='external' name='choose-link-type' onchange='linkField(this, ".$idElement.", this.value);' /><label for='external-url'>Externe</label></div>
				<div><input type='radio' id='internal-url' value='internal' name='choose-link-type' onchange='linkField(this, ".$idElement.", this.value);' checked='checked' /><label for='internal-url'>Interne</label></div>";
			}
			$styleFields .= "</div></div>";
		}elseif($elementType == "image"){
			$link = $elementsTable->getElementLink($idElement);
			$styleFields .= "<div id='box-edit-media-edit-menu' class='flex column'>
			<div class='title-styles-in-edition'><h2>Image sélectionnée :</h2></div>
			<div id='preview-image-edit-menu' class='preview-media-edit-menu' data-idelement='".$idElement."' style='background-image: url(".$link.");' ></div>
			<input type='button' class='select-media-edit-menu' id='select-image-edit-menu' value='Sélectionner une image' onclick='getMediasToAdd(\"image\", true);'/>
			<div id='display-media-list-edit-menu' class='display-media-list hidden'></div>
			</div>";
		}elseif($elementType == "video"){
			$link = $elementsTable->getElementLink($idElement);
			$styleFields .= "<div id='box-edit-media-edit-menu' class='flex column'>
			<div class='title-styles-in-edition'><h2>Vidéo sélectionnée :</h2></div>
			<video id='preview-video-edit-menu' class='preview-media-edit-menu' data-idelement='".$idElement."' src='".$link."' autoload loop muted></video>
			<input type='button' class='select-media-edit-menu' id='select-image-edit-menu' value='Sélectionner une vidéo' onclick='getMediasToAdd(\"video\", true);'/>
			<div id='display-media-list-edit-menu' class='display-media-list hidden'></div>
			</div>";
		}

		$styleFields .= "<div class='part-title-styles-in-edition'><h1>Couleurs</h1></div>";
		$styleFields .= $displayFieldsColors;
		$styleFields .= "<hr class='line-between-styles-parts'>";
		$styleFields .= "<div class='part-title-styles-in-edition'><h1>Bordures</h1></div>";
		$styleFields .= $displayFieldsBorders;
		$styleFields .= "<hr class='line-between-styles-parts'>";
		$styleFields .= "<div class='part-title-styles-in-edition'><h1>Texte</h1></div>";
		$styleFields .= $displayFieldsText;
		$styleFields .= "<hr class='line-between-styles-parts'>";
		$styleFields .= "<div class='part-title-styles-in-edition'><h1>Ombrage</h1></div>";
		$styleFields .= $displayFieldsShadow;
		$styleFields .= "<hr class='line-between-styles-parts'>";
		$styleFields .= "<div class='part-title-styles-in-edition'><h1>Fond</h1></div>";
		$styleFields .= $displayFieldsBackground;
		$styleFields .= "<hr class='line-between-styles-parts'>";
		$styleFields .= "<div class='part-title-styles-in-edition'><h1>Animation</h1></div>";
		$styleFields .= $displayFieldsAnimation;

		return $styleFields;

	 }

	 /**
	 * 
	 * Crée le html de l edition de la couleur
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $fieldsColors tableau de tout les elements dont la couleur est modifiable
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	 public function getEditColor($idElement, $key, $value, $fieldsColors){

		$html = "";

		$html .= "<div class='title-styles-in-edition'><h2>".$fieldsColors[$key]."</h2></div>
		<div class='editable-style-input flex space-between' id='editable-style-".$key."-".$idElement."'>";
		if(empty($value)) 
			$html .= "<input type='color' class='style-value-input' value='#000000' disabled='disabled' onchange='changeColor(this.value, ".$idElement.", \"$key\");' />";
		else
			$html .= "<input type='color' class='style-value-input' value='".$value."' onchange='changeColor(this.value, ".$idElement.", \"$key\");' />";
		$html .= "<label class='control control-checkbox' title='activer/désactiver' >";
		if(empty($value)) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-colors-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' />";
		else
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-colors-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' checked='checked' />";
		$html .= "<div class='control_indicator'></div></label>";
		$html .= "</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition de la bordure
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $fieldsBorders tableau de tout les elements dont la bordure est modifiable
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditBorder($idElement, $key, $value, $fieldsBorders){

		$html = "";

		$html .= "<div class='title-styles-in-edition'><h2>".$fieldsBorders[$key]."</h2></div>
				<div class='editable-style-input flex space-between' id='editable-style-".$key."-".$idElement."'>";

		if(empty($value) 
		&& ($key == "border-radius" 
		|| $key == "border-top-left-radius" 
		|| $key == "border-top-right-radius" 
		|| $key == "border-bottom-left-radius" 
		|| $key == "border-bottom-right-radius")){
			$html .= "<div class='flex stretch'>
			<input type='number' class='style-value-input field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' value='1' max='100' min='0' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"radius\");' disabled='disabled' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>";
		}elseif(!empty($value) 
		&& ($key == "border-radius" 
		|| $key == "border-top-left-radius" 
		|| $key == "border-top-right-radius" 
		|| $key == "border-bottom-left-radius" 
		|| $key == "border-bottom-right-radius")){

			$value = $this->getValueOnly($value);

			$html .= "<div class='flex stretch'>
			<input type='number' class='style-value-input field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' value='".$value."' max='100' min='0' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"radius\");' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>";
		}elseif(!empty($value) 
		&& ($key != "border-radius" 
		|| $key != "border-top-left-radius" 
		|| $key != "border-top-right-radius" 
		|| $key != "border-bottom-left-radius" 
		|| $key != "border-bottom-right-radius")){

			$brokeBorder = $this->breakCssBorderString($value);

			$html .= "<div class='main-border-options' id='main-border-options-".$key."-".$idElement."'>
			<div class='flex stretch border-size'>
			<label class='label-cat-option'><h3>Taille : </h3></label>
			<input type='number' value='".$brokeBorder["size"]."' class='field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' max='100' min='0' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"size\");' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex border-types'>
			<label class='label-cat-option label-type-border-option'><h3>Type : </h3></label>
			<label class='radio-border' id='solid-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "solid")
				$html .= "<input type='radio' name='type-".$key."' value='solid' id='radio-solid-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='solid' id='radio-solid-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Solid
			</label>
			<label class='radio-border' id='dotted-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "dotted")
				$html .= "<input type='radio' name='type-".$key."' value='dotted' id='radio-dotted-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='dotted' id='radio-dotted-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Dotted
			</label>
			<label class='radio-border' id='dashed-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "dashed")
				$html .= "<input type='radio' name='type-".$key."' value='dashed' id='radio-dashed-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='dashed' id='radio-dashed-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Dashed
			</label>
			<label class='radio-border' id='double-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "double")
				$html .= "<input type='radio' name='type-".$key."' value='double' id='radio-double-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='double' id='radio-double-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Double
			</label>
			<label class='radio-border' id='groove-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "groove")
				$html .= "<input type='radio' name='type-".$key."' value='groove' id='radio-groove-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='groove' id='radio-groove-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Groove
			</label>
			<label class='radio-border' id='ridge-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "ridge")
				$html .= "<input type='radio' name='type-".$key."' value='ridge' id='radio-ridge-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='ridge' id='radio-ridge-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Ridge
			</label>
			<label class='radio-border' id='inset-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "inset")
				$html .= "<input type='radio' name='type-".$key."' value='inset' id='radio-inset-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='inset' id='radio-inset-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Inset
			</label>
			<label class='radio-border' id='outset-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "outset")
				$html .= "<input type='radio' name='type-".$key."' value='outset' id='radio-outset-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='outset' id='radio-outset-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />";
			$html .= " Outset
			</label>
			</div>
			<div class='color-picker-border'>
			<label class='label-cat-option flex'>
			<h3>Couleur :</h3>
			<input type='color' value='".$brokeBorder["color"]."' class='small-color-picker' id='color-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"color\");' />
			</label>
			</div>
			</div>";

		}elseif(empty($value) 
		&& ($key != "border-radius" 
		|| $key != "border-top-left-radius" 
		|| $key != "border-top-right-radius" 
		|| $key != "border-bottom-left-radius" 
		|| $key != "border-bottom-right-radius")){
			$html .= "<div class='main-border-options hidden' id='main-border-options-".$key."-".$idElement."'>
			<div class='flex stretch border-size'>
			<label class='label-cat-option'><h3>Taille : </h3></label>
			<input type='number' value='1' class='field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' max='100' min='0' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"size\");' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex border-types'>
			<label class='label-cat-option label-type-border-option'><h3>Type : </h3></label>
			<label class='radio-border' id='solid-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='solid' id='radio-solid-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' checked='checked' />
			Solid
			</label>
			<label class='radio-border' id='dotted-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='dotted' id='radio-dotted-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Dotted
			</label>
			<label class='radio-border' id='dashed-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='dashed' id='radio-dashed-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Dashed
			</label>
			<label class='radio-border' id='double-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='double' id='radio-double-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Double
			</label>
			<label class='radio-border' id='groove-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='groove' id='radio-groove-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Groove
			</label>
			<label class='radio-border' id='ridge-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='ridge' id='radio-ridge-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Ridge
			</label>
			<label class='radio-border' id='inset-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='inset' id='radio-inset-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Inset
			</label>
			<label class='radio-border' id='outset-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='outset' id='radio-outset-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"type\");' />
			Outset
			</label>
			</div>
			<div class='color-picker-border'>
			<label class='label-cat-option flex'>
			<h3>Couleur :</h3>
			<input type='color' class='small-color-picker' id='color-border-".$key."-".$idElement."' onchange='changeBorder(this, this.value, ".$idElement.", \"$key\", \"color\");' />
			</label>
			</div>
			</div>";

		}

		$html .= "<div class='cta-action-styles flex'><label class='control control-checkbox' title='activer/désactiver' >";
		if(empty($value)) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-borders-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' />";
		else
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-borders-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' checked='checked' />";
		$html .= "<div class='control_indicator'></div>
		</label>
		</div>
		</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition du texte
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $fieldsText tableau de tout les elements dont ce qui concerne du texte est modifiable
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditText($idElement, $key, $value, $fieldsText, $is_text_enabled){

		$html = "";

		$html .= "<div class='title-styles-in-edition'><h2>".$fieldsText[$key]."</h2></div>
		<div class='editable-style-input flex space-between' id='editable-style-".$key."-".$idElement."'>";
		if($key == "text-align" && (empty($value) || $value == "left")){ 
			$html .= "<div class='bloc-icons-text-align flex space-around' id='bloc-icons-text-align'>
			<i class='fas fa-align-left icons-text-align' title='Alignement à gauche' id='text-align-left' style='color: #6B6FD8;' onclick='selectTextAlign(this, \"left\", ".$idElement.");' ></i>
			<i class='fas fa-align-center icons-text-align' title='Centrer' id='text-align-center' onclick='selectTextAlign(this, \"center\", ".$idElement.");' ></i>
			<i class='fas fa-align-right icons-text-align' title='Alignement à droite' id='text-align-right' onclick='selectTextAlign(this, \"right\", ".$idElement.");' ></i>
			<i class='fas fa-align-justify icons-text-align' title='Alignement justifié' id='text-align-justify' onclick='selectTextAlign(this, \"justify\", ".$idElement.");' ></i>
			</div>";
		}elseif($key == "text-align" && ($value == "center")){
			$html .= "<div class='bloc-icons-text-align flex space-around' id='bloc-icons-text-align'>
			<i class='fas fa-align-left icons-text-align' title='Alignement à gauche' id='text-align-left' onclick='selectTextAlign(this, \"left\", ".$idElement.");' ></i>
			<i class='fas fa-align-center icons-text-align' title='Centrer' id='text-align-center' style='color: #6B6FD8;' onclick='selectTextAlign(this, \"center\", ".$idElement.");' ></i>
			<i class='fas fa-align-right icons-text-align' title='Alignement à droite' id='text-align-right' onclick='selectTextAlign(this, \"right\", ".$idElement.");' ></i>
			<i class='fas fa-align-justify icons-text-align' title='Alignement justifié' id='text-align-justify' onclick='selectTextAlign(this, \"justify\", ".$idElement.");' ></i>
			</div>";
		}elseif($key == "text-align" && ($value == "right")){
			$html .= "<div class='bloc-icons-text-align flex space-around' id='bloc-icons-text-align'>
			<i class='fas fa-align-left icons-text-align' title='Alignement à gauche' id='text-align-left' onclick='selectTextAlign(this, \"left\", ".$idElement.");' ></i>
			<i class='fas fa-align-center icons-text-align' title='Centrer' id='text-align-center' onclick='selectTextAlign(this, \"center\", ".$idElement.");' ></i>
			<i class='fas fa-align-right icons-text-align' title='Alignement à droite' id='text-align-right' style='color: #6B6FD8;' onclick='selectTextAlign(this, \"right\", ".$idElement.");' ></i>
			<i class='fas fa-align-justify icons-text-align' title='Alignement justifié' id='text-align-justify' onclick='selectTextAlign(this, \"justify\", ".$idElement.");' ></i>
			</div>";
		}elseif($key == "text-align" && ($value == "justify")){
			$html .= "<div class='bloc-icons-text-align flex space-around' id='bloc-icons-text-align'>
			<i class='fas fa-align-left icons-text-align' title='Alignement à gauche' id='text-align-left' onclick='selectTextAlign(this, \"left\", ".$idElement.");' ></i>
			<i class='fas fa-align-center icons-text-align' title='Centrer' id='text-align-center' onclick='selectTextAlign(this, \"center\", ".$idElement.");' ></i>
			<i class='fas fa-align-right icons-text-align' title='Alignement à droite' id='text-align-right' onclick='selectTextAlign(this, \"right\", ".$idElement.");' ></i>
			<i class='fas fa-align-justify icons-text-align' title='Alignement justifié' id='text-align-justify' style='color: #6B6FD8;' onclick='selectTextAlign(this, \"justify\", ".$idElement.");' ></i>
			</div>";
		}
		if(empty($value) && $key == "contenu")
			$html .= "<input type='text' id='edit-text-contain' class='style-value-input' disabled='disabled' onkeyup='changeTextContain(this.value, ".$idElement.")' />";
		elseif(!empty($value) && $key == "contenu")
			$html .= "<input type='text' class='style-value-input' value='".html_entity_decode($value)."' onkeyup='changeTextContain(this.value, ".$idElement.")' />";
		if(empty($value) && $key == "placeholder")
			$html .= "<input type='text' id='edit-placeholder-contain' class='style-value-input' disabled='disabled' onkeyup='changePlaceholderContain(this.value, ".$idElement.")' />";
		elseif(!empty($value) && $key == "placeholder")
			$html .= "<input type='text' class='style-value-input' value='".html_entity_decode($value)."' onkeyup='changePlaceholderContain(this.value, ".$idElement.")' />";
		if(!empty($value) && $key == "font-family"){
			$value = str_replace("&amp;sbquo;", ",", $value); 
			$optionFontFamily = $this->getFontFamilyName($value);
		}elseif(empty($value) && $key == "font-family"){
			$optionFontFamily = $this->getFontFamilyName();
		}
		if($key == "font-family"){
			$html .= "<select id='select-font-family' onchange='changeFontFamily(this.value, ".$idElement.")' >";
			$html .= $optionFontFamily;
			$html .= "</select>";
		}
		if(empty($value) && $key == "font-size")
			$html .= "<div class='flex stretch'>
			<input type='number' class='style-value-input field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' value='1' max='100' min='0' onchange='changeFontSize(this.value, ".$idElement.");' disabled='disabled' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>";
		elseif(!empty($value) && $key == "font-size"){

			$value = $this->getValueOnly($value);

			$html .= "<div class='flex stretch'>
			<input type='number' class='style-value-input field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' value='".$value."' max='100' min='0' onchange='changeFontSize(this.value, ".$idElement.");'/>
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>";
		}
		if($key != "text-align" && $key != "font-family")
			$html .= "<label class='control control-checkbox' title='activer/désactiver' >";
		if(empty($value) && $key != "text-align" && $key != "font-family" && $is_text_enabled) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-text-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' />";
		elseif(!empty($value) && $key != "text-align" && $key != "font-family" && $is_text_enabled) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-text-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' checked='checked' />";
		elseif(empty($value) && $key != "text-align" && $key != "font-family" && !$is_text_enabled) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-text-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' disabled='disabled' />";
		if($key != "text-align" && $key != "font-family")
			$html .= "<div class='control_indicator'></div></label>";
		$html .= "</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition de l ombre
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $fieldsShadow tableau de tout les elements dont le shadow est modifiable
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditShadow($idElement, $key, $value, $fieldsShadow){

		$html = "";

		if(!empty($value))
			$shadowValues = $this->breakShadowString($value);

		$html .= "<div class='title-styles-in-edition'><h2>".$fieldsShadow[$key]."</h2></div>
		<div class='editable-style-input flex column space-between' id='editable-style-".$key."-".$idElement."'>";
		if(empty($value)) 
			$html .= "<div class='main-shadow-options flex column hidden shadow-types' id='shadow-types' >";
		else
			$html .= "<div class='main-shadow-options flex column shadow-types' id='shadow-types'>";
		$html .= "<div class='flex stretch'>
		<label class='label-cat-option'><h3>Axe X : </h3></label>";
		if(!empty($value))
			$html .= "<input type='number' value='".$shadowValues["xAxis"]."' class='field-num-value-style-edition' id='xaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"xAxis\");' />";
		else
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='xaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"xAxis\");' />";
		$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
		</div>
		<div class='flex stretch'>
		<label class='label-cat-option'><h3>Axe Y : </h3></label>";
		if(!empty($value))
			$html .= "<input type='number' value='".$shadowValues["yAxis"]."' class='field-num-value-style-edition' id='yaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"yAxis\");' />";
		else
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='yaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"yAxis\");' />";
		$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
		</div>
		<div class='flex stretch'>
		<label class='label-cat-option'><h3>Flou : </h3></label>";
		if(!empty($value))
			$html .= "<input type='number' value='".$shadowValues["blur"]."' class='field-num-value-style-edition' id='blur-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"blur\");' />";
		else
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='blur-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"blur\");' />";
		$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
		</div>
		<div class='flex stretch'>
		<label class='label-cat-option'><h3>Propagation : </h3></label>";
		if(!empty($value))
			$html .= "<input type='number' value='".$shadowValues["spread"]."' class='field-num-value-style-edition' id='spread-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"spread\");' />";
		else
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='spread-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"spread\");' />";
		$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
		</div>
		<div>
		<label class='label-cat-option'><h3>Ombre intérieur ? </h3></label>";
		if(!empty($value) && $shadowValues['inset'] == 1)
			$html .= "<input type='checkbox' id='inset-shadow-option-".$key."-".$idElement."' checked='checked' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"inset\");' />";
		else
			$html .= "<input type='checkbox' id='inset-shadow-option-".$key."-".$idElement."' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"inset\");' />";
		$html .= "</div>
		<div class='flex stretch'>
		<label class='label-cat-option'><h3>Couleur : </h3></label>";
		if(!empty($value))
			$html .= "<input type='color' id='color-shadow-option-".$key."-".$idElement."' value='".$shadowValues["color"]."' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"color\");' />";
		else
			$html .= "<input type='color' id='color-shadow-option-".$key."-".$idElement."' onchange='changeShadow(this, this.value, ".$idElement.", \"$key\", \"color\");' />";
		$html .= "</div>
		</div>";
		$html .= "<div class='cta-action-styles flex'><label class='control control-checkbox' title='activer/désactiver' >";
		if(empty($value)) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-shadow-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' />";
		else
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-shadow-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' checked='checked' />";
		$html .= "<div class='control_indicator'></div>
		</label>
		</div>
		</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition du background
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $fieldsBackground tableau de tout les elements permettant de modifier le background
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditBackground($idElement, $key, $value, $fieldsBackground){

		$html = "";

		$html .= "<div class='title-styles-in-edition title-edit-background flex'><h2>".$fieldsBackground[$key]."</h2>";
		$html .= "<label class='control control-checkbox' title='activer/désactiver' >";
		if(empty($value)) 
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-background-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' />";
		else
			$html .= "<input type='checkbox' class='enable-disable-checkbox' id='enable-disable-checkbox-background-".$key."-".$idElement."' onclick='changeStyleStatut(this, \"$key\", ".$idElement.");' checked='checked' />";
		$html .= "<div class='control_indicator'></div>
		</label>
		</div>
		<div class='editable-style-input flex space-between' id='editable-style-".$key."-".$idElement."'>";
		if(empty($value)) 
			$html .= "<div id='box-edit-media-edit-menu-background' class='flex column'>
			<input type='button' class='select-media-edit-menu' data-idelement='".$idElement."' id='select-background-edit-menu' value='Sélectionner une image' onclick='getMediasToAdd(\"image\", true, true);' disabled='disabled'/>
			<div id='label-selected-image-background' class='title-styles-in-edition hidden'><h2>Image sélectionnée :</h2></div>
			<div id='preview-image-edit-menu-background' class='preview-media-edit-menu hidden' data-idelement='".$idElement."' ></div>
			<div id='display-media-list-edit-menu-background' class='display-media-list hidden'></div>
			</div>";
		else
			$html .= "<div id='box-edit-media-edit-menu-background' class='flex column'>
			<input type='button' class='select-media-edit-menu' data-idelement='".$idElement."' id='select-background-edit-menu' value='Sélectionner une image' onclick='getMediasToAdd(\"image\", true, true);'/>
			<div id='label-selected-image-background' class='title-styles-in-edition'><h2>Image sélectionnée :</h2></div>
			<div id='preview-image-edit-menu-background' class='preview-media-edit-menu' data-idelement='".$idElement."' style='background-image: ".$value.";' ></div>
			<div id='display-media-list-edit-menu-background' class='display-media-list hidden'></div>
			</div>
		</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition de la couleur en hover
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $elementsInHoverAndAnimationTime liste des elements modifié en hover avec leur temps de transition
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditColorHover($idElement, $key, $value, $elementsInHoverAndAnimationTime){

		$html = "";

		$html .= "<div class='item-hover-bloc' id='hover-color'>";
		if(!in_array("color", array_keys($elementsInHoverAndAnimationTime)))
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-color-hover' onclick='changeStyleStatut(this, \"colorHover\", ".$idElement.");' /> Couleur</label>
			<div class='bloc-edit-hover-item hidden'>";
		else
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-color-hover' onclick='changeStyleStatut(this, \"colorHover\", ".$idElement.");' checked='checked'/> Couleur</label>
			<div class='bloc-edit-hover-item'>";
		$html .= "<div class='flex column stretch'>
		<label class='label-cat-option'><h3>Couleur au hover : </h3></label>";
		if(!in_array("color", array_keys($elementsInHoverAndAnimationTime))){
			$html .= "<input type='color' onchange='changeColorHover(this.value, ".$idElement.");'/>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='1' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"color\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}else{

			$stylesHover = new Styles_hover();
			$color = $stylesHover->getHoverElementValue("color", $idElement);

			$html .= "<input type='color' value='".$color."' onchange='changeColorHover(this.value, ".$idElement.");'/>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='".$elementsInHoverAndAnimationTime["color"]."' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"color\");'/>
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}
		$html .= "</div>";
		$html .= "</div>
		</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition de la couleur de fond en hover
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $elementsInHoverAndAnimationTime liste des elements modifié en hover avec leur temps de transition
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditBackgroundColorHover($idElement, $key, $value, $elementsInHoverAndAnimationTime){

		$html = "";

		$html .= "<div class='item-hover-bloc' id='hover-background-color'>";
		if(!in_array("background-color", array_keys($elementsInHoverAndAnimationTime)))
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-background-color-hover' onclick='changeStyleStatut(this, \"backgroundColorHover\", ".$idElement.");' /> Couleur de fond</label>
			<div class='bloc-edit-hover-item hidden'>";
		else
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-background-color-hover' onclick='changeStyleStatut(this, \"backgroundColorHover\", ".$idElement.");' checked='checked' /> Couleur de fond</label>
			<div class='bloc-edit-hover-item'>";
		$html .= "<div class='flex column stretch'>
		<label class='label-cat-option'><h3>Couleur au hover : </h3></label>";
		if(!in_array("background-color", array_keys($elementsInHoverAndAnimationTime))){
			$html .= "<input type='color' onchange='changeBackgroundColorHover(this.value, ".$idElement.");'/>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='1' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"background-color\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}else{

			$stylesHover = new Styles_hover();
			$backgroundColor = $stylesHover->getHoverElementValue("background-color", $idElement);

			$html .= "<input type='color' value='".$backgroundColor."' onchange='changeBackgroundColorHover(this.value, ".$idElement.");'/>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='".$elementsInHoverAndAnimationTime["background-color"]."' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"background-color\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}
		$html .= "</div>";
		$html .= "</div>
		</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition de l ombre en hover
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $elementsInHoverAndAnimationTime liste des elements modifié en hover avec leur temps de transition
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditShadowHover($idElement, $key, $value, $elementsInHoverAndAnimationTime){

		$html = "";

		$html .= "<div class='item-hover-bloc' id='hover-box-shadow'>";
		if(!in_array("box-shadow", array_keys($elementsInHoverAndAnimationTime)))
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-shadow-hover' onclick='changeStyleStatut(this, \"shadowHover\", ".$idElement.");' /> Ombre</label>
			<div class='bloc-edit-hover-item hidden'>";
		else
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-shadow-hover' onclick='changeStyleStatut(this, \"shadowHover\", ".$idElement.");' checked='checked'/> Ombre</label>
			<div class='bloc-edit-hover-item'>";
		$html .= "<div class='flex column stretch shadow-types' id='shadow-types-hover'>";
		if(!in_array("box-shadow", array_keys($elementsInHoverAndAnimationTime))){
			$html .= "<div class='flex stretch'>
			<label class='label-cat-option'><h3>Axe X : </h3></label>";
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='xaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"xAxis\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Axe Y : </h3></label>";
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='yaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"yAxis\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Flou : </h3></label>";
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='blur-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"blur\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Propagation : </h3></label>";
			$html .= "<input type='number' value='1' class='field-num-value-style-edition' id='spread-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"spread\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<label class='label-cat-option'><h3>Ombre intérieur ? </h3>";
			$html .= "<input type='checkbox' id='inset-shadow-option-".$key."-".$idElement."' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"inset\");' />";
			$html .= "</label>
			<label class='label-cat-option'><h3>Couleur : </h3>";
			$html .= "<input type='color' id='color-shadow-option-".$key."-".$idElement."' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"color\");' />";
			$html .= "</label>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='1' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"box-shadow\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}else{

			$stylesHover = new Styles_hover();
			$shadow = $stylesHover->getHoverElementValue("box-shadow", $idElement);

			$shadowValues = $this->breakShadowString($shadow);

			$html .= "<div class='flex stretch'>
			<label class='label-cat-option'><h3>Axe X : </h3></label>";
			$html .= "<input type='number' value='".$shadowValues["xAxis"]."' class='field-num-value-style-edition' id='xaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"xAxis\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Axe Y : </h3></label>";
			$html .= "<input type='number' value='".$shadowValues["yAxis"]."' class='field-num-value-style-edition' id='yaxis-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"yAxis\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Flou : </h3></label>";
			$html .= "<input type='number' value='".$shadowValues["blur"]."' class='field-num-value-style-edition' id='blur-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"blur\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Propagation : </h3></label>";
			$html .= "<input type='number' value='".$shadowValues["spread"]."' class='field-num-value-style-edition' id='spread-shadow-option-".$key."-".$idElement."' max='100' min='-100' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"spread\");' />";
			$html .= "<label class='label-cat-option' id='label-size-unit-shadow-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<label class='label-cat-option'><h3>Ombre intérieur ? </h3>";
			if($shadowValues['inset'] == 1)
				$html .= "<input type='checkbox' id='inset-shadow-option-".$key."-".$idElement."' checked='checked' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"inset\");' />";
			else
				$html .= "<input type='checkbox' id='inset-shadow-option-".$key."-".$idElement."' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"inset\");' />";
			$html .= "</label>
			<label class='label-cat-option'><h3>Couleur au hover :</h3>";
			$html .= "<input type='color' id='color-shadow-option-".$key."-".$idElement."' value='".$shadowValues["color"]."' onchange='changeShadowHover(this, this.value, ".$idElement.", \"$key\", \"color\");' />";
			$html .= "</label>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='".$elementsInHoverAndAnimationTime["box-shadow"]."' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"box-shadow\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}
		$html .= "</div>";
		$html .= "</div>
		</div>";

		return $html;

	 }

	 /**
	 * 
	 * Crée le html de l edition de la bordure en hover
	 * 
	 * @param integer $idElement id de l element en edition
	 * @param integer $key nom du champ correspondant a un style 
	 * @param integer $value valeur du champs et donc du style
	 * @param array $elementsInHoverAndAnimationTime liste des elements modifié en hover avec leur temps de transition
	 * 
	 * @return string html créé
	 * 
	 * 
	 * 
	 */

	public function getEditBorderHover($idElement, $key, $value, $elementsInHoverAndAnimationTime){

		$html = "";

		$html .= "<div class='item-hover-bloc' id='hover-border'>";
		if(!in_array("border", array_keys($elementsInHoverAndAnimationTime)))
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-border-hover' onclick='changeStyleStatut(this, \"borderHover\", ".$idElement.");' /> Bordure</label>
			<div class='bloc-edit-hover-item hidden'>";
		else
			$html .= "<label class='label-cat-option'><input type='checkbox' id='checkbox-border-hover' onclick='changeStyleStatut(this, \"borderHover\", ".$idElement.");' checked='checked'/> Bordure</label>
			<div class='bloc-edit-hover-item'>";
		$html .= "<div class='flex column stretch' id='border-hover-elements' >";
		if(!in_array("border", array_keys($elementsInHoverAndAnimationTime))){
			$html .= "<div class='flex stretch border-size'>
			<label class='label-cat-option'><h3>Taille : </h3></label>
			<input type='number' value='1' class='field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' max='100' min='0' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"size\");' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex border-types'>
			<label class='label-cat-option label-type-border-option'><h3>Type : </h3></label>
			<label class='radio-border' id='solid-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='solid' id='radio-solid-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Solid
			</label>
			<label class='radio-border' id='dotted-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='dotted' id='radio-dotted-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Dotted
			</label>
			<label class='radio-border' id='dashed-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='dashed' id='radio-dashed-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Dashed
			</label>
			<label class='radio-border' id='double-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='double' id='radio-double-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Double
			</label>
			<label class='radio-border' id='groove-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='groove' id='radio-groove-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Groove
			</label>
			<label class='radio-border' id='ridge-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='ridge' id='radio-ridge-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Ridge
			</label>
			<label class='radio-border' id='inset-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='inset' id='radio-inset-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Inset
			</label>
			<label class='radio-border' id='outset-border-".$key."-".$idElement."'>
			<input type='radio' name='type-".$key."' value='outset' id='radio-outset-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />
			Outset
			</label>
			</div>
			<div class='color-picker-border'>
			<label class='label-cat-option flex'>
			<h3>Couleur :</h3>
			<input type='color' class='small-color-picker' id='color-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"color\");' />
			</label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='1' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"border\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}else{

			$stylesHover = new Styles_hover();
			$border = $stylesHover->getHoverElementValue("border", $idElement);

			$brokeBorder = $this->breakCssBorderString($border);

			$html .= "<div class='flex stretch border-size'>
			<label class='label-cat-option'><h3>Taille : </h3></label>
			<input type='number' value='".$brokeBorder["size"]."' class='field-num-value-style-edition' id='size-border-option-".$key."-".$idElement."' max='100' min='0' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"size\");' />
			<label class='label-cat-option' id='label-size-unit-border-option-".$key."-".$idElement."'><h3>px</h3></label>
			</div>
			<div class='flex border-types'>
			<label class='label-cat-option label-type-border-option'><h3>Type : </h3></label>
			<label class='radio-border' id='solid-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "solid")
				$html .= "<input type='radio' name='type-".$key."' value='solid' id='radio-solid-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='solid' id='radio-solid-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Solid
			</label>
			<label class='radio-border' id='dotted-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "dotted")
				$html .= "<input type='radio' name='type-".$key."' value='dotted' id='radio-dotted-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='dotted' id='radio-dotted-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Dotted
			</label>
			<label class='radio-border' id='dashed-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "dashed")
				$html .= "<input type='radio' name='type-".$key."' value='dashed' id='radio-dashed-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='dashed' id='radio-dashed-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Dashed
			</label>
			<label class='radio-border' id='double-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "double")
				$html .= "<input type='radio' name='type-".$key."' value='double' id='radio-double-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='double' id='radio-double-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Double
			</label>
			<label class='radio-border' id='groove-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "groove")
				$html .= "<input type='radio' name='type-".$key."' value='groove' id='radio-groove-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='groove' id='radio-groove-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Groove
			</label>
			<label class='radio-border' id='ridge-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "ridge")
				$html .= "<input type='radio' name='type-".$key."' value='ridge' id='radio-ridge-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='ridge' id='radio-ridge-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Ridge
			</label>
			<label class='radio-border' id='inset-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "inset")
				$html .= "<input type='radio' name='type-".$key."' value='inset' id='radio-inset-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='inset' id='radio-inset-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Inset
			</label>
			<label class='radio-border' id='outset-border-".$key."-".$idElement."'>";
			if($brokeBorder["type"] == "outset")
				$html .= "<input type='radio' name='type-".$key."' value='outset' id='radio-outset-border-".$key."-".$idElement."' checked='checked' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			else
				$html .= "<input type='radio' name='type-".$key."' value='outset' id='radio-outset-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"type\");' />";
			$html .= " Outset
			</label>
			</div>
			<div class='color-picker-border'>
			<label class='label-cat-option flex'>
			<h3>Couleur au hover :</h3>
			<input type='color' value='".$brokeBorder["color"]."' class='small-color-picker' id='color-border-".$key."-".$idElement."' onchange='changeBorderHover(this, this.value, ".$idElement.", \"border\", \"color\");' />
			</label>
			</div>
			<div class='flex stretch'>
			<label class='label-cat-option'><h3>Durée de la transition : </h3></label>
			<input type='number' step='0.1' class='style-value-input field-num-value-style-edition' id='time-transition-option-".$key."-".$idElement."' value='".$elementsInHoverAndAnimationTime["border"]."' max='100' min='0' onchange='changeTransitionTime(this.value, ".$idElement.", \"border\");' />
			<label class='label-cat-option' id='label-size-unit-time-option-".$key."-".$idElement."'><h3>sec</h3></label>
			</div>";
		}
		$html .= "</div>";
		$html .= "</div>
		</div>";

		return $html;

	 }

}