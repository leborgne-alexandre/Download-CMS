<?php

//declare (strict_types=1);

class Styles_hover extends ConnectBDD{
	use style__style_hover;
	use element_style__style_hover;

    public $id_element;
	public $id_page;
	public $color = "";
	public $background__color = "";
	public $box__shadow = "";
	public $border = "";

	public function setElementId($idElement){
		$this->id_element = $idElement;
	}

	public function getElementId(){
		return $this->id_element;
	}

	public function setPageId($idPage){
		$this->id_page = $idPage;
	}

	public function getPageId(){
		return $this->id_page;
	}

	public function setColor($color){
		$this->color = trim($color);
	}

	public function getColor(){
		return $this->color;
	}

	public function setBackgroundColor($backgroundColor){
		$this->background__color = trim($backgroundColor);
	}

	public function getBackgroundColor(){
		return $this->background__color;
    }

	public function setBoxShadow($boxShadow){
		$this->box__shadow = trim($boxShadow);
	}

	public function getBoxShadow(){
		return $this->box__shadow;
	}

	public function setBorder($border){
		$this->border = trim($border);
	}

	public function getBorder(){
		return $this->border;
	}

	/**
     * 
     * recupere les styles en hover de l element selectionné
     * 
     * @param string $styleName nom du champ (correspond au nom du style)
	 * @param integer $idElement id de l element selectionné
     * 
     * @return string valeur du style en hover trouvé
     * 
     * 
     */

	public function getHoverElementValue($styleName, $idElement){

		$select = array("\"$styleName\"");
        $where = array("id_element = ?"=>$idElement);

		$result = $this->select($select, $where);

		foreach($result[0] as $key => $value)
            return $value;

	}
    
}