<?php

class Templates extends ConnectBDD{

    public $nom;

    public function setName($name){
        $this->nom = $name;
    }

    public function getName(){
        return $this->nom;
    }

    /**
     * 
     * Recupere la liste de tout les templates
     * 
     * @return array $result liste de tout les templates
     * 
     * 
     */

    public function getAllTemplates(){

        $select = array("nom");

        $result = $this->select($select);

        return $result;
    }

    /**
     * 
     * recupere l id du template grace a son nom
     * 
     * @param string $templateName nom du template
     * 
     * @return integer $result id du template correspondant
     * 
     * 
     */

    public function getIdTemplateWithTemplateName($templateName){

        $select = array("id");
        $where = array("nom = ?"=>$templateName);

        $result = $this->select($select, $where);

        if(!empty($result))
            return $result[0]["id"];

        return 1;

     }

}
