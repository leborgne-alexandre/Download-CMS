<?php

//declare(strict_types=1);

class Usr extends ConnectBDD{
	use users;
	use global_security;

	public $username;
	public $password;
	public $mail;
	public $token = NULL;
	public $verified = 0;
	public $bdddownloaded = 0;
	public $verifaccountkey;
	public $id_role = ID_ROLE_ADMIN;
	public $is_banned = 0;

	public function __construct()
	{
		parent::__construct();
	}

	public function getUsername()
	{
		return $this->username;
	}

	public function setUsername($username)
	{
		$this->username = trim($username);
	}

	public function getPassword()
	{
		return $this->password;
	}

	public function setPassword($password)
	{
		$this->password = $password;
	}

	public function getMail()
	{
		return $this->mail;
	}

	public function setMail($mail)
	{
		$this->mail = trim($mail);
	}

	public function getVerifAccountKey()
	{
		return $this->verifaccountkey;
	}

	public function setVerifAccountKey($verifAccountKey)
	{
		$this->verifaccountkey = trim(htmlspecialchars($verifAccountKey));
	}

	/**
	 * 
	 * creation du formulaire de connexion
	 * 
	 * @return array formulaire
	 * 
	 * 
	 * 
	 */

	public function getLoginForm()
	{

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("Users", "validateLogin"),
				"class" => "form-login",
				"id" => "form-login",
				"submit" => "Se connecter"
			],

			"data" => [

				"mail" => [
					"type" => "email",
					"placeholder" => "eMail",
					"id" => "mail",
					"name" => "mail",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "L'eMail est invalide"
				],

				"password" => [
					"type" => "password",
					"placeholder" => "Mot de passe",
					"id" => "password",
					"name" => "password",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le mot de passe est incorrect"
				],

			]

		];
	}

	public function getSignUpForm()
	{

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("Users", "validateSignUp"),
				"class" => "form-sign-up",
				"id" => "form-sign-up",
				"submit" => "S'inscrire"
			],

			"data" => [

				"username" => [
					"type" => "text",
					"placeholder" => "Entrer un nom d'utilisateur",
					"id" => "username",
					"name" => "username",
					"class" => "form-elements",
					"maxlength" => 50,
					"required" => true,
					"error" => "Le nom d'utilisateur doit faire moins de 50 caractères"
				],

				"mail" => [
					"type" => "email",
					"placeholder" => "Entrer une adresse eMail",
					"id" => "mail",
					"name" => "mail",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "L'eMail est invalide ou doit faire moins de 100 caractères"
				],

				"password" => [
					"type" => "password",
					"placeholder" => "Entrer un mot de passe",
					"id" => "password",
					"name" => "password",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le mot de passe doit contenir au moins 7 caractères / 1 majuscule / 1 numéro"
				],

				"confirm-password" => [
					"type" => "password",
					"placeholder" => "Confirmer le mot de passe",
					"id" => "confirm-password",
					"name" => "confirm-password",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"confirm" => "password",
					"error" => "Les mots de passe ne sont pas identiques"
				]


			]
		];
	}

	/**
	 * 
	 * recupere le formulaire oublie de mot de passe
	 * 
	 * 
	 * @return array formulaire
	 * 
	 * 
	 */

	public function getForgetPasswordForm()
	{

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("Users", "validateForgetPassword"),
				"class" => "form-forget-password",
				"id" => "form-forget-password",
				"submit" => "Récupérer le mot de passe"
			],

			"data" => [

				"mail" => [
					"type" => "email",
					"placeholder" => "Adresse eMail",
					"id" => "mail",
					"name" => "mail",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "L'eMail est invalide"
				]

			]

		];
	}

	/**
     * 
     * recupere le formulaire reinitialisation de mot de passe
     * 
     * 
     * @return array formulaire
     * 
     * 
     */

	public function getResetPasswordForm(){

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("Users", "validateResetPassword"),
				"class" => "form-reset-password",
				"id" => "form-reset-password",
				"submit" => "Réinitialiser le mot de passe"
			],

			"data" => [

				"password" => [
					"type" => "password",
					"placeholder" => "Nouveau mot de passe",
					"id" => "password",
					"name" => "password",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le mot de passe doit contenir au moins 7 caractères / 1 majuscule / 1 numéro"
				],

				"confirm-password" => [
					"type" => "password",
					"placeholder" => "Confirmer le nouveau mot de passe",
					"id" => "confirm-password",
					"name" => "confirm-password",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "Les mots de passe ne sont pas identiques"
				]

			]

		];
	}

	/**
	 * 
	 * recupere le formulaire de configuration de l'email dans les parametres
	 * 
	 * 
	 * @return array formulaire
	 * 
	 * 
	 */
	public function getParameterChangeEmailForm()
	{

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("UserAccount", "validateParameterEmail"),
				"class" => "form-change-email",
				"id" => "form-change-email",
				"submit" => "Modifier l'Email"
			],

			"data" => [

				"mail" => [
					"type" => "email",
					"placeholder" => "Adresse Email",
					"id" => "mail",
					"name" => "mail",
					"class" => "formParameters-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "Email invalide"
				],

				"confirm-password" => [
					"type" => "password",
					"placeholder" => "Mot de passe",
					"id" => "confirm-password",
					"name" => "confirm-password",
					"class" => "formParameters-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le mot de passe est incorrect"
				]

			]

		];
	}

	/**
	 * 
	 * recupere le formulaire de configuration du mot de passe dans les parametres
	 * 
	 * 
	 * @return array formulaire
	 * 
	 * 
	 */
	public function getParameterChangePasswordForm()
	{

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("UserAccountPassword", "validateParameterChangePassword"),
				"class" => "form-reset-password",
				"id" => "form-reset-password",
				"submit" => "Changer mon mot de passe"
			],

			"data" => [

				"confirm-password" => [
					"type" => "password",
					"placeholder" => "Mot de passe actuel",
					"id" => "confirm-password",
					"name" => "confirm-password",
					"class" => "",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le mot de passe est incorrect"
				],

				"new-password" => [
					"type" => "password",
					"placeholder" => "Nouveau mot de passe",
					"id" => "new-password",
					"name" => "new-password",
					"class" => "",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le nouveau mot de passe doit contenir au moins 7 caractères / 1 majuscule / 1 numéro"
				],

				"confirm-new-password" => [
					"type" => "password",
					"placeholder" => "Confirmer le nouveau mot de passe",
					"id" => "confirm-new-password",
					"name" => "confirm-new-password",
					"class" => "",
					"maxlength" => 100,
					"required" => true,
					"error" => "Le nouveau mot de passe doit contenir au moins 7 caractères / 1 majuscule / 1 numéro"
				]
			]

		];
	}

	/**
	 * 
	 * recupere le formulaire de demande d un nouvel admin
	 * 
	 * 
	 * @return array formulaire
	 * 
	 * 
	 */

	public function getAskNewUserForm()
	{

		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("Users", "validateAskNewUserForm"),
				"class" => "form-ask-new-user",
				"id" => "form-ask-new-user",
				"submit" => "Envoyer demande d'ajout"
			],

			"data" => [

				"mail-user" => [
					"type" => "email",
					"placeholder" => "Entrer votre adresse eMail",
					"id" => "mail",
					"name" => "mail-user",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "L'eMail renseignée est invalide"
				],

				"mail-superadmin" => [
					"type" => "email",
					"placeholder" => "Entrer un mail SuperAdmin",
					"id" => "mail",
					"name" => "mail-superadmin",
					"class" => "form-elements",
					"maxlength" => 100,
					"required" => true,
					"error" => "L'eMail renseignée ne correspond pas à un SuperAdministrateur"
				]

			]

		];
	}

	/**
	 * 
	 * ajout d un admin
	 * 
	 * @param string $mail mail de l user
	 * @param bool $isFirstAdd true si c est la premiere inscription
	 * 
	 * @return bool true si add ok et false si add echoué
	 * 
	 * 
	 */

	public function addUser($mail, $isFirstAdd = FALSE, $firstAddSecretKey = ""){

		$askNewUser = new AskNewUser();

		if($isFirstAdd){
			$this->id_role = ID_ROLE_SUPERADMIN;
		}

		$secretKey = "";

		if($firstAddSecretKey == ""){
			$token = new Token();
			$secretKey = $token->token;
		}else{
			$secretKey = $firstAddSecretKey;
		}

		$this->setVerifAccountKey($secretKey);

		$this->password = password_hash($this->password, PASSWORD_DEFAULT);

		$isSent = false;

		if(!$isFirstAdd)
			$isSent = $askNewUser->sendValidationSignUpMail($mail, $secretKey);
		else
			$isSent = $askNewUser->sendValidationSignUpMail($mail, $secretKey, TRUE);

		try{
			$this->insert();
		} catch (Exception $e) {
			die("Erreur lors de l'enregistrement : " . $e->getMessage());
		}

		if($isSent){
			session_start();
			$_SESSION["validateSignUp"] = $mail;
			return true;
		} else {
			session_start();
			$_SESSION["errorValidateSignUp"] = $mail;
			return false;
		}
	}

	/**
	 * 
	 * mise a jour du mot de passe
	 * 
	 * @param string $password nouveau mot de passe
	 * @param string $mail mail de l user
	 * 
	 * 
	 * 
	 */

	public function updatePassword($password, $mail)
	{

		$password = password_hash($password, PASSWORD_DEFAULT);

		$set = ['password' => $password];
		$where = ['mail = ?' => $mail];

		$this->update($set, $where);
	}
	/**
	 * 
	 * mise a jour du mot de passe
	 * 
	 * @param string $password nouveau mot de passe
	 * @param string $mail mail de l user
	 * 
	 * 
	 * 
	 */

	public function CheckEqualPassword($newPassword, $confimNewPassword)
	{
		if (password_verify($newPassword, $confimNewPassword)) { } else {
			$this->errors[] = "Les mots de passes ne sont pas identiques";
		}
	}

	/**
	 * 
	 * bani un admin
	 * 
	 * @param string $mail mail de l user
	 * 
	 * 
	 * 
	 */

	public function banUser($mail)
	{

		$set = array('is_banned' => 'TRUE');
		$where = array('mail = ?' => $mail);

		$this->update($set, $where);
	}

	/**
	 * 
	 * débani un admin
	 * 
	 * @param string $mail mail de l user
	 * 
	 * 
	 * 
	 */

	public function unbanUser($mail)
	{

		$set = array('is_banned' => 'FALSE');
		$where = array('mail = ?' => $mail);

		$this->update($set, $where);
	}

	/**
	 * 
	 * supprime definitivement un admin bani
	 * 
	 * @param string $mail mail de l user
	 * 
	 * 
	 * 
	 */

	public function deleteBanned($mail)
	{

		$where = array('mail = ?' => $mail);

		$this->delete($where);
	}

	/**
	 * 
	 * verifie si quelqu un est deja enregistré
	 * 
	 * @return array admin si existe et vide si existe pas
	 * 
	 * 
	 */

	public function checkExistingUser()
	{

		$select = array("*");
		$where = NULL;
		$limit = array("LIMIT 1");

		return $this->select($select, $where, $limit);
	}

	/**
	 * 
	 * verifie si l admin existe en bdd
	 * 
	 * @param string $mail mail de l user
	 * 
	 * @return array admin si existe et vide si existe pas
	 * 
	 * 
	 * 
	 */

	public function checkUser($mail)
	{

		$select = array("*");
		$where = array("mail = ?" => $mail);

		return $this->select($select, $where);
	}

	/**
	 * 
	 * verifie si clé unique de verif de compte presente
	 * 
	 * @param string $mail mail de l user
	 * @param $key clé unique attribué a l admin
	 * 
	 * @return array admin si trouvé et vide si non trouvé
	 * 
	 * 
	 * 
	 */

	public function verifKeyAccount($mail, $key)
	{

		$select = array("*");
		$where = array("mail = ?" => $mail, "AND verifaccountkey = ?" => $key);

		return $this->select($select, $where);
	}

	/**
	 * 
	 * valide le compte admin
	 * 
	 * @param string $mail mail de l user
	 * 
	 * 
	 * 
	 */

	public function validateAccount($mail)
	{

		$set = array("verified" => TRUE, "verifaccountkey" => "");
		$where = array("mail = ?" => $mail);

		$this->update($set, $where);

		session_start();
		$_SESSION["validateAccount"] = $mail;
	}

	/**
     * 
     * crée les sessions utilisateur
     * 
     * @param string $mail mail de l user
     * @param string $token_value token de connexion
     * @param array $found_user infos du user
     * 
     * 
     * 
     */

	public function createSessions($found_user){

		session_start();
		$_SESSION['mail'] = $found_user[0]["mail"];
		$_SESSION['token_b'] = $found_user[0]["token"];
		$_SESSION['username'] = $found_user[0]["username"];
	}

	/**
	 * 
	 * Crée les cookies de l user
	 * 
	 * @param string $token_value valeur du cookie
	 * @param integer $time_cookie_token durée du cookie 
	 * 
	 * 
	 */

	 public function createCookies($token_value, $time_cookie_token){
		setcookie("token_b_kc", $token_value, time()+$time_cookie_token, "/", NULL, NULL, TRUE);
	 }
	
	/**
	 * 
	 * 	 * verifie si le compte admin est validé
	 * 
	 * @param string $mail mail de l user
	 * 
	 * @return array admin si validé et vide si non validé
	 * 
	 * 
	 * 
	 */

	public function verifIfUserValidated($mail)
	{

		$select = array("*");
		$where = array("mail = ?" => $mail, "AND verified = ?" => TRUE);

		return $this->select($select, $where);
	}

	/**
	 * 
	 * verifie si le token est present et valide 
	 * 
	 * @param string $token token de la session ou du cookie de session
	 * 
	 * @return array user si token ok ou vide si token pas ok
	 * 
	 * 
	 * 
	 */

	public function verifTokenAndValidated($token)
	{

		$select = array("*");
		$where = array("token = ?" => $token, "AND verified = ?" => TRUE);

		return $this->select($select, $where);
	}

	/**
	 * 
	 * acces au compte
	 * 
	 * @param string $mail mail de l user
	 * @param string $password mot de passe de l admin
	 * 
	 * 
	 * 
	 */

	/*public function access($mail, $password)
	{

		$found_user = $this->verifIfUserValidated($mail);

		if (empty($found_user)) {
			$this->errors[] = "L'eMail et/ou le mot de passe est incorrect";
		} else {
			if (password_verify($password, $found_user[0]["password"])) {
				$token = new Token();
				$token_value = $token->token;

				$set = array('token' => $token_value);
				$where = array('mail = ?' => $mail);

				$this->update($set, $where);

				session_start();

				$_SESSION['mail'] = $mail;
				$_SESSION['token_b'] = $token_value;
				$_SESSION['username'] = $found_user[0]["username"];

				$time_cookie_token = 86400; //1 jour

				setcookie("token_b_kc", $token_value, time() + $time_cookie_token, "/", NULL, NULL, TRUE);

				$blacklist = new Blacklist();
				$blacklist->resetCounter();

				if (isset($_GET['action'])) {
					header('Location: ' . $_GET['action'] . '');
				} else {
					header('Location: /zz-admin/dashboard');
				}
			} else {
				$blacklist = new Blacklist();
				$blacklist->incrementCounter();
				$this->errors[] = "L'eMail et/ou le mot de passe est incorrect";
			}
		}
	}*/

	public function checkMatchingPassword($mail, $pass)
	{
		$found_user = $this->verifIfUserValidated($mail);

		if (empty($found_user)) {
			$this->errors[] = "un problème est survenue";
		} else {
			if (password_verify($pass, $found_user[0]["password"])) { } else {
				$this->errors[] = "Le mot de passe est incorrect";
			}
		}
	}

	public function updateEmail($newEmail)
	{
		$set = ['mail' => $newEmail];
		$where = ['username = ?' => $_SESSION['username']];

		$this->update($set, $where);
		$cleanRefreshLogout = new cmsUserAccountController();
		$cleanRefreshLogout->logOutAction();
	}

	/**
	 * 
	 * verifie si admin deja connecté
	 * 
	 * @return bool true si deja connecté et false si non connecté
	 * 
	 * 
	 */

	public function checkIfUserConnected()
	{

		//session_start();

		if (isset($_SESSION['token_b']) || isset($_COOKIE['token_b_kc'])) {

			if (isset($_SESSION['token_b']) && isset($_COOKIE['token_b_kc'])) {
				$token = $_SESSION['token_b'];
			} elseif (isset($_SESSION['token_b']) && !isset($_COOKIE['token_b_kc'])) {
				$token = $_SESSION['token_b'];
			} elseif (!isset($_SESSION['token_b']) && isset($_COOKIE['token_b_kc'])) {
				$token = $_COOKIE['token_b_kc'];
			}

			$found_user = $this->verifTokenAndValidated($token);

			if (!empty($found_user)) {

				$this->createSessions($found_user);
				return true;
			}
				
			return false;

		}
			
		return false;
	}

	/**
	 * 
	 * recupere le statement du compte utilisateur (vérifié ou non)
	 * 
	 * 
	 * 
	 * @return string Vérifié si le compte de l'utilisateur est dans le state vérifié
	 * @return string Non-Vérifié si le compte de l'utilisateur est dans le state Non-vérifié
	 * 
	 * 
	 */
	public function getAccountUserState()
	{

		$select = array("s.verified AS etat");
		$tag = "s";
		$innerJoin = NULL;
		$orderByLimitOffset = NULL;

		$where = array("username = ?" => $_SESSION['username']);

		$result = $this->select($select, $where, $orderByLimitOffset, $innerJoin, $tag);

		if ($result = 1) {
			return 'Vérifié';
		} else {
			return 'Non Vérifié';
		}
	}
	
	/**
     * 
     * Crée le html des admin trouvé avec un nouveau offset
     * 
     * @param array $result infos de l admin
     * 
     * @return string $listAdminOffset html créé
     * 
     * 
     */

    public function displayAdminsWithNewOffset($result){

        $listAdminOffset = "";
		$i = 0;
			
		foreach($result as $key => $value){
								
			$listAdminOffset .= "<tr>
			<td>".htmlentities($value['username'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td><i class='fas fa-crown icon-user-list' title='Administrateur' ></i></td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>";

			if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN){
				$listAdminOffset .= "<button onclick='banInUserListAdminWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-admin-in-user-list' class='cta-delete-admin-in-user-list' title='Bannir cet administrateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>";
			}

			$listAdminOffset .= "</div>
			</tr>";

			$i++;
							
		}

		return $listAdminOffset;
    }

	/**
	 * 
	 * recupere l'email de l'utilisateur
	 * 
	 * @return string Retourne l'email en chaîne de caractère
	 * 
	 * 
	 */

	public function getAccountUserEmail()
	{

		$select = array("mail");
		$where = array("username = ?" => $_SESSION['username']);

		$mailUser = $this->select($select, $where);

		return (string)implode($mailUser[0]);
	}

	/**
	 * 
	 * recupere tous les admin
	 * 
	 * @param integer $offset offset de depart de la recherche
	 * 
	 * @return string si offset > 0 liste des users trouvé
	 * @return array $result si offset = 0 infos de l admin
     * 
     * 
     * 
     */

	public function getAdmin($offset)
	{

		$select = array("u.username", "u.mail", "ro.role", "u.verified AS etat", "u.is_banned AS statut");
		$tag = "u";
		$innerJoin = array("roles ro ON ro.id_role = u.id_role");
		$where = array("u.is_banned = ?"=>"FALSE", "AND u.id_role = ?"=>ID_ROLE_ADMIN);
		$orderByLimitOffset = array("ORDER BY u.username ASC LIMIT 20 OFFSET ".$offset."");

		$result = $this->select($select, $where, $orderByLimitOffset, $innerJoin, $tag);

		if($offset > 0){
			return $this->displayAdminsWithNewOffset($result);
		}

		return $result;
	}

	/**
     * 
     * Crée le html des admin recherché trouvé
     * 
     * @param array $result infos de l admin
     * 
     * @return string $listAdmin html créé
     * 
     * 
     */

    public function displaySearchedAdmins($result){

        $listAdmin = "";
		$i = 0;

		foreach($result as $key => $value){
							
			$listAdmin .= "<tr>
			<td>".htmlentities($value['username'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td><i class='fas fa-crown icon-user-list' title='Administrateur' ></i></td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>";

			if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN){
				$listAdmin .= "<button onclick='banInUserListAdminWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-admin-in-user-list' class='cta-delete-admin-in-user-list' title='Bannir cet administrateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>";
			}
			
			$listAdmin .= "</div>
			</td>
			</tr>";

			$i++;
		}

		return $listAdmin;
    }

	/**
     * 
     * recupere tous les admin non banni recherché dans la barre de recherche
	 * 
	 * @param string $value valeur de la barre de recherche
	 * 
	 * @return string liste des admin trouvé
     * 
     * 
     * 
     */

	public function getSearchedAdmin($value){

		$select = array("u.username", "u.mail", "u.verified AS etat", "ro.role", "u.is_banned AS statut");
		$tag = "u";
		$innerJoin = array("roles ro ON ro.id_role = u.id_role");
		$where = array(
						"(lower(u.username) LIKE lower(?)"=>"".$value."%",
						"OR lower(u.mail) LIKE lower(?))"=>"".$value."%",
						"AND u.is_banned = ?"=>"FALSE",
						"AND u.id_role = ?"=>ID_ROLE_ADMIN
					);
		$orderBy = array("ORDER BY u.username ASC");

		$result = $this->select($select, $where, $orderBy, $innerJoin, $tag);

		return $this->displaySearchedAdmins($result);

	}

	/**
     * 
     * Crée le html des admin bannis trouvé
     * 
     * @param array $result infos de l admin
     * 
     * @return string $listBanned html créé
     * 
     * 
     */

    public function displayBannedAdminsWithNewOffset($result){

        $listBanned = "";
		$i = 0;
			
		foreach($result as $key => $value){
								
			$listBanned .= "<tr>
			<td>".htmlentities($value['username'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td><i class='fas fa-crown icon-user-list' title='Administrateur' ></i></td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>";

			if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN){
				$listBanned .= "<button onclick='unbanInUserListAdminWhileSearch(this);' name=".htmlentities($value['mail'], ENT_QUOTES)." id='unban-admin-in-user-list' class='cta-unban-in-user-list cta-unban-admin-in-user-list' title='Débannir cet administrateur' value=".$i."><i class='fas fa-undo'></i></button>
				<button onclick='deleteInUserListAdminBannedWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-admin-in-user-list' class='cta-delete-admin-in-user-list' title='Supprimer cet administrateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>";
			}
			
			$listBanned .= "</div>
			</td>
			</tr>";

			$i++;

		}

		return $listBanned;
    }

	/**
	 * 
	 * recupere tous les admin banni
	 * 
	 * @param integer $offset offset de depart de la recherche
	 * 
	 * @return string si offset > 0 liste des users
	 * @return array $result infos de l admin 
     * 
     * 
     * 
     */

	public function getBannedAdmin($offset)
	{

		$select = array("u.username", "u.mail", "ro.role", "u.verified AS etat", "u.is_banned AS statut");
		$tag = "u";
		$innerJoin = array("roles ro ON ro.id_role = u.id_role");
		$where = array("u.is_banned = ?" => "TRUE");
		$orderByLimitOffset = array("ORDER BY u.username ASC LIMIT 20 OFFSET " . $offset . "");

		$result = $this->select($select, $where, $orderByLimitOffset, $innerJoin, $tag);

		if($offset > 0){
			return $this->displayBannedAdminsWithNewOffset($result);
		}

		return $result;

	}

	/**
     * 
     * Crée le html des admin bannis recherché trouvé
     * 
     * @param array $result infos de l admin
     * 
     * @return string $listBanned html créé
     * 
     * 
     */

    public function displaySearchedBannedAdmins($result){

        $listBanned = "";
		$i = 0;
		
		foreach($result as $key => $value){
							
			$listBanned .= "<tr>
			<td>".htmlentities($value['username'], ENT_QUOTES)."</td>
			<td>".htmlentities($value['mail'], ENT_QUOTES)."</td>
			<td><i class='fas fa-crown icon-user-list' title='Administrateur' ></i></td>
			<td>".(($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>')."</td>
			<td>".(($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>')."</td>
			<td>
			<div>";
			
			if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN){
				$listBanned .= "<button onclick='unbanInUserListAdminWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='unban-admin-in-user-list' class='cta-unban-in-user-list cta-unban-admin-in-user-list' title='Débannir cet administrateur' value='".$i."'><i class='fas fa-undo'></i></button>
				<button onclick='deleteInUserListAdminWhileSearch(this);' name='".htmlentities($value['mail'], ENT_QUOTES)."' id='delete-admin-in-user-list' class='cta-delete-admin-in-user-list' title='Supprimer cet administrateur' value='".$i."'><i class='fas fa-trash-alt'></i></button>";
			}

			$listBanned .= "</div>
			</td>
			</tr>";

			$i++;
						
		}

		return $listBanned;
    }

	/**
	 * 
	 * recupere tous les admin banni recherché dans la barre de recherche
	 * 
	 * @param string $value valeur de la barre de recherche
	 * 
	 * @return string $listBanned liste des admin trouvé
	 * 
	 * 
	 * 
	 */

	public function getSearchedBannedAdmin($value)
	{

		$select = array("u.username", "u.mail", "u.verified AS etat", "ro.role", "u.is_banned AS statut");
		$tag = "u";
		$innerJoin = array("roles ro ON ro.id_role = u.id_role");
		$where = array(
			"(lower(u.username) LIKE lower(?)" => "" . $value . "%",
			"OR lower(u.mail) LIKE lower(?))" => "" . $value . "%",
			"AND u.is_banned = ?" => "TRUE"
		);
		$orderBy = array("ORDER BY u.username ASC");

		$result = $this->select($select, $where, $orderBy, $innerJoin, $tag);

		return $this->displaySearchedBannedAdmins($result);

	}
	// Functions pour changer les infos en base de donnée
	// Dans les paramètres

	/**************************************************
	 ***************************************************
	 **************************************************/

	/********************************************************
	 **** FORMULAIRE DE CONFIGURATON DANS LES PARAMETRES ****
	 ********************************************************/

	/**
	 * 
	 *	fomulaire de configuration des infos bdd dans 'paramètres'
	 * 
	 *	@return array formulaire
	 * 
	 */
	public function getNewBddAccessForm()
	{
		return [
			"config" => [
				"method" => "POST",
				"action" => Routing::getSlug("UserNewBdd", "validateNewBddAccess"),
				"class" => "",
				"id" => "form-config-bdd",
				"submit" => "Confirmer la configuration"
			],

			"data" => [

				"new-bdd-name" => [
					"type" => "text",
					"placeholder" => "Nom de la base de données",
					"id" => "new-bdd-name",
					"name" => "new-bdd-name",
					"class" => "",
					"maxlength" => 100,
					"required" => false,
					"error" => "Le nom de la base de donnée est incorrect"
				],

				"new-id" => [
					"type" => "text",
					"placeholder" => "Identifiant",
					"id" => "new-id",
					"name" => "new-id",
					"class" => "",
					"maxlength" => 100,
					"required" => false,
					"error" => "L'identifiant n'est pas valide"
				],

				"new-password" => [
					"type" => "text",
					"placeholder" => "Mot de passe PostgresSQL",
					"id" => "new-password",
					"name" => "new-password",
					"class" => "",
					"maxlength" => 100,
					"required" => false,
					"error" => "Le mot de passe n'est pas valide"
				],

				"new-host" => [
					"type" => "text",
					"placeholder" => "Hôte de la base de données",
					"id" => "new-host",
					"name" => "new-host",
					"class" => "",
					"maxlength" => 100,
					"required" => false,
					"error" => "L'hôte n'est pas valide"
				],

				"new-domain-name" => [
					"type" => "text",
					"placeholder" => "Nom de domaine du site",
					"id" => "new-domain-name",
					"name" => "new-domain-name",
					"value" => "http://exemple.com/",
					"class" => "",
					"required" => false,
					"error" => "Le nom de domaine n'est pas valide. Il doit commencer par http:// ou https:// et doit se finir par /"
				]

			]

		];
	}
	/**
	 * 
	 *	Change le nom de la base de donnée dans les paramètres
	 * 
	 *	
	 * 
	 */
	public function parametersChangeBddName($newBddName)
	{
		if(!empty($newBddName)){
		$result = $this->FileSearchAndWriteAtLine(23, 'conf-db.php', 'define("DBHOST", "' . $newBddName . '");//');
		return $result;
		}
	}

	/**
	 * 
	 *	Change l'identifiant pour la connexion à la base de donnée dans les paramètres
	 * 
	 *	
	 * 
	 */
	public function parametersChangeBddId($newBddId)
	{
		if(!empty($newBddId)){
		$result = $this->FileSearchAndWriteAtLine(24, 'conf-db.php', 'define("DBNAME", "' . $newBddId . '");//');
		return $result;
		}
	}

	/**
	 * 
	 *	Change le mot de passe pour la connexion à la base de donnée dans les paramètres
	 * 
	 *	
	 * 
	 */
	public function parametersChangeBddPassword($newBddPassword)
	{
		if(!empty($newBddPassword)){
		$result = $this->FileSearchAndWriteAtLine(25, 'conf-db.php', 'define("DBUSER", "' . $newBddPassword . '");//');
		return $result;
		}
	}

	/**
	 * 
	 *	Change le host de la base de donnée dans les paramètres
	 * 
	 *	
	 * 
	 */
	public function parametersChangeBddHost($newBddHost)
	{
		if(!empty($newBddHost)){
		$result = $this->FileSearchAndWriteAtLine(26, 'conf-db.php', 'define("DBPWD", "' . $newBddHost . '");//');
		return $result;
		}
	}

	/**
	 * 
	 *	Change le nom de domaine du site dans les paramètres
	 * 
	 *	
	 * 
	 */
	public function parametersChangeDomainName($newDomainName)
	{
		if(!empty($newDomainName)){
		$result = $this->FileSearchAndWriteAtLine(31, 'conf-db.php', 'define("HOST", "' . $newDomainName . '");//');
		return $result;
		}
	}

	/**
	 * 
	 * Fonction boucle pour rechercher la ligne à modifier dans un fichier
	 * 
	 */
	public function FileSearchAndWriteAtLine($line, $file, $content)
	{
		$fileToEdit = fopen($file, 'r+');
		for ($currentLine = 0; $currentLine < $line; $currentLine++) {
			$stopAtLine = fgets($fileToEdit);
		}
		fputs($fileToEdit, $content);
		fclose($fileToEdit);
	}
}
