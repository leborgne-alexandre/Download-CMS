<?php
trait element_style__style_hover{

    /**
     * 
     * insert un element dans les tables necessaires a l edition (element, styles, styles_hover)
     * 
     * @param string $type type de l element
     * @param integer $nextId id de l element
     * @param integer $pageId id de la page ou l element a été ajouté
     * @param string $elementName nom de l element (necessaire que pour la table "elements")
     * @param string $typeToInsert type de l element a inserer en bdd (nuance avec $type qui sert a definir le contenu a inserer en bdd)
     * @param string $elementHtml html de l element a ajouté (inséré dans "contenu" de la table "elements")
     * 
     * 
     */

    public function insertElementInEachTable($type = null, $nextId, $pageId, $elementName = null, $typeToInsert = null, $elementHtml = null, $fileName = null, $path = null){

        $this->setElementId($nextId);
       
        if($elementName != null){
            $this->setElementName($elementName);

            if($typeToInsert != null){
                $this->setType($typeToInsert);
            
                if($typeToInsert == "link"){
                    $this->setLink("http://link.example");
                }

                if($typeToInsert == "video"){
                    $this->setLink("".$path.$fileName."");
                }

                if($typeToInsert == "image"){
                    $this->setLink("".$path.$fileName."");
                }
            }

            if($elementHtml != null)
                $this->setContain($elementHtml);
        }

        if($type == "text"){
            $this->setContain("Texte...");
            $this->setEditTextEnable(1);
        }elseif($type == "link"){
            $this->setContain("lien...");
            $this->setEditTextEnable(1);
        }

        $this->setPageId($pageId);

        $this->insert();

    }

    /**
     * 
     * supprime un element
     * 
     * @param integer $element id de l element
     * 
     * 
     */

	public function deleteElement($element){

        $where = array("id_element = ?"=>$element);

        $this->delete($where);

     }

     /**
     * 
     * supprime les elements d'une page supprimé
     * 
     * @param integer $idPage id de la page supprimé
     * 
     * 
     */

	public function deleteElementIfPageDeleted($idPage){

        $where = array("id_page = ?"=>$idPage);
    
        $this->delete($where);

     }

     /**
     * 
     * modifie le nom d un media pour un element de type image ou video
     * 
     * @param string $fileName nouveau nom du media
     * @param integer $idElement id de l element ou le media doit etre modifiée
     * @param boolean $isBackground true s'il s agit d une modif pour un background d un style
     * @param boolean $isUnable true si l element background est desactivé
     * 
     * 
     */

    public function updateMediaInEdition($path, $fileName, $idElement, $isBackground = "false", $isUnable = "false"){

        if($isBackground == "false"){
            $set = array("link"=>$path.$fileName);
            $where = array("id_element = ?"=>$idElement, "AND (type = ?"=>"image", "OR type = ?)"=>"video");
        }else{
            if($isUnable == "false"){
                $set = array("\"background-image\""=>"url(".$path.$fileName.")");
            }else{
                $set = array("\"background-image\""=>NULL);
            }

            $where = array("id_element = ?"=>$idElement);
        }

        $this->update($set, $where);

     }

}