<?php
trait global_security{

    /**
     * 
     * supprime les caracteres non désiré
     * 
     * @param string $string chaine a verifier
     * 
     * @return string chaine verifié et modifié si nécessaire
     * 
     * 
     */

    public function removeUnwantedString($string){

        $search = array(',', '<script>', '</script>', '"');
        $replace = array('', '', '', '\'');

        return str_replace($search, $replace, $string);

    }

    /**
     * 
     * supprime les caracteres non désiré dans le ckeditor
     * 
     * @param string $string chaine a verifier
     * 
     * @return string chaine verifié et modifié si nécessaire
     * 
     * 
     */

    public function removeUnwantedStringInCKEditor($string){

        $search = array('&lt;script&gt;', '&lt;/script&gt;', '&quot;', '"', "<script>", "</script>");
        $replace = array('', '', '\'', '\'', '', '');

        return str_replace($search, $replace, $string);

    }

    /**
     * 
     * check si une chaine correspond à une url valide
     * 
     * @param string $value chaine a verifier
     * 
     * @return boolean true si valid ou false si invalide
     * 
     * 
     * 
     */

    public function checkIfUrlValid($value, $isInternalUrl = false){

        $isStringOk = $this->checkIfUnwantedStringInUrl($value);

        if($isInternalUrl)
            $regex = "/^(\/)?(\/.*)?$/";
        else
            $regex = "/^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/";

        if(preg_match($regex, $value) && $isStringOk)
            return true;

        return false;

    }

    /**
     * 
     * check si il y a des chaines non voulu dans l url
     * 
     * @param string $stringBefore chaine a comparer
     * 
     * @return boolean true si chaine ok et false si chaine invalide
     * 
     * 
     * 
     */

     public function checkIfUnwantedStringInUrl($stringBefore){

        $search = array(',', '<script>', '</script>', '"', '\'');
        $replace = array('', '', '', '', '');

        $stringAfter = str_replace($search, $replace, $stringBefore);

        if($stringAfter === $stringBefore)
            return true;

        return false;

     }

     /**
      * 
      * verifie la taille d une chaine
      *
      * @param string $string chaine a verifier
      * @param integer $maxLength valeur maximum autorisée
      *
      * @return boolean false si chaine trop grande
      *
      *
      */

      public function stringLengthValidator($string, $maxLength){

        if(strlen($string) > $maxLength)
            return false;

        return true;

      }

}