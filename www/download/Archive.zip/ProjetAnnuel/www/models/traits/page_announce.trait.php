<?php
trait page_announce{

    /**
     * 
     * recupere les champs en bdd en fonction de la colonne selectionné
     * 
     * @param string $column colonne
     * @param string $slug slug de la page demandé
     * 
     * @return string valeur du champ si champ non vide
     * @return null si champ vide
     * 
     * 
     */
    
    public function getElementsFromBdd($column, $slug){

        $select = array($column);
        $where = array("slug = ?"=>$slug);

        $element = $this->select($select, $where);

        if($column == "contenu"){
            $elementsTable = new Elements();
            $select2 = array("contenu");
            $where2 = array("id_page = (SELECT id_page FROM pages WHERE slug = ?)"=>$slug, "AND is_deletable = ?"=>"TRUE");
            $orderBy2 = array("ORDER BY id ASC");

            $addedElementHtmlList = $elementsTable->select($select2, $where2, $orderBy2);

            $addedElementHtml = "";
            foreach($addedElementHtmlList as $key => $value){
                $addedElementHtml .= $value["contenu"];
            }

        }else{
            $addedElementHtml = null;
        }

        if(!empty($element)){

            if($column !== "*"){
                return $element[0][$column].$addedElementHtml;
            }else{
                $html = "";
                foreach($element[0] as $key => $value){
                    $html .= $value;
                }

                return $html;
            }
        }
      
        return;

    }

    /**
     * 
     * Recupere les slugs des pages et des annonces
     * 
     * 
     * 
     */

    public function getAllSlugs(){
         
        $select = array("*");

        return $this->select($select);

    }

}