<?php
trait style__style_hover{

    /**
     * 
     * recupere les styles
     * 
     * @param string $slug slug de la page demandé
     * 
     * @return array styles trouvé
     * 
     * 
     */
	
    public function getStylesAndStylesHoverFromDb($slug, $announce = FALSE){

        $select = array("s.*", "e.nom_element", "e.type", "e.link");
        $tag = "s";
		$innerJoin = array("elements e ON e.id_element = s.id_element");
		
		if(!$announce){
			$where = array(
				"(s.id_page IN (SELECT id_page FROM pages WHERE slug = ?)"=>$slug,
				"OR s.id_page IN (SELECT id_page FROM pages WHERE slug = ?)"=>"header",
				"OR s.id_page IN (SELECT id_page FROM pages WHERE slug = ?))"=>"footer"
			);
		}else{
			$where = array(
				"(s.id_page IN (SELECT id_page FROM annonces WHERE slug = ?)"=>$slug,
				"OR s.id_page IN (SELECT id_page FROM pages WHERE slug = ?)"=>"header",
				"OR s.id_page IN (SELECT id_page FROM pages WHERE slug = ?))"=>"footer"
			);
		}

        return $this->select($select, $where, NULL, $innerJoin, $tag);

	}

    /**
	 * 
	 * Insere les nouveaux styles modifié par l user
	 * 
	 * @param string $style champ en bdd correspondant au style modifié
	 * @param string $value valeur du style modifié
	 * 
	 * 
	 * 
	 */

	 public function insertNewStyle($style, $value, $idElement){

		$pages = new Pages();
		$pages->updateLastChangeDate($idElement);

		$value = str_replace("<", "", $value);
		$value = str_replace(">", "", $value);
		$value = str_replace("\"", "'", $value);
		$value = str_replace(",", "&sbquo;", $value);

		if(($style == "color" || $style == "background-color") && $value != "")
			$value = "#".$value;
		elseif(($style == "border" || $style == "border-top" || $style == "border-bottom" || $style == "border-left" || $style == "border-right" 
		|| $style == "box-shadow") && $value != "")
			$value = str_replace("*", "#", $value);

		if($style != "transition"){
			if($style == "contenu" || $style == "placeholder" || $style == "font-size"){
				$is_edit_text_enabled = $this->checkEditTextEnable($idElement);

				if($is_edit_text_enabled){
					$set = array("\"$style\""=>$value);
					$where = array("id_element = ?"=>$idElement);

					$this->update($set, $where);
				}
			}else{
				$set = array("\"$style\""=>$value);
				$where = array("id_element = ?"=>$idElement);

				$this->update($set, $where);
			}
		}else{
			$this->updateTransitionField($style, $value, $idElement);
		}

		if($style == "contenu" || $style == "placeholder"){
			$value = str_replace("&sbquo;", ",", $value);
			return $this->getSecureContain($value);
		}

	 }

	  /**
	 * 
	 * Enleve la transition d un style
	 * 
	 * @param string $style le style dont la transition doit etre enlever
	 * @param array $initialStylesAndTransitions transition en bdd
	 * 
	 * @return string $newString nouvelle valeur dans transition
	 * 
	 * 
	 * 
	 */

	public function removeATransition($style, $initialStylesAndTransitions){
		
		unset($initialStylesAndTransitions[$style]);
		$initialStylesAndTransitions = array_merge($initialStylesAndTransitions);
		
		$keys = array_keys($initialStylesAndTransitions);
		$values = array_values($initialStylesAndTransitions);

		$newArray = [];
		for($i = 0; $i < sizeof($initialStylesAndTransitions); $i++){
			array_push($newArray, $keys[$i]." ".$values[$i]);
		}

		$newString = implode("&sbquo; ", $newArray);

		return $newString;

	 }

	 /**
	 * 
	 * Insere les nouveaux styles modifié par l user
	 * 
	 * @param string $style champ en bdd correspondant au style modifié
	 * @param string $value valeur du style modifié
	 * 
	 * 
	 * 
	 */

	 public function updateTransitionField($style, $value, $idElement){

		$pages = new Pages();
		$pages->updateLastChangeDate($idElement);

		$select = array("transition");
		$whereSelect = array("id_element = ?"=>$idElement);
		$result = $this->select($select, $whereSelect);

		if(!empty($result[0]["transition"])){
			$stringInitialStylesAndTransitions = $result[0]["transition"];

			$initialStylesAndTransitions = $this->getSeparateInitialStylesAndTransitions($stringInitialStylesAndTransitions);
				
			if($value != ""){
			
				$newStyleAndTransition = $this->getSeparateNewStyleAndTransition($value);
				$newStyle = $newStyleAndTransition[0];
				$newTransition = $newStyleAndTransition[1];

				if(in_array($newStyle, array_keys($initialStylesAndTransitions))){	
					$newString = $this->setNewStylesTransitionsString($initialStylesAndTransitions, $newStyle, $newTransition);
					$set = array("transition"=>$newString);
				}else{
					$set = array("transition"=>$stringInitialStylesAndTransitions."&sbquo; ".$value);
				}

			}else{
				$newString = $this->removeATransition($style, $initialStylesAndTransitions);
				$set = array("transition"=>$newString);
			}

		}else{
			$set = array("transition"=>$value);
		}

		$where = array("id_element = ?"=>$idElement);

		$this->update($set, $where);

	 }

	 /**
	 * 
	 * Recupere les styles et transitions séparement deja presents avant l update
	 * 
	 * @param string $initialStylesAndTransitions le champ transition initial avant l update
	 * 
	 * @return array $arraySeparateStylesAndTransitions tableau associatif des styles et des trnasitions initial
	 * 
	 * 
	 */

	 public function getSeparateInitialStylesAndTransitions($initialStylesAndTransitions){

		$getInitialStyleAndTransition = explode("&sbquo; ", $initialStylesAndTransitions);

		$arraySeparateStylesAndTransitions = [];
		foreach($getInitialStyleAndTransition as $key => $value){

			$styleAndTransition = explode(" ", $value);
			$style = $styleAndTransition[0];
			$transition = $styleAndTransition[1];

			$arraySeparateStylesAndTransitions[$style] = $transition;

		}

		return $arraySeparateStylesAndTransitions;
	 }

	 /**
	 * 
	 * Recupere le styles et transition séparement du nouvel element
	 * 
	 * @param string $value le champ transition du nouvel element
	 * 
	 * @return array $arraySeparateStyleAndTransition tableau associatif du style et trnasition du nouvel element
	 * 
	 * 
	 */

	public function getSeparateNewStyleAndTransition($value){

		$getNewStyleAndTransition = explode(" ", $value);

		return $getNewStyleAndTransition;
	 }

	 /**
	 * 
	 * Crée la nouvelle chaine de caractere en bdd de la transition
	 * 
	 * @param array $initialStylesAndTransitions tableau des transitions initiales
	 * @param string $newStyle le nouveau style apres l update
	 * @param string $newTransition le nouveau temps de transition apres l update
	 * 
	 * @return string $string chaine créé prête a etre insérer en bdd
	 * 
	 * 
	 */

	 public function setNewStylesTransitionsString($initialStylesAndTransitions, $newStyle, $newTransition){

		unset($initialStylesAndTransitions[$newStyle]);
		$initialStylesAndTransitions = array_merge($initialStylesAndTransitions);

		$keys = array_keys($initialStylesAndTransitions);
		$values = array_values($initialStylesAndTransitions);

		$string = "";
		for($i = 0; $i < sizeof($initialStylesAndTransitions); $i++){
			$string .= $keys[$i]." ".$values[$i]."&sbquo; ";
		}

		$string = $string.$newStyle." ".$newTransition;

		return $string;

	 }

}