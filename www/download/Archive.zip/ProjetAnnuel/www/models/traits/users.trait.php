<?php
trait users{

    /**
     * 
     * acces au compte
	 * 
	 * @param string $mail mail de l user
	 * @param string $password mot de passe user
     * 
     * 
     * 
     */

	public function access($mail, $password, $redirectPath){

		$found_user = $this->verifIfUserValidated($mail);

		if(empty($found_user)){
			$this->errors[]="L'eMail et/ou le mot de passe est incorrect";
		}else{

			$blacklist = new Blacklist();
			$ipBanned = $blacklist->checkIfIPBanned();

			if(!$ipBanned){

				if(password_verify($password, $found_user[0]["password"])){
					$token = new Token();
					$token_value = $token->token;

					$set = array('token'=>$token_value);
					$where = array('mail = ?'=>$mail);

					$this->update($set, $where);

					$this->createSessions($found_user);

					$time_cookie_token = 86400; //1 jour

          $this->createCookies($token_value, $time_cookie_token);
					
					$blacklist->resetCounter();

					if(isset($_GET['action'])){
						header('Location: '.$_GET['action'].'');
					}else{
						header('Location: '.$redirectPath.'');
					}

				}else{
					$blacklist->incrementCounter();
					$this->errors[] = "L'eMail et/ou le mot de passe est incorrect";
				}
			}else{
				$this->errors[] = "Vous ne pouvez plus vous connecter. Veuillez réessayer ultérieurement.";
			}
		}
    }
    
    /**
     * 
     * recupere le role (4 = user, 3 = moderateur, 2 = admin et 1 = superAdmin)
	 * 
     * @return integer id du role
     * 
     * 
     */

	public function getRole(){

		$select = array("id_role");
		$where = array("mail = ?"=>$_SESSION['mail']);

		$role = $this->select($select, $where);

		return (int)implode($role[0]);

    }
    
    /**
     * 
     * verifie si le token est present et valide 
	 * 
	 * @param string $token token de la session ou du cookie de session
	 * 
	 * @return array user si token ok ou vide si token pas ok
     * 
     * 
     * 
     */

	public function verifTokenAndValidated($token){

		$select = array("*");
		$where = array("token = ?"=>$token, "AND verified = ?"=>TRUE);

		return $this->select($select, $where);

    }
    
    /**
     * 
     * verifie si le compte est validé
	 * 
	 * @param string $mail mail de l user
	 * 
	 * @return array admin si validé et vide si non validé
     * 
     * 
     * 
     */

	public function verifIfUserValidated($mail){

		$select = array("*");
		$where = array("mail = ?"=>$mail, "AND verified = ?"=>TRUE);

		return $this->select($select, $where);

    }
    
    /**
     * 
     * mise a jour du mot de passe
	 * 
	 * @param string $password nouveau mot de passe
	 * @param string $mail mail de l user
     * 
     * 
     * 
     */

	public function updatePassword($password, $mail){

		$password = password_hash($password, PASSWORD_DEFAULT);

		$set = ['password'=>$password];
		$where = ['mail = ?'=>$mail];

		$this->update($set, $where);

    }
    
    /**
     * 
     * banir un user
	 * 
	 * @param string $mail mail de l user
     * 
     * 
     * 
     */

	public function banUser($mail){

		$set = array('is_banned'=>'TRUE');
		$where = array('mail = ?'=>$mail);

		$this->update($set, $where);
    }
    
    /**
     * 
     * débannil user
     * 
     * @param string $mail mail de l user
     * 
     * 
     * 
     */

	public function unbanUser($mail){

		$set = array('is_banned'=>'FALSE');
		$where = array('mail = ?'=>$mail);

		$this->update($set, $where);
    }

    /**
     * 
     * supprime definitivement l user banni
     * 
     * @param string $mail mail de l user
     * 
     * 
     * 
     */

	public function deleteBanned($mail){

		$where = array('mail = ?'=>$mail);

		$this->delete($where);

    }

    /**
     * 
     * compte les users non banni
     * 
     * @param integer $roleId role de l user (1 = superadmin, 2 = admin, 3 = moderateur et 4 = user)
     * 
     * @return integer nombre d user trouvé
     * 
     * 
     */
    
    public function countAllUsers($roleId = NULL){

		$select = array("COUNT(id)");
		$where = array("is_banned = ?"=>"FALSE");

		if($roleId != NULL)
			$where["AND id_role = ?"] = $roleId;

		$result = $this->select($select, $where);

		if(!empty($result))
			return $result[0]["count"];
		else
			return 0;
    }

    /**
     * 
     * compte les users banni
     * 
     * 
     * @return integer nombre d user trouvé
     * 
     * 
     */
    
    public function countBanned(){

        $select = array("COUNT(id)");
        $where = array("is_banned= ?"=>"TRUE");

        $result = $this->select($select, $where);

		if(!empty($result))
			return $result[0]["count"];
		else
			return 0;
    }

}