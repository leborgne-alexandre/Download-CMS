<?php
// role id user
const ID_ROLE_USER = 4;
const NAME_ROLE_USER = "user";
// role id moderator
const ID_ROLE_MODERATOR = 3;
const NAME_ROLE_MODERATOR = "moderator";
// role id admin
const ID_ROLE_ADMIN = 2;
const NAME_ROLE_ADMIN = "admin";
// role id superadmin
const ID_ROLE_SUPERADMIN = 1;
const NAME_ROLE_SUPERADMIN = "superadmin";
// date au format europeen
const EUROPEAN_DATE_FORMAT = "d-m-Y H:i";
const EUROPEAN_DATE_FORMAT_WITHOUT_TIME = "d-m-Y";

/*** MAIL FRYZZER ***/
const MAIL_FRYZZER_HOST = "smtp.gmail.com";
const MAIL_FRYZZER_PORT = 587;
const MAIL_FRYZZER_USERNAME = "noreply.fryzzer@gmail.com";
const MAIL_FRYZZER_PASSWORD = "fryzzergmail";
const MAIL_FRYZZER_SET_FROM_MAIL = "noreply@fryzzer.com";
const MAIL_FRYZZER_SET_FROM_NAME = "FRYZZER";
const MAIL_FRYZZER_SMTP_SECURE = "tls";
const MAIL_FRYZZER_CHARSET = "UTF-8";

/*** MEDIA ***/
const PATH_INITIAL_MEDIAS = "/assets/images/front/";
const PATH_DL_MEDIAS = "/uploads/medias/";
const MAX_FILE_SIZE_IMAGE = 2000000;
const MAX_FILE_SIZE_VIDEO = 25000000;
const AUTHORIZED_IMAGE_EXTENDS = ["png", "jpg", "jpeg", "gif", "svg", "apng", "bmp", "ico", "webp"];
const AUTHORIZED_VIDEO_EXTENDS = ["mp4", "webm", "ogg"];

/*** NOTIFICATIONS ***/
const ASK_NEW_ADMIN_NOTIFICATION_TYPE = "ask_new_admin";
const NEW_ANNOUNCE_NOTIFICATION_TYPE = "new_announce";