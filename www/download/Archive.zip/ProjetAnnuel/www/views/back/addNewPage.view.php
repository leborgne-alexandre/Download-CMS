<title>Ajouter une page</title>
</head>
<body>
<section>
	<?php $this->addModalBack("menu") ?>
	<div class="view">
		<?php $this->addModalBack("header") ?>
        <h1>Ajouter une page</h1>
        <?php $this->addModalBack("inCmsForm", $inCmsForm) ?>
    </div>
</section>