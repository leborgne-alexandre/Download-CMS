<title>Demande d'ajout d'un nouvel utilisateur</title>
</head>
<body>
<?php
	if(isset($_SESSION["mailSend"])){
		echo "<script>
			alertMessage('Le mail a été envoyé au Super Administrateur<br>(vous recevrez un mail si celui-ci accepte votre demande)', '/zz-sign_in');
		</script>";
		unset($_SESSION["mailSend"]);
		session_destroy();
	}else if(isset($_SESSION["errorMailSend"])){
		echo "<script>
			alertErrorMessage('Erreur lors de l\'envoi du mail', '/zz-sign_in');
		</script>";
		unset($_SESSION["errorMailSend"]);
		session_destroy();
	}
?>

<div id="container">
<div class="back-to-login" ><a href="/zz-sign_in">Retour à la connexion</a></div>
<div class="logo_cms"></div>
<div class="flex-wrap">
<?php $this->addModalBack("form", $form) ?>
</div>
</div>