<title>Sending sign-up mail...</title>
</head>
<body>
<?php
	if(isset($_SESSION["autorisedSignUpMailSent"])){
		echo "<script>
			alertMessage('Un mail d\'autorisation de création d\'un compte Super Administrateur a été envoyé à ".$_SESSION['autorisedSignUpMailSent']."', '/zz-sign_in');
		</script>";
		unset($_SESSION["autorisedSignUpMailSent"]);
		session_destroy();
	}elseif(isset($_SESSION["errorAutorisedSignUpMailSent"])){
		echo "<script>
			alertErrorMessage('Erreur lors de l\'envoi du mail', '/zz-sign_in');
		</script>";
		unset($_SESSION["errorAutorisedSignUpMailSent"]);
		session_destroy();
	}