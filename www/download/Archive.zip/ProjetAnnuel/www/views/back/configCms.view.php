<script type="text/javascript" src="/assets/js/back/fields.js"></script>
<title>zz-config-cms</title>
</head>
<body>
<?php
	if(isset($_SESSION["db-downloaded"])){
		echo "<script>
			alertMessage('La base de données a été créée avec succès. Un mail de confirmation a été envoyé à ".$_SESSION["db-downloaded"]."', '/zz-sign_in');
		</script>";
		unset($_SESSION["db-downloaded"]);
		session_destroy();
	}elseif(isset($_SESSION["error-db-downloaded"])){
		echo "<script>
			alertErrorMessage('Erreur lors de la création de la base de données. Assurez vous que celle-ci est vide avant l\'opération');
		</script>";
		unset($_SESSION["error-db-downloaded"]);
		session_destroy();
	}
?>
<div id="container">
<div class="logo_cms"></div>
<div class="flex-wrap">
<div class="title-config"><h1>Configuration de la Base de Données</h1></div>
<?php $this->addModalBack("form", $configBddForm) ?>
</div>
</div>