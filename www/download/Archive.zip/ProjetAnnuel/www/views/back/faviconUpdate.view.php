<title>Paramètres</title>
</head>

<body>

    <section>
        <?php $this->addModalBack("menu") ?>
        <div class="view">
            <?php $this->addModalBack("header") ?>

            <section class="favicon-form">
                <form action="faviconSend" method="post" enctype="multipart/form-data">
                    <p>Changer son Favicon</p>
                    <input type="file" name="favicon-file" /><br />
                    <input type="submit" class="button-parameters" value="Envoyer" name="send-favicon" />
                </form>
            </section>
        </div>