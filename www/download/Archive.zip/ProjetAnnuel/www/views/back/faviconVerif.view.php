<?php

$faviconRegister = new Parameters();
//test envois du favicon

if (isset($_FILES['favicon-file']) and $_FILES['favicon-file']['error'] == 0) {
    $extensionInfos = pathinfo($_FILES['favicon-file']['name']);
    $extension_upload = $extensionInfos['extension'];
    $extensions_autorisees = array('ico');
    if (in_array($extension_upload, $extensions_autorisees)) {
        move_uploaded_file($_FILES['favicon-file']['tmp_name'], 'uploads/' . basename($_FILES['favicon-file']['name']));
        echo "L'envoi a bien été effectué !";
        echo "Vous allez être redirigé dans 5 secondes ...";
        $faviconRegister->faviconSave(basename($_FILES['favicon-file']['name']));
    }
}
?>
<h1> vous serez bientot redirigé </h1>
<meta http-equiv="refresh" content="5; URL= /zz-admin/parameters">