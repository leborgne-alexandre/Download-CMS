<title>Mot de passe oublié</title>
</head>
<body>
<?php
	if(isset($_SESSION["mailSend"])){
		echo "<script>
			alertMessage('Le mail a été envoyé avec succès', '/zz-sign_in');
		</script>";
		unset($_SESSION["mailSend"]);
		session_destroy();
	}elseif(isset($_SESSION["errorMailSend"])){
		echo "<script>
			alertErrorMessage('Erreur lors de l\'envoi du mail');
		</script>";
		unset($_SESSION["errorMailSend"]);
		session_destroy();
	}
?>

<div id="container">
<div class="back-to-login" ><a href="/zz-sign_in">Retour à la connexion</a></div>
<div class="logo_cms"></div>
<div class="flex-wrap">
<?php $this->addModalBack("form", $form) ?>
</div>
</div>