<title>Connexion</title>
</head>
<body>
<div id="container">
<div class="flex-wrap">
<div class="logo_cms"></div>
<?php $this->addModalBack("form", $form) ?>
<div class="links-login">
<div>
	<a href="/zz-forget_password" class="forget_password">Mot de passe oublié ?</a>
</div>
<div>
	<a href="/zz-sign_up" class="sign_up">Ajouter</a>
</div>
</div>
</div>
</div>