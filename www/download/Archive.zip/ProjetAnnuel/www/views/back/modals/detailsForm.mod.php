<div class="filter-pop-up"></div>
<div id="bloc-details">
<div><h1>Détails</h1></div>
<div id="close-details" onclick="closeDetails();" ><i class="fas fa-times"></i></div>
<div class="flex column" id="list-details">

<?php foreach($config[0] as $key => $value): ?>

<?php 
switch($key){
    case "username":
        $label = "Nom d'utilisateur";
        break;
    case "nom":
        $label = "Nom";
        break;
    case "prenom":
        $label = "Prénom";
        break;
    case "age":
        $label = "Age";
        break;
    case "mail":
        $label = "Mail";
        break;
    case "adresse":
        $label = "Adresse";
        break;
    case "telephone":
        $label = "Téléphone";
        break;
    case "ville":
        $label = "Ville";
        break;
    case "code_postal":
        $label = "Code postal";
        break;
    case "description":
        $label = "Description";
        break;
    case "region_nom":
        $label = "Région";
        break;
    case "departement_nom":
        $label = "Département";
        break;
    case "role":
        $label = "Role";
        break;
    case "etat":
        $label = "Etat";
        break;
    case "statut":
        $label = "Statut";
        break;
}

if($label == "Etat" && $value == 1)
    $value = "Vérifié";
elseif($label == "Etat" && $value != 1)
    $value = "Non vérifié";

if($label == "Statut" && $value == 1)
    $value = "Banni";
elseif($label == "Statut" && $value != 1)
    $value = "Actif";

if($label == "Role"){
    switch($value){
        case NAME_ROLE_USER:
            $value = "utilisateur";
            break;
        case NAME_ROLE_MODERATOR:
            $value = "modérateur";
            break;
        case NAME_ROLE_ADMIN:
            $value = "administrateur";
            break;
    }
}
?>
<div class="detail-line flex">
<label id="title-part-detail"><?php echo $label; ?> :</label>
<span id="value-part-detail"><?php echo htmlentities($value, ENT_QUOTES); ?></span>
</div>

<?php if($label == "Statut"): ?>
<?php if($config[0]["role"] == NAME_ROLE_USER): ?>

<hr>
<div class="detail-line flex" id="change-role">
<button id="title-part-detail" class="button-change-role" title="Passer cet utilisateur en modérateur" onclick="changeRole('<?php echo $config[0]['mail']; ?>', <?php echo ID_ROLE_MODERATOR; ?>);" >Passer en modérateur ?</button>
</div>

<?php elseif($config[0]["role"] == NAME_ROLE_MODERATOR): ?>

<hr>
<div class="detail-line flex" id="change-role">
<button id="title-part-detail" class="button-change-role" title="Passer se modérateur en utilisateur normal" onclick="changeRole('<?php echo $config[0]['mail']; ?>', <?php echo ID_ROLE_USER; ?>);" >Passer en utilisateur normal ?</button>
</div>

<?php endif; ?>
<?php endif; ?>
<?php endforeach; ?>

</div>
</div>