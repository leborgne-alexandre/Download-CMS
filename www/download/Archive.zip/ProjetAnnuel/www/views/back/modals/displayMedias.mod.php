<?php $media = new Media(); ?>

<?php $result = $media->getAllMedias(); ?>

<?php foreach($result as $key => $value): ?>

    <?php if($value["type"] === "image"): ?>
        <div id="bloc-media-<?php echo $value["id"]; ?>" class="bloc-media bloc-display-media">
        <?php if($value["is_initial"]): ?>
            <div id="show-full-media-<?php echo $value["id"]; ?>" class="background-media" style="background-image: url('<?php echo $value["path"].$value["file_name"]; ?>')"></div>
            <button class="cta-delete-media hidden" data-path="<?php echo $value["path"]; ?>" data-filename="<?php echo $value["file_name"]; ?>" title="Supprimer cette image"><i class="fas fa-times"></i></button>
        <?php else: ?>
            <div id="show-full-media-<?php echo $value["id"]; ?>" class="background-media" style="background-image: url('<?php echo PATH_DL_MEDIAS.$value["file_name"]; ?>')"></div>
            <button class="cta-delete-media hidden" data-path="<?php echo PATH_DL_MEDIAS; ?>" data-filename="<?php echo $value["file_name"]; ?>" title="Supprimer cette image"><i class="fas fa-times"></i></button>
        <?php endif; ?>
            <div class="infos-box-media size-info-box-media hidden"><?php echo $value["size"]; ?> <b>Mo</b></div>
        <?php if(!$value["is_initial"]): ?>
            <div class="infos-box-media title-info-box-media hidden"><?php echo $value["title"]; ?></div>
        <?php endif; ?>
            <div type="hidden" value="<?php echo $value["file_name"]; ?>" ></div>
        </div>
    <?php else: ?>
        <div id="bloc-media-<?php echo $value["id"]; ?>" class="bloc-media bloc-display-media">
            <video autoplay loop controls muted >
                <source src="<?php echo PATH_DL_MEDIAS.$value["file_name"]; ?>" />
            </video>
            <button class="cta-delete-media hidden" data-filename="<?php echo $value["file_name"]; ?>" title="Supprimer cette vidéo"><i class="fas fa-times"></i></button>
            <div class="infos-box-media size-info-box-media hidden"><?php echo $value["size"]; ?> <b>Mo</b></div>
            <div type="hidden" value="<?php echo $value["file_name"]; ?>" ></div>
        </div>
    <?php endif; ?>

<?php endforeach; ?>