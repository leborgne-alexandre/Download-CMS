<header>
    <div class="header-content">
        <div class="add-content">
            <a href="/zz-admin/add-new-page"><i class="fas fa-plus"></i> Ajouter du contenu</a>
        </div>
        <div class="dashboard">
            <h1>Dashboard</h1>
        </div>
        <?php $notifications = new Notifications(); 
              $count = $notifications->countNotifications();
              if($count > 99){
                  $count = "99+";
              }
        ?>
        <div class="header-right-part flex">
            <span>Hello <a href="profil" title="Gestion du profil" ><?php echo htmlentities($_SESSION['username'], ENT_QUOTES); ?></a> !</span>
            <div class="bloc-icon-notifs">
                <a href="notifications" class="cta-icon-notifs" title="Notifications (<?php echo $count; ?>)" >
                    <div class="cta-count-notifs flex"><?php echo $count; ?></div>
                    <i class="fas fa-bell"></i>
                </a>
            </div>
        </div>
    </div> 
</header>