<?php $data = ($config["config"]["method"]=="POST")?$_POST:$_GET; ?>

  <form   
      method="<?php echo $config["config"]["method"];?>"  
      class="<?php echo $config["config"]["class"];?>"   
      id="<?php echo $config["config"]["id"];?>">

		<?php if( !empty($config["errors"])):?>
			<div class="alert-statut">
			<ul>
			<?php foreach ($config["errors"] as $errors):?>
				<li><?php echo $errors;?></li>
				<hr>
			<?php endforeach ?>
			</ul>
			</div>
		<?php endif ?>

            <?php foreach ($config["data"] as $key => $value): ?>
                <?php if($key != "template"): ?> 
                    <input type="<?php echo $value["type"];?>" 
                        name="<?php echo $key;?>"
                        <?php echo ($value["required"])?'required="required"':'';?>
                        id="<?php echo $value["id"];?>" 
                        class="<?php echo $value["class"];?>"
                        <?php if(isset($value["value"])): ?>
                            value="<?php echo $data[$key]??$value["value"];?>"
                        <?php else: ?>
                            value="<?php echo $data[$key]??'';?>"
                        <?php endif; ?>
                        placeholder="<?php echo $value["placeholder"]; ?>"
                        >

                    <?php if($key == "slug"): ?>
                        <p class="info-text">Si l'url est renseignée, elle ne doit pas commencer par "zz-" (cette notation est réservée pour les pages natives au CMS). Si l'url n'est pas renseignée alors le nom de la page doit respecter cette règle. Si "zz-" est présent, la page sera créé mais "zz-" sera retiré automatiquement.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <?php $path = new GetCurrentPath();
                    if($path->path == "/zz-admin/add-new-page"): ?>
                
                        <select id="template-list" name="template-list">

                        <?php $template = new Templates();
                        $listTemplates = $template->getAllTemplates();

                        foreach($listTemplates as $key => $value): ?>

                            <option><?php echo $value['nom'] ?></option>

                        <?php endforeach; ?>

                        </select>

                    <?php endif; ?>
                <?php endif; ?>

      	<?php endforeach;?>

          <input type="submit" class="cta-submit" value="<?php echo $config["config"]["submit"];?>">

          <?php if($path->path == "/zz-admin/add-new-page"): ?>

            <p class="info-text">A la création, cette page ne sera pas activée. Pour l'activer rendez-vous dans la <a href="/zz-admin/page-list">liste des pages</a>.</p>

          <?php endif; ?>

  </form>