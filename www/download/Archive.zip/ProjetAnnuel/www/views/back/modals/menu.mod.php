        <div class="sidebar">

        <?php
            $currentPath = new GetCurrentPath();
            $path = $currentPath->path;
            if($path == "/zz-admin/website"):
        ?>

            <div class="flex">
                <div class="sidebar-logo">
                    <img class="logo" src="/assets/images/back/logos/min_logo_fryzzer.png" alt="logo">
                </div>
                <div class="close-open-menu">
                    <i id="open-list-editable-elements-menu" class="fas fa-chevron-right arrow-close white" title="Ouvrir la liste des éléments"></i>
                </div>
            </div>

        <?php else: ?>

            <div class="sidebar-logo">
                <img class="logo" src="/assets/images/back/logos/min_logo_fryzzer.png" alt="logo">
            </div>

        <?php endif; ?>

            <div id="leftside-navigation" class="nano">
                <ul class="nano-content">
                    <li>
                        <a href="/zz-admin/dashboard"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="/"><i class="fas fa-eye"></i><span>Visionner</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="far fa-file"></i><span>Pages</span></a>
                        <ul>
                            <li><a href="page-list">Liste des pages</a>
                            </li>
                            <li><a href="add-new-page">Ajouter une page</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="/zz-admin/announce-list"><i class="far fa-newspaper"></i><span>Annonces</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="/zz-admin/medias"><i class="fas fa-camera"></i><span>Media</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="/zz-admin/users-list"><i class="fas fa-user-cog"></i><span>Utilisateurs / admins</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="#" id="menu-cta-notes"><i class="fas fa-pen"></i><span>Bloc-note</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="/zz-admin/statistics"><i class="fas fa-chart-bar"></i><span>Statistiques</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="/zz-admin/parameters"><i class="fas fa-cog"></i><span>Paramètres</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="/zz-admin/log_out"><i class="fas fa-sign-out-alt"></i><span>Déconnexion</span></a>
                    </li>
                </ul>
            </div>
        </div>
        <div id="display-bloc-notes"></div>
        <script src="/assets/js/back/script.js"></script>
            
