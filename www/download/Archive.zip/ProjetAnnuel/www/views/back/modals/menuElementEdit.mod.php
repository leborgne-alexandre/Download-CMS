<div class="sidebar-menu-element-edit sidebar">
    <div class="flex">
        <div class="sidebar-logo">
            <img class="logo" src="/assets/images/back/logos/min_logo_fryzzer.png" alt="logo">
        </div>
        <div class="close-open-menu">
            <i id="close-editable-styles-menu" class="fas fa-chevron-left arrow-close black-metal" title="Fermer le menu d'édition"></i>
        </div>
    </div>
    <div>
    </div>
    <div id="leftside-navigation" class="nano display-editable-styles"></div>
</div>