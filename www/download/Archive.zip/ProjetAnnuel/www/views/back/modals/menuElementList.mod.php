<?php $pageViewSlug = new GetCurrentSlug(TRUE); // TRUE indique qu on recupere le slug de la page en edition 
$pages = new Pages();
?>
<div class="sidebar-menu-element-list sidebar show-menu">
    <div class="flex">
        <div class="sidebar-logo">
            <img class="logo" src="/assets/images/back/logos/min_logo_fryzzer.png" alt="logo">
        </div>
        <div class="close-open-menu">
            <i id="close-list-editable-elements-menu" class="fas fa-chevron-left arrow-close white" title="Fermer la liste des éléments"></i>
        </div>
    </div>
    <div class="flex space-around select-platform">
        <i id="computer-platform" class="fas fa-desktop" title="Ordinateur (1920px de large)"></i>
        <i id="laptop-platform" class="fas fa-laptop" title="Ordinateur portable (1300px de large)"></i>
        <i id="tablet-platform" class="fas fa-tablet-alt" title="Tablette (900px de large)"></i>
        <i id="phone-platform" class="fas fa-mobile-alt" title="Téléphone (400px de large)"></i>
    </div>
    <?php $isPageExist = $pages->checkIfSlugExists($pageViewSlug->slug, TRUE);
    if($isPageExist):  
    ?>
        <div class="flex column">
            <form method="get" id="form-edit-page-infos" class="form-edit-page-infos" >
                <label>Nom de la page :</label>
                <input type="text" id="name" name="<?php echo $pages->getElementsFromBdd("nom_page", $pageViewSlug->slug); ?>" required="required" value="<?php echo $pages->getElementsFromBdd("nom_page", $pageViewSlug->slug); ?>"/>
                <label>URL de la page :</label>
                <?php if($pages->getElementsFromBdd("is_deletable", $pageViewSlug->slug)): ?>
                    <input type="text" id="slug" name="<?php echo $pages->getElementsFromBdd("slug", $pageViewSlug->slug); ?>" value="<?php echo $pages->getElementsFromBdd("slug", $pageViewSlug->slug); ?>"/>
                <?php else: ?>
                    <input type="text" id="slug" class="input-disabled" name="<?php echo $pages->getElementsFromBdd("slug", $pageViewSlug->slug); ?>" value="<?php echo $pages->getElementsFromBdd("slug", $pageViewSlug->slug); ?>" disabled="disabled"/>
                <?php endif; ?>
                <label>Titre de la page :</label>
                <input type="text" id="title" required="required" value="<?php echo $pages->getElementsFromBdd("title", $pageViewSlug->slug); ?>"/>
                <label>Description de la page :</label>
                <input type="text" id="description-page-in-db" required="required" value="<?php echo $pages->getElementsFromBdd("description", $pageViewSlug->slug); ?>"/>
                <div class="flex">
                    <input type="submit" value="Valider" id="submit-update-page-infos"/>
                    <div id="display-result-update-page-infos"></div>
                </div>
            </form>
        </div>
    <?php endif; ?>
    <input type="hidden" id="page-slug" value="<?php echo $pageViewSlug->slug; ?>" />
    <div class="element-list-title">
        <h1>ELEMENTS</h1>
    </div>
    <div class="element-list-icon tool-icon">
        <i class="fas fa-arrow-circle-down"></i>
    </div>
    <div id="leftside-navigation" class="display-element-list flex column nano">
        <div id="display-add-element-status" class="fail" ></div>
        <ul class="nano-content">
            <li class="sub-menu" id="add-element">
                <a href="javascript:void(0);"><i class="fas fa-plus"></i><span>Ajouter un élément</span></a>
                <ul>
                    <li class="flex">
                            <button id="add-text-element" class="cta-add-element">
                                <div class="flex column" >  
                                    <i class="fas fa-font"></i>
                                    <label class="label-cta-add-element">Texte</label>
                                </div>
                            </button>
                            <button id="add-image-element" class="cta-add-element">
                                <div class="flex column" >
                                    <i class="fas fa-images"></i>
                                    <label class="label-cta-add-element">Image</label>
                                </div>
                            </button>
                            <button id="add-video-element" class="cta-add-element">
                                <div class="flex column">
                                    <i class="fas fa-video"></i>
                                    <label class="label-cta-add-element">Vidéo</label>
                                </div>
                            </button>
                            <button id="add-link-element" class="cta-add-element">
                                <div class="flex column">
                                    <i class="fas fa-link"></i>
                                    <label class="label-cta-add-element">Lien</label>
                                </div>
                            </button>
                    </li>
                </ul>
            </li>
            <li class="sub-menu" id="in-element-list">
                <a href="javascript:void(0);"><i class="fas fa-tools"></i><span>Liste des éléments</span></a>
                <ul style="display: block;">
                <?php 
                    $elements = new Elements();
                    if($pageViewSlug->slug != "header" AND $pageViewSlug->slug != "footer")
                        $listElements = $elements->getEditableElementsIdFromDb($pageViewSlug->slug);
                    else
                        $listElements = $elements->getEditableElementsIdFromDb("error404");
                    foreach($listElements as $key => $value){
                        echo "<li class='flex'>";
                        if($value["is_deletable"]){
                            echo "<button class='flex column cta-focus-element-deletable' name='element-".$value["nom_element"]."-".$value["id_element"]."'>
                            <p>".$value["nom_element"]."</p>
                            <p class='label-info-type-element' >(".$value["type"].")</p>
                            <i class='fas fa-arrow-right padding-arrow-element'></i>
                            </button>
                            <button class='flex column cta-delete-element' id='delete-element-".$value["id_element"]."' name='element-".$value["nom_element"]."-".$value["id_element"]."' value='".$value["id_element"]."' title='Supprimer l&rsquo;élément ".$value["nom_element"]."' ><input type='hidden' value='".$value["type"]."' /></button>";
                        }else{
                            echo "<button class='flex column cta-focus-element' name='element-".$value["nom_element"]."-".$value["id_element"]."'>
                                <p>".$value["nom_element"]."</p>
                                <i class='fas fa-arrow-right padding-arrow-element'></i>
                            </button>";
                        }

                        echo "</li>";
                    }
                
                ?>
                </ul>
            </li>
        </ul>
    </div>
</div>
            
