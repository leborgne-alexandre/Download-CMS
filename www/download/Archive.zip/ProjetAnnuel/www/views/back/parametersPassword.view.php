<title>Paramètres</title>
</head>

<body>
	<?php $user = new Usr(); ?>
	<section>
		<?php $this->addModalBack("menu") ?>
		<div class="view">
			<?php $this->addModalBack("header") ?>
			<?php $compteState = $user->getAccountUserState(); ?>
			<?php $userEmail = $user->getAccountUserEmail(); ?>

			<section class="menu-list">
				<div class="flex infos-menu-list">
					<div>
						Compte : <td><?php echo $compteState; ?></td>
					</div>
					<div>
						Connecté en tant que : <td><?php echo $_SESSION['username'] ?></td>
					</div>
				</div>
			</section>
			<div id="main-display-search"></div>
			<section class="display-list">
				<div class="parametres-title-menu-link"><a href="/zz-admin/parameters">Modifier mon adresse mail </a></div>
			</section>
			<section class="display-list">
				<div class="parametres-title-menu-link">Modifier mon Mot de Passe</div>
				<div class="parametres-form-content"><?php $this->addModalBack("formParameters", $formPassword) ?></div>
			</section>
			<section class="display-list">
				<div class="parametres-title-menu-link"><a href="/zz-admin/parametersDatabase">Modifier les infos de ma base de donnée ( Attention données sensibles !)</a></div>
			</section>
			<section class="display-list">
				<div class="parametres-title-menu-link"><a href="favicon" class="button-link-favicon">Changer favicon</a></div>
			</section>
		</div>