<title>Refused...</title>
</head>
<body>
<?php
	if(isset($_SESSION["refusedCreateSuperAdminAccount"])){
		echo "<script>
			alertMessage('La création d\'un compte Super Administrateur pour ".$_SESSION['refusedCreateSuperAdminAccount']." a bien été refusée', '/zz-sign_in');
		</script>";
		unset($_SESSION["refusedCreateSuperAdminAccount"]);
		session_destroy();
	}elseif(isset($_SESSION["errorRefusedCreateSuperAdminAccount"])){
		echo "<script>
			alertErrorMessage('Erreur lors de l\'envoi du mail de refus à l\'utilisateur', '/zz-sign_in');
		</script>";
		unset($_SESSION["errorRefusedCreateSuperAdminAccount"]);
		session_destroy();
	}