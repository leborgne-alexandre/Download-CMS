<title>Réinitialiser le mot de passe</title>
</head>
<body>
<?php
	if(isset($_SESSION["validateResetPassword"])){
		echo "<script>
			alertMessage('Le mot de passe a bien été réinitialisé', '/zz-sign_in');
		</script>";
		unset($_SESSION["validateResetPassword"]);
		session_destroy();
	}elseif(isset($_SESSION["errorValidateResetPassword"])){
		echo "<script>
			alertErrorMessage('Erreur lors de la réinitialisation du mot de passe');
		</script>";
		unset($_SESSION["errorValidateResetPassword"]);
		session_destroy();
	}
?>
<div id="container">
<div class="back-to-login" ><a href="/zz-sign_in">Retour à la connexion</a></div>
<div class="flex-wrap">
<div class="logo_cms"></div>
<?php $this->addModalBack("form", $form) ?>
</div>
</div>