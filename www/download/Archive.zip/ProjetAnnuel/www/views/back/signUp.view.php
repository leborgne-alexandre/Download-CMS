<title>Inscription</title>
</head>
<body>
<?php
	if(isset($_SESSION["validateSignUp"])){
		echo "<script>
			alertMessage('Un mail de confirmation a été envoyé à ".$_SESSION['validateSignUp']."', '/zz-sign_in');
		</script>";
		unset($_SESSION["validateSignUp"]);
		session_destroy();
	}elseif(isset($_SESSION["errorValidateSignUp"])){
		echo "<script>
			alertErrorMessage('Erreur lors de l\'envoi du mail');
		</script>";
		unset($_SESSION["errorValidateSignUp"]);
		session_destroy();
	}
?>
<div id="container-sign-up">
<div class="back-to-login" ><a href="/zz-sign_in">Retour à la connexion</a></div>
<div class="logo_cms"></div>
<?php $this->addModalBack("form", $form) ?>
</div>