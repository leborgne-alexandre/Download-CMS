<title>Dashboard</title>
</head>
<body>
    <section>
        <div class="sidebar">
            <div class="sidebar-logo">
                <img class="logo" src="/assets/images/back/logos/main_logo_fryzzer.png" alt="logo">
            </div>
            <div id="leftside-navigation" class="nano">
                <ul class="nano-content">
                    <li>
                        <a href="#"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="fas fa-eye"></i><span>Visionner</span></a>
                        <ul>

                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="far fa-file"></i><span>Pages</span></a>
                        <ul>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="far fa-newspaper"></i><span>Articles</span></a>
                        <ul>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="fas fa-camera-retro"></i></i><span>Media</span></a>
                        <ul>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="fas fa-user-cog"></i><span>Utilisateurs</span></a>
                        <ul>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="fas fa-paint-roller"></i><span>Apparence</span></a>
                        <ul>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>

                    <li class="sub-menu">
                        <a href="javascript:void(0);"><i class="fas fa-user-tie"></i><span>Admin</span></a>
                        <ul>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                            <li><a href="#">Function</a>
                            </li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="#"><i class="fas fa-cog"></i><span>Paramètres</span></a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="view">
                <header>
                        <div class="header-content">
                            <div class="add-content">
                                <a href="#"><i class="fas fa-plus"></i> Ajouter du contenu</a>
                            </div>
                            <div class="dashboard">
                                <h1>Dashboard</h1>
                            </div>
                            <div class="notification">
                                <span>Hello User !</span>
                                <i class="far fa-bell"></i>
                                <i class="far fa-envelope"></i>
                            </div>
                        </div> 
                    </header>
            <div class="welcome">
                <h1>Bienvenue sur Fryzzer !</h1>
                <h2> Par quoi pouvez-vous commencer ?</h2>

                <div class="sub-content">
                    <div class="sub-welcome">
                        <h3>Editer votre site</h3>
                        <ul>
                            <li><i class="fas fa-user-cog"></i><a href="#">Créer une page</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="#">Modifier une page</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="#">Voir votre site</a></li>
                        </ul>
                    </div>
                    <div class="sub-welcome">
                        <h3>Administrer</h3>
                        <ul>
                            <li><i class="fas fa-user-cog"></i><a href="#">Gerer les utilisateurs</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="#">Gerer vos administrateur</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="#">Voir les statistiques de votre site</a></li>
                        </ul>
                    </div>
                    <div class="sub-welcome">
                        <h3>Gérer les flux</h3>
                        <ul>
                            <li><i class="fas fa-user-cog"></i><a href="#">Créer des catégories</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="#">Analyse du traffic</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="#">Administration des articles en ligne</a></li>
                        </ul>
                    </div>

                    <div class="sub-features">
                        <h3>Nouveautés</h3>
                    </div>
                </div>

            </div>

            <div class="bottom-part">
                <div class="left-content">
                    <div class="activity">

                        <h1>Activité récente</h1>
                        <h2>Que s'est t'il passsé sur votre site ?</h2>


                        <div class="request">

                            <div class="left-request">
                                <p class="title-request">Steve Jobs vien de vous demander une demande d'approbation</p>
                                <p class="title-subject">Salut mec stp, accepte ma demande serieux faut qu'on parle
                                    de...</p>
                            </div>
                            <div class="right-request">
                                <p class="date-request">12 décembre 2018 à 19h00</p>

                                <input class="accept"  type="button" name="accept" value="Accepter">
                                <input class="decline" type="button" name="decline" value="Refuser">
                            </div>


                        </div>
                        <div class="request">

                                <div class="left-request">
                                    <p class="title-request">Steve Jobs vien de vous demander une demande d'approbation</p>
                                    <p class="title-subject">Salut mec stp, accepte ma demande serieux faut qu'on parle
                                        de...</p>
                                </div>
                                <div class="right-request">
                                    <p class="date-request">12 décembre 2018 à 19h00</p>
    
                                    <input class="accept"  type="button" name="accept" value="Accepter">
                                    <input class="decline" type="button" name="decline" value="Refuser">
                                </div>
    
    
                            </div>
                            <div class="request">

                                    <div class="left-request">
                                        <p class="title-request">Steve Jobs vien de vous demander une demande d'approbation</p>
                                        <p class="title-subject">Salut mec stp, accepte ma demande serieux faut qu'on parle
                                            de...</p>
                                    </div>
                                    <div class="right-request">
                                        <p class="date-request">12 décembre 2018 à 19h00</p>
        
                                        <input class="accept"  type="button" name="accept" value="Accepter">
                                        <input class="decline" type="button" name="decline" value="Refuser">
                                    </div>
        
        
                                </div>
                                <div class="request">

                                        <div class="left-request">
                                            <p class="title-request">Steve Jobs vien de vous demander une demande d'approbation</p>
                                            <p class="title-subject">Salut mec stp, accepte ma demande serieux faut qu'on parle
                                                de...</p>
                                        </div>
                                        <div class="right-request">
                                            <p class="date-request">12 décembre 2018 à 19h00</p>
            
                                            <input class="accept"  type="button" name="accept" value="Accepter">
                                            <input class="decline" type="button" name="decline" value="Refuser">
                                        </div>
            
            
                                    </div>
                                    <div class="request">

                                            <div class="left-request">
                                                <p class="title-request">Steve Jobs vien de vous demander une demande d'approbation</p>
                                                <p class="title-subject">Salut mec stp, accepte ma demande serieux faut qu'on parle
                                                    de...</p>
                                            </div>
                                            <div class="right-request">
                                                <p class="date-request">12 décembre 2018 à 19h00</p>
                
                                                <input class="accept"  type="button" name="accept" value="Accepter">
                                                <input class="decline" type="button" name="decline" value="Refuser">
                                            </div>
                                        </div>
                        <div class="state-request">
                            <a class="link" href="#">En attente (5)</a>
                            <a class="link" href="#">Approuvé (0)</a>
                        </div>
                    </div>
                </div>
                <div class="right-content">
                    <div class="note">
                        <h1>Note</h1>

                        <div>
                            <form action="#" method="POST">
                                <div class="input-text">
                                    <label for="note-title"></label>
                                    <input class="note-title" type="text" value="Titre">
                                    <input class="note-title" type="text" value="Ecriver votre idée">
                                </div>

                                

                        </div>

                        <div class="note-save">
                            <input class="btn" type="submit" value="Enregistrer votre note">
                            <a href="#">Consulter toutes vos notes >></a>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="/assets/js/back/script.js"></script>