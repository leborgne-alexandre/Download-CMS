<title>Liste des annonces</title>
</head>
<body>
	<?php $annonces = new Annonces(); ?>
	<section>
	<?php $this->addModalBack("menu") ?>
	<div class="view">
		<?php $this->addModalBack("header") ?>
		<h1>Liste des annonces</h1>
		<section class="menu-list">
			<div class="flex infos-menu-list">
				<div>
					Nombre d'annonces totales : <?php echo $annonces->countAllWebsiteAnnounces(); ?>
				</div>
				<div>
					Nombre d'annonces désactivées : <?php echo $annonces->countDesactivateAnnounces(); ?>
				</div>
				<div>
					<input type="text" id="search-bar-announce" class="search-bar-announce" placeholder="Rechercher une annonce" />
				</div>
			</div>
		</section>
		<div id="main-display-search"></div>
		<section class="display-list display-list-announces" id="display-list-announces">
			<table id="count-elements">
				<thead>
					<tr>
						<th id="title">Titre</th>
						<th>Auteur</th>
						<th>Date de création</th>
						<th>Etat</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$annoncesList = $annonces->getAllAnnounces(0); // 0 => offset de départ
						$i = 0;
						foreach($annoncesList as $key => $value): ?>
							<tr id="announce-<?php echo $i; ?>">
								<td><?php echo htmlentities($value['titre'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['creator'], ENT_QUOTES); ?></td>
								<td><?php echo date(EUROPEAN_DATE_FORMAT_WITHOUT_TIME, strtotime($value['date'])); ?></td>
								<td id="announce-state-<?php echo $i; ?>"><?php echo ($value['etat']) ? "Active" : "Non active"; ?></td>
								<td>
									
									<div>
										<?php if($value['etat']): ?>
											<button data-slug="<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" id="activated-announce-in-page-list-<?php echo $i; ?>" class="cta-activate-desactivate-announce-in-page-list" title="Désactiver l'annonce ?" value="desactivate"><i class="fas fa-battery-full cta-announce-activated"></i></button>
										<?php else: ?>
											<button data-slug="<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" id="no-activated-announce-in-page-list<?php echo $i; ?>" class="cta-activate-desactivate-announce-in-page-list" title="Activer l'annonce ?" value="activate"><i class="fas fa-battery-empty cta-announce-desactivated"></i></button>
										<?php endif; ?>
										<a href="/<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" title="Visualiser"><i class="fas fa-eye"></i></a>
										<a href="website?page=<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" title="Editer"><i class="fas fa-edit"></i></a>
										<button name="<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" id="delete-announce-in-page-list" class="cta-delete-announce-in-page-list" title="Supprimer" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
									</div>

								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>

	</div>