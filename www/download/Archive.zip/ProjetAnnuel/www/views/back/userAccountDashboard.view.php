<title>Dashboard</title>
</head>
<body>
    <section>
        <?php $this->addModalBack("menu") ?>
        <div class="view">
            <?php $this->addModalBack("header") ?>
            <div class="welcome">
                <h1>Bienvenue sur Fryzzer !</h1>
                <h2> Par quoi pouvez-vous commencer ?</h2>

                <div class="sub-content flex">
                    <div class="sub-welcome">
                        <h3>Editer votre site</h3>
                        <ul>
                            <li><i class="far fa-file"></i><a href="/zz-admin/add-new-page">Créer une page</a></li>
                            <li><i class="fas fa-edit"></i><a href="/zz-admin/page-list">Modifier une page</a></li>
                            <li><i class="far fa-newspaper"></i><a href="/zz-admin/announce-list">Modifier une annonce</a></li>
                            <li><i class="fas fa-camera"></i><a href="/zz-admin/media">Gérer vos médias</a></li>
                            <li><i class="fas fa-eye"></i><a href="/">Voir votre site</a></li>
                        </ul>
                    </div>
                    <div class="sub-welcome">
                        <h3>Administrer</h3>
                        <ul>
                            <li><i class="fas fa-user"></i><a href="/zz-admin/users-list">Gerer les utilisateurs</a></li>
                            <li><i class="fas fa-user-cog"></i><a href="/zz-admin/users-list">Gerer vos administrateur</a></li>
                        </ul>
                    </div>
                    <div class="sub-welcome">
                        <h3>Gérer les flux</h3>
                        <ul>
                            <li><i class="fas fa-level-up-alt"></i><a href="/zz-admin/statistics">Analyse du traffic</a></li>
                            <li><i class="fas fa-chart-bar"></i><a href="/zz-admin/statistics">Voir les statistiques de votre site</a></li>
                        </ul>
                    </div>
                </div>

            </div>

            <div class="bottom-part flex">
                <div class="notifs-content">
                    <div class="activity">

                        <h1>Activitées récentes</h1>
                        <h2>Que s'est t'il passé sur votre site ?</h2>

                        <?php 
                            $notifications = new Notifications(); 
                            $result = $notifications->getAllNotifs(TRUE); // true pour indiquer qu'il s agit des notifs affiché sur le dashboard

                            if(gettype($result) === "array"):
                            ?>
                            <?php foreach($result as $key => $value): ?>
        
                                <?php if($value["type_notification"] === ASK_NEW_ADMIN_NOTIFICATION_TYPE): ?>
                        
                                        <div class="request">

                                            <div class="left-request">
                                                <p class="title-request">Demande d'ajout</p>
                                                <p class="title-subject">L'utilisateur <?php echo $value["mail"]; ?> a fait une demande pour devenir Administrateur</p>
                                            </div>
                                            <div class="right-request">
                                                <p class="date-request"><?php echo date(EUROPEAN_DATE_FORMAT, strtotime($value["date"])); ?></p>
                                                <input class="accept-notification" data-type="<?php echo ASK_NEW_ADMIN_NOTIFICATION_TYPE; ?>" type="button" data-mail="<?php echo $value["mail"]; ?>" data-key="<?php echo $value["key"]; ?>" value="Accepter" />
                                                <input class="decline-notification" data-type="<?php echo ASK_NEW_ADMIN_NOTIFICATION_TYPE; ?>" type="button" data-mail="<?php echo $value["mail"]; ?>" data-key="<?php echo $value["key"]; ?>" value="Refuser" />
                                            </div>
                                        </div>

                                    <?php elseif($value["type_notification"] === NEW_ANNOUNCE_NOTIFICATION_TYPE): ?>   

                                        <div class="request">

                                            <div class="left-request">
                                                <p class="title-request">Nouvelle annonce</p>
                                                <p class="title-subject"><?php echo $value["contenu"]; ?></p>
                                            </div>
                                            <div class="right-request">
                                                <p class="date-request"><?php echo date(EUROPEAN_DATE_FORMAT, strtotime($value["date"])); ?></p>
                                                <input class="accept-notification" data-type="<?php echo NEW_ANNOUNCE_NOTIFICATION_TYPE; ?>" type="button" data-slug="<?php echo $value["slug"]; ?>" value="Accepter" />
                                                <input class="decline-notification" data-type="<?php echo NEW_ANNOUNCE_NOTIFICATION_TYPE; ?>" type="button" data-slug="<?php echo $value["slug"]; ?>" value="Refuser" />
                                            </div>
                                        </div>

                                    <?php endif; ?>
                                <?php endforeach; ?>
                                
                            <?php else: ?>
                                <div class="no-notification-block"><?php echo $result; ?></div>
                            <?php endif; ?>

                        <div class="state-request">
                            <a class="link" href="notifications">Voir toutes les notifications (<?php echo $notifications->countNotifications(); ?>)</a>
                        </div>
                    </div>
                </div>
                <div class="note-content">
                    <div class="note">
                        <h1>Note</h1>

                        <div>
                            <div class="input-text">
                                <label for="note-title"></label>
                                <input id="title-note-dashboard" class="note-title" type="text" placeholder="Titre">
                                <input id="text-note-dashboard" class="note-title" type="text" placeholder="Ecrivez votre idée">
                            </div>
                        </div>
                        <div id="display-insert-note-status"></div>
                        <div class="note-save">
                            <input class="btn" id="cta-insert-note" type="button" value="Enregistrer votre note" />
                            <a href="#" id="dashboard-access-notes">Consulter toutes vos notes >></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--<script src="/assets/js/back/script.js"></script>-->