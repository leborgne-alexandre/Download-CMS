<title>Médias</title>
</head>
<body>
	<section>
	<?php $this->addModalBack("menu") ?>
	<div class="view">
        <?php $this->addModalBack("header") ?>
        <h1>Médias</h1>
        <div class="info-box-medias">
            <p class="info-text">
                <b>Formats autorisés :</b> PNG - JPEG - GIF - SVG - APNG - BMP - ICO - WEBP (images) | MP4 - WEBM - OGG (vidéos)
            </p>
            <p class="info-text">
                <b>Poids maximum :</b> 2 Mo (images) | 25 Mo (vidéos)
            </p>
            <p class="info-text">
                Nous vous conseillons de compresser vos médias pour un maximum de performance -> <a href="https://compressnow.com/fr/" target="_blank">site de compression d'image et de vidéo</a>
            </p>
        </div>
        <?php $media = new Media(); ?>
        <section class="menu-list stats-medias">
			<div class="flex infos-menu-list">
				<div>
					Nombre d'images : <?php echo $media->countMedias("image"); ?>
				</div>
				<div>
					Nombre de vidéos : <?php echo $media->countMedias("video"); ?>
				</div>
			</div>
		</section>
        <section>
            <div id="display-media-loader"></div>
            <div id="display-media-status" class="flex column"></div>
            <div id="display-all-medias" class="flex">
                <div class="input-file-container bloc-media">
                    <form id="form-input-file">
                        <input class="input-file" id="select-file" name="select-file" type="file">
                        <input type="submit" id="upload-media" class="hidden" value="Télécharger" />
                        <input type="hidden" id="media-to-display-to-preview" />
                    </form>
                    <label for="select-file" class="plus-add-media">
                        <i class="far fa-plus-square"></i>
                    </label>
                    <label for="select-file" class="input-file-trigger" tabindex="0"></label>
                    <label for="select-file" class="label-add-media">Ajouter un média</label>
                </div>
                <div id="new-media-after-insert" class="flex"></div>
                <?php $this->addModalBack("displayMedias") ?>
            </div>
            <div id="display-preview-media"></div>
        </section>
	</div>