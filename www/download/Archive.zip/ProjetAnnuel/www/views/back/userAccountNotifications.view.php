<title>Notifications</title>
</head>
<body>
    <?php $notifications = new Notifications(); ?>
    <section>
        <?php $this->addModalBack("menu") ?>
        <div class="view">
            <?php $this->addModalBack("header") ?>
            <section class="menu-list">
                <div class="flex infos-menu-list notifications-infos">
                    <div>
                        Nombre de notifications : <?php echo $notifications->countNotifications(); ?>				
                    </div>
                    <div>
                        <button id="accept-all-announces" class="cta-accept-all-new-announce-notifs">Accepter toutes les annonces</button>				
                    </div>
                </div>
            </section>
            <div class="notifs-content">
                <div class="activity">
                    <h1>Notifications</h1>
                    <?php 
                        $result = $notifications->getAllNotifs();

                        if(gettype($result) === "array"):
                            $i = 1;
                        ?>
                        <?php foreach($result as $key => $value): ?>

                            <?php if($value["type_notification"] === ASK_NEW_ADMIN_NOTIFICATION_TYPE): ?>
                            
                            <div class="request">

                                <div class="left-request">
                                    <p class="title-request">Demande d'ajout</p>
                                    <p class="title-subject">L'utilisateur <?php echo $value["mail"]; ?> a fait une demande pour devenir Administrateur</p>
                                </div>
                                <div class="right-request">
                                    <p class="date-request"><?php echo date(EUROPEAN_DATE_FORMAT, strtotime($value["date"])); ?></p>
                                    <input class="accept-notification" data-type="<?php echo ASK_NEW_ADMIN_NOTIFICATION_TYPE; ?>" type="button" data-mail="<?php echo $value["mail"]; ?>" data-key="<?php echo $value["key"]; ?>" value="Accepter" />
                                    <input class="decline-notification" data-type="<?php echo ASK_NEW_ADMIN_NOTIFICATION_TYPE; ?>" type="button" data-mail="<?php echo $value["mail"]; ?>" data-key="<?php echo $value["key"]; ?>" value="Refuser" />
                                </div>
                            </div>

                            <?php elseif($value["type_notification"] === NEW_ANNOUNCE_NOTIFICATION_TYPE): ?>   

                                <div class="request" id="is-new-announce-<?php echo $i; ?>">

                                    <div class="left-request">
                                        <p class="title-request">Nouvelle annonce</p>
                                        <p class="title-subject"><?php echo $value["contenu"]; ?></p>
                                    </div>
                                    <div class="right-request">
                                        <p class="date-request"><?php echo date(EUROPEAN_DATE_FORMAT, strtotime($value["date"])); ?></p>
                                        <input class="accept-notification" data-type="<?php echo NEW_ANNOUNCE_NOTIFICATION_TYPE; ?>" type="button" data-slug="<?php echo $value["slug"]; ?>" value="Accepter" />
                                        <input class="decline-notification" data-type="<?php echo NEW_ANNOUNCE_NOTIFICATION_TYPE; ?>" type="button" data-slug="<?php echo $value["slug"]; ?>" value="Refuser" />
                                    </div>
                                </div>

                            <?php endif; ?>  
                                <?php $i++ ?>
                        <?php endforeach; ?>
                            
                        <?php else: ?>
                            <div class="no-notification-block"><?php echo $result; ?></div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </section>