<title>Liste des pages</title>
</head>
<body>
	<?php $pages = new Pages(); ?>
	<section>
	<?php $this->addModalBack("menu") ?>
	<div class="view">
		<?php $this->addModalBack("header") ?>
		<h1>Liste des pages</h1>
		<section class="menu-list">
			<div class="flex infos-menu-list">
				<div>
					Nombre de pages totale(s) : <?php echo $pages->countAllWebsitePages(); ?>
				</div>
				<div>
					Brouillon : <?php echo $pages->countWebsitePagesNonActive(); ?>
				</div>
				<div>
					<input type="text" id="search-bar-pages" class="search-bar-pages" placeholder="Rechercher une page" />
				</div>
			</div>
		</section>
		<div id="main-display-search"></div>
		<section class="display-list" id="display-list-pages">
			<table id="count-elements">
				<thead>
					<tr>
						<th id="title">Titre</th>
						<th>Auteur</th>
						<th>Date de modification</th>
						<th>Description</th>
						<th>Etat</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$pagesList = $pages->getAllPages();
						$i = 0;
						foreach($pagesList as $key => $value): ?>
							<tr id="line-page-list-<?php echo $i; ?>">
								<td><?php echo htmlentities($value['nom_page'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['creator'], ENT_QUOTES); ?></td>
								<td><?php echo date(EUROPEAN_DATE_FORMAT, strtotime($value['last_update'])); ?></td>
								<td><?php echo htmlentities($value['description'], ENT_QUOTES); ?></td>
								<td id="page-state-<?php echo $i; ?>"><?php echo $value['etat']; ?></td>
								<td>
									
									<div>
										<?php if($value['slug'] != "error404"  && $value['slug'] != "maintenance"): ?>
											<?php if($value['etat'] == "active"): ?>
												<button id="active-page-<?php echo $i; ?>" class="active-no-active-button" title="Désactiver la page ?" name="<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" value="desactivate"><i class="fas fa-battery-full active-page active-no-active-icon"></i></button>
											<?php else: ?>
												<button id="no-active-page-<?php echo $i; ?>" class="active-no-active-button" title="Activer la page ?" name="<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" value="activate"><i class="fas fa-battery-empty no-active-page active-no-active-icon"></i></button>
											<?php endif; ?>
										<?php endif; ?>
										<a href="/<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" title="Visualiser"><i class="fas fa-eye"></i></a>
										<a href="website?page=<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" title="Editer"><i class="fas fa-edit"></i></a>
										<?php if($value['is_deletable']): ?>
											<button name="<?php echo htmlentities($value['slug'], ENT_QUOTES); ?>" id="delete-page-in-page-list" class="cta-delete-page-in-page-list" title="Supprimer" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
										<?php endif; ?>
									</div>

								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>

	</div>