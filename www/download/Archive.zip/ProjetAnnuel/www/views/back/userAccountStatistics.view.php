<title>Statistiques</title>
</head>
<body>
    <?php $announces = new Annonces(); ?>
    <?php $siteUsers = new Siteusers(); ?>
    <section>
        <?php $this->addModalBack("menu") ?>
        <div class="view">
            <?php $this->addModalBack("header") ?>
            <h1>Statistiques</h1>
            <section class="flex section-boxes-stats">
                <div class="box-stats flex column">
                    <h2 class="stat-title">Nombre d'annonces</h2>
                    <div class="stat-value" title="<?php echo $announces->countAllWebsiteAnnounces(); ?>"><?php echo $announces->countAllWebsiteAnnounces(); ?></div>
                </div>
                <div class="box-stats flex column">
                    <h2 class="stat-title">Nombre d'utilisateurs</h2>
                    <div class="stat-value" title="<?php echo $siteUsers->countAllUsers(); ?>"><?php echo $siteUsers->countAllUsers(); ?></div>
                </div>
                <div class="box-stats flex column">
                    <h2 class="stat-title">Nombre de nouveaux utilisateurs par jour en moyenne</h2>
                    <div class="stat-value" title="<?php echo $siteUsers->countAverageNewSignUpPerDay(); ?>"><?php echo $siteUsers->countAverageNewSignUpPerDay(); ?></div>
                </div>
            </section>
            <section class="chart-section">
                <div class="chart-container">
                    <canvas id="chart-pages-visited-per-day"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="chart-new-announces-per-day"></canvas>
                </div>
            </section>
            <?php $statsPagesVisited = new Stats_visited_pages(); ?>
            <script>
                var ctx1 = document.getElementById('chart-pages-visited-per-day').getContext('2d');
                var myChart = new Chart(ctx1, {
                    type: 'bar',
                    data: {
                        labels: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'],
                        datasets: [{
                            label: "Nombre de pages visités",
                            data: [
                                <?php echo $statsPagesVisited->selectDayCounter("Monday"); ?>, 
                                <?php echo $statsPagesVisited->selectDayCounter("Tuesday"); ?>,
                                <?php echo $statsPagesVisited->selectDayCounter("Wednesday"); ?>,
                                <?php echo $statsPagesVisited->selectDayCounter("Thursday"); ?>, 
                                <?php echo $statsPagesVisited->selectDayCounter("Friday"); ?>,
                                <?php echo $statsPagesVisited->selectDayCounter("Saturday"); ?>, 
                                <?php echo $statsPagesVisited->selectDayCounter("Sunday"); ?>
                            ],
                            backgroundColor: [
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)'
                            ],
                            borderColor: [
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: { display: false },
                        title: {
                            display: true,
                            text: 'Nombre de pages visités par jour'
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        },
                        tooltips: {
                            enabled: true,
                            intersect: false,
                            displayColors: false
                        }
                    }
                });
                var ctx2 = document.getElementById('chart-new-announces-per-day').getContext('2d');
                var myChart = new Chart(ctx2, {
                    type: 'line',
                    data: {
                        labels: ['<?php echo date('d-m-Y', strtotime("-7 days")); ?>', '<?php echo date('d-m-Y', strtotime("-6 days")); ?>', '<?php echo date('d-m-Y', strtotime("-5 days")); ?>', '<?php echo date('d-m-Y', strtotime("-4 days")); ?>', '<?php echo date('d-m-Y', strtotime("-3 days")); ?>', '<?php echo date('d-m-Y', strtotime("-2 days")); ?>', '<?php echo date('d-m-Y', strtotime("-1 days")); ?>', '<?php echo date("d-m-Y"); ?>', '<?php echo date('d-m-Y', strtotime("+1 days")); ?>'],
                        datasets: [{
                            label: "Nombre d'annonces ajoutées",
                            data: [
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-7 days"))); ?>,
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-6 days"))); ?>, 
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-5 days"))); ?>,
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-4 days"))); ?>,
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-3 days"))); ?>, 
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-2 days"))); ?>,
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("-1 days"))); ?>, 
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d')); ?>,
                                <?php echo $announces->getAddedAnnouncesPerDay(date('Y-m-d', strtotime("+1 days"))); ?>
                            ],
                            backgroundColor: [
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)',
                                'rgba(107, 111, 216, 0.7)'
                            ],
                            borderColor: [
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8',
                                '#6B6FD8'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: { display: false },
                        title: {
                            display: true,
                            text: 'Nombre d\'annonces ajoutées par jour'
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        },
                        tooltips: {
                            enabled: true,
                            intersect: false,
                            displayColors: false
                        }
                    }
                });
                </script>
        </div>
    </section>
    <script type="text/javascript" src="/assets/js/back/chart.js"></script>
