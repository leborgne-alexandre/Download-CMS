<title>Liste des utilisateurs</title>
</head>
<body>
	<?php $user = new Usr(); ?>
	<?php $siteUsers = new Siteusers(); ?>
	<section>
	<?php $this->addModalBack("menu"); ?>
	<div class="view">
		<?php $this->addModalBack("header"); ?>
		<h1>Liste des utilisateurs</h1>
		<section class="section-target-cta">
			<div class="bloc-target-cta flex">
				<input type="button" id="target-users" class="cta-target-users" value="Utilisateurs" />
				<input type="button" id="target-moderator" class="cta-target-moderator" value="Modérateurs" />
				<input type="button" id="target-admin" class="cta-target-admin" value="Administrateurs" />
				<input type="button" id="target-users-moderators-banned" class="cta-target-users-moderators-banned" value="Utilisateurs et modérateurs bannis" />
				<input type="button" id="target-admin-banned" class="cta-target-admin-banned" value="Administrateurs bannis" />
			</div>
		</section>
		<section class="menu-list menu-list-user" id="menu-list-user">
			<div class="flex infos-menu-list">
				<div>
					Nombre d'utilisateurs totals : <b><?php echo $siteUsers->countAllUsers(); ?></b>
				</div>
				<div>
					Utilisateurs bannis : <b><?php echo $siteUsers->countBanned(); ?></b>
				</div>
				<div>
					<input type="text" id="search-bar-users" class="search-bar-users" placeholder="Rechercher un utilisateur" />
				</div>
			</div>
		</section>
		<section class="menu-list menu-list-moderator hidden" id="menu-list-moderator">
			<div class="flex infos-menu-list">
				<div>
					Nombre de modérateurs totals : <b><?php echo $siteUsers->countAllUsers(ID_ROLE_MODERATOR); // 3 = roleID (moderateur) ?></b>
				</div>
				<div>
					Utilisateurs bannis : <b><?php echo $siteUsers->countBanned(); ?></b>
				</div>
				<div>
					<input type="text" id="search-bar-moderators" class="search-bar-moderator" placeholder="Rechercher un modérateur" />
				</div>
			</div>
		</section>
		<section class="menu-list menu-list-admin hidden" id="menu-list-admin">
			<div class="flex infos-menu-list">
				<div>
					Nombre d'administrateurs totals : <b><?php echo $user->countAllUsers(ID_ROLE_ADMIN); // ID_ROLE_ADMIN = roleID (admin) ?></b>
				</div>
				<div>
					Administrateurs bannis : <b><?php echo $user->countBanned(); ?></b>
				</div>
				<div>
					<input type="text" id="search-bar-admins" class="search-bar-admin" placeholder="Rechercher un administrateur" />
				</div>
			</div>
		</section>
		<section class="menu-list menu-list-users-moderators-banned hidden" id="menu-list-users-moderators-banned">
			<div class="flex infos-menu-list">
				<div>
					Nombre d'utilisateurs et de modérateurs totals : <b><?php echo $siteUsers->countAllUsers(); ?></b>
				</div>
				<div>
					Utilisateurs et modérateurs bannis : <b><?php echo $siteUsers->countBanned(); ?></b>
				</div>
				<div>
					<input type="text" id="search-bar-users-moderators-banned" class="search-bar-users-moderators-banned" placeholder="Rechercher un banni" />
				</div>
			</div>
		</section>
		<section class="menu-list menu-list-admin-banned hidden" id="menu-list-admin-banned">
			<div class="flex infos-menu-list">
				<div>
					Nombre d'administrateurs totals : <b><?php echo $user->countAllUsers(ID_ROLE_ADMIN); // ID_ROLE_ADMIN = roleID (admin) ?></b>
				</div>
				<div>
					Administrateurs bannis : <b><?php echo $user->countBanned(); ?></b>
				</div>
				<div>
					<input type="text" id="search-bar-admin-banned" class="search-bar-admin-banned" placeholder="Rechercher un banni" />
				</div>
			</div>
		</section>
		<div id="display-details" ></div>
		<div id="main-display-search"></div>
		<section class="display-list display-list-user" id="display-list-user">
			<table id="count-elements-user">
				<thead>
					<tr>
						<th>Nom</th>
						<th>Prénom</th>
						<th>Adresse mail</th>
						<th>Rôle</th>
						<th>Etat</th>
						<th>Statut</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$userList = $siteUsers->getAllUsers(0); // 0 = offset de depart
						$i = 0;
						foreach($userList as $key => $value): ?>
							<tr>
								<td><?php echo htmlentities($value['nom'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['prenom'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['mail'], ENT_QUOTES); ?></td>
								<td><?php echo (($value['role'] == NAME_ROLE_USER) ? '<i class="fas fa-user icon-user-list" title="Utilisateur" ></i>' :  '<i class="fas fa-user-shield icon-user-list" title="Modérateur"></i>'); ?></td>
								<td><?php echo (($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>'); ?></td>
								<td><?php echo (($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>'); ?></td>
								<td>
									<div>
										<button value="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" class="cta-more-details cta-more-details-user-moderator" title="+ détails"><i class="fas fa-eye"></i></button>
										<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="delete-user-in-user-list" class="cta-delete-user-in-user-list" title="Bannir cet utilisateur" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
									</div>
								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>
		<section class="display-list display-list-moderator hidden" id="display-list-moderator">
			<table id="count-elements-moderator">
				<thead>
					<tr>
						<th>Nom</th>
						<th>Prénom</th>
						<th>Adresse mail</th>
						<th>Rôle</th>
						<th>Etat</th>
						<th>Statut</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$userList = $siteUsers->getAllUsers(0, ID_ROLE_MODERATOR); // 0= offset de depart, ID_ROLE_MODERATOR = roleID (moderateur)
						$i = 0;
						foreach($userList as $key => $value): ?>
							<tr>
								<td><?php echo htmlentities($value['nom'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['prenom'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['mail'], ENT_QUOTES); ?></td>
								<td><i class="fas fa-user-shield icon-user-list" title="Modérateur"></td>
								<td><?php echo (($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>'); ?></td>
								<td><?php echo (($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>'); ?></td>
								<td>
									
									<div>
										<button class="cta-more-details cta-more-details-user-moderator" value="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" title="+ détails"><i class="fas fa-eye"></i></button>
										<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="delete-moderator-in-user-list" class="cta-delete-moderator-in-user-list" title="Bannir ce modérateur" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
									</div>

								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>
		<section class="display-list display-list-admin hidden" id="display-list-admin">
			<table id="count-elements-admin">
				<thead>
					<tr>
						<th>Nom d'utilisateur</th>
						<th>Adresse mail</th>
						<th>Rôle</th>
						<th>Etat</th>
						<th>Statut</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$userList = $user->getAdmin(0); // 0 = offset de départ
						$i = 0;
						foreach($userList as $key => $value): ?>
							<tr>
								<td><?php echo htmlentities($value['username'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['mail'], ENT_QUOTES); ?></td>
								<td><i class="fas fa-crown icon-user-list" title="Administrateur" ></i></td>
								<td><?php echo (($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>'); ?></td>
								<td><?php echo (($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>'); ?></td>
								<td>
									
									<div>
										<?php if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN): ?>
											<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="delete-admin-in-user-list" class="cta-delete-admin-in-user-list" title="Bannir cet administrateur" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
										<?php endif; ?>
									</div>

								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>
		<section class="display-list display-list-users-moderators-banned hidden" id="display-list-users-moderators-banned">
			<table id="count-elements-users-moderators-banned">
				<thead>
					<tr>
						<th>Nom</th>
						<th>Prénom</th>
						<th>Adresse mail</th>
						<th>Rôle</th>
						<th>Etat</th>
						<th>Statut</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$userList = $siteUsers->getBannedUsersAndModerators(0); // 0 => offset de départ
						$i = 0;
						foreach($userList as $key => $value): ?>
							<tr>
								<td><?php echo htmlentities($value['nom'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['prenom'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['mail'], ENT_QUOTES); ?></td>
								<td><?php echo (($value['role'] == NAME_ROLE_USER) ? '<i class="fas fa-user icon-user-list" title="Utilisateur" ></i>' :  '<i class="fas fa-user-shield icon-user-list" title="Modérateur"></i>'); ?></td>
								<td><?php echo (($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>'); ?></td>
								<td><?php echo (($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>'); ?></td>
								<td>
									
									<div>
										<button class="cta-more-details cta-more-details-user-moderator" value="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" title="+ détails"><i class="fas fa-eye"></i></button>
										<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="unban-user-moderator-in-user-list" class="cta-unban-in-user-list cta-unban-user-moderator-in-user-list" title="Débannir cet utilisateur" value="<?php echo $i; ?>"><i class="fas fa-undo"></i></button>
										<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="delete-users-moderators-banned-in-user-list" class="cta-delete-users-moderators-banned-in-user-list" title="Supprimer cet utilisateur" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
									</div>

								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>
		<section class="display-list display-list-admin-banned hidden" id="display-list-admin-banned">
			<table id="count-elements-admin-banned">
				<thead>
					<tr>
						<th>Nom d'utilisateur</th>
						<th>Adresse mail</th>
						<th>Rôle</th>
						<th>Etat</th>
						<th>Statut</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php 
						
						$userList = $user->getBannedAdmin(0); // 0 = offset de départ
						$i = 0;
						foreach($userList as $key => $value): ?>
							<tr>
								<td><?php echo htmlentities($value['username'], ENT_QUOTES); ?></td>
								<td><?php echo htmlentities($value['mail'], ENT_QUOTES); ?></td>
								<td><i class="fas fa-crown icon-user-list" title="Administrateur" ></i></td>
								<td><?php echo (($value['etat']) ? '<i class="fas fa-check icon-user-list" title="Vérifié" ></i>' :  '<i class="fas fa-times icon-user-list" title="Non vérifié"></i>'); ?></td>
								<td><?php echo (($value['statut']) ? '<i class="fas fa-lock icon-user-list" title="Banni" ></i>' :  '<i class="fas fa-lock-open icon-user-list" title="Actif"></i>'); ?></td>
								<td>
									
									<div>
										<?php if(isset($_SESSION['role_admin_or_superadmin']) && $_SESSION['role_admin_or_superadmin'] == ID_ROLE_SUPERADMIN): ?>
											<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="unban-admin-in-user-list" class="cta-unban-in-user-list cta-unban-admin-in-user-list" title="Débannir cet administrateur" value="<?php echo $i; ?>"><i class="fas fa-undo"></i></button>
											<button name="<?php echo htmlentities($value['mail'], ENT_QUOTES); ?>" id="delete-admin-banned-in-user-list" class="cta-delete-admin-banned-in-user-list" title="Supprimer cet administrateurs" value="<?php echo $i; ?>"><i class="fas fa-trash-alt"></i></button>
										<?php endif; ?>
									</div>

								</td>
							</tr>
						<?php $i++; endforeach; ?>
				</tbody>
			</table>

		</section>

	</div>