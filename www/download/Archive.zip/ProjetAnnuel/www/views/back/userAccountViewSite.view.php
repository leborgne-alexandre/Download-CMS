<title>Your website</title>
<style>
                body{
                    background-color: #FFFFFF !important; //mettre variable en fonction de la bdd (couleur de fond de la page)
                }
                .view-website{
                    background-color: #FFFFFF !important; //mettre variable en fonction de la bdd (couleur du body de la page)
                }
                <?php 
                    $css = new StylesImport("header");
                    echo $css->mainCSS;
                    if($_GET["page"] != "header" && $_GET["page"] != "footer")
                        $css2 = new StylesImport($_GET["page"], TRUE);
                    else
                        $css2 = new StylesImport("error404");
                    echo $css2->mainCSS;
                    $css3 = new StylesImport("footer");
                    echo $css3->mainCSS;
                    $styleFile = dirname(__FILE__).'/../../assets/styles/css/front/style.css';
                    if(file_exists($styleFile))
                        include ($styleFile);
                    else
                        echo "Erreur lors de la récupération du style";
                ?>
            </style>
            <script>
                $(document).ready(function(){
                    <?php 
                        $text = new StylesImport("header");
                        echo $text->containText;
                        if($_GET["page"] != "header" && $_GET["page"] != "footer")
                            $text2 = new StylesImport($_GET["page"], TRUE);
                        else
                            $text2 = new StylesImport("error404");
                        echo $css2->containText;
                        $text3 = new StylesImport("footer");
                        echo $text3->containText;
	                ?>
                });
            </script>
</head>
<body class="overflow-y-auto">
    <section>
        <?php 
            $this->addModalBack("menuElementList");
            $this->addModalBack("menuElementEdit");
            $this->addModalBack("menu");
        ?>

        <div class="view-website">
            <?php 
                $view = new View("dbPageForCMS", "inCMS");
                echo $view->getHtmlFromDb("header"); 
            ?>
                
                <script>
                    $(".btn-toggle").on("click", function(){
                        $(".toggle-nav").toggleClass("open");
                        $("#toggle-nav-filter").toggleClass("hidden visible");
                        $("body").toggleClass("overflow-y-auto overflow-y-hidden");
                        $(".toggle-nav").toggleClass("hidden");
                        $(".toggle-nav").toggleClass("background-transparent");
                    });

                    $("#toggle-nav-filter").on("click", function(){
                        $(".toggle-nav").toggleClass("open");
                        $("#toggle-nav-filter").toggleClass("visible hidden");
                        $("body").toggleClass("overflow-y-hidden overflow-y-auto");
                        $(".toggle-nav").toggleClass("hidden");
                        $(".toggle-nav").toggleClass("background-transparent");
                    });

                    var viewWebsiteSize = $(".view-website").width();
                    if(viewWebsiteSize < 768){
                        $(".toggle-nav").addClass("view-website-menu");
                        $(".toggle").toggleClass("toggle toggle-open");
                        $(".toggle-nav").addClass("background-transparent");
                        $(".toggle-nav").addClass("hidden");
                    }else{
                        $(".toggle-nav").removeClass("view-website-menu");
                        $(".toggle-open").toggleClass("toggle-open toggle");
                        $(".toggle-nav").addClass("background-transparent");
                    }

                    $(window).resize(function(){
                        var width = $(window).width();
                        if(width > 768){
                            $("#toggle-nav-filter").removeClass("visible");
                            $("#toggle-nav-filter").addClass("hidden");
                            $(".toggle-nav").removeClass("open");
                            $("body").removeClass("overflow-y-hidden");
                            $(".toggle-nav").addClass("background-transparent");
                            $("body").addClass("overflow-y-auto");
                            $(".toggle-nav").removeClass("hidden");
                        }else{
                            $(".toggle-nav").addClass("hidden");
                        }
                    });

                </script>

            <!-- here start the focus page content -->
            <?php    
                if($_GET["page"] != "header" && $_GET["page"] != "footer")
                    echo $view->getHtmlFromDb($_GET["page"], TRUE);
                else
                    echo $view->getHtmlFromDb("error404");
            ?>
            <div id="added-element-current-view" ></div>
            <!-- here end the focus page content -->
               <?php echo $view->getHtmlFromDb("footer"); ?>
        </div>
        <script>
            var viewWebsiteSize = $(".view-website").width();
            if(viewWebsiteSize < 768){
                $(".footer-width").css("flex-direction", "column");
            }else{
                $(".footer-width").removeAttr("style");
            }
        </script>
    </section>
    <div id="display-alert-add-element"></div>