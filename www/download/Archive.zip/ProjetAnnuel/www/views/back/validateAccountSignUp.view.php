<title>Validate Account...</title>
</head>
<body>
<?php
	if(isset($_SESSION["validateAccount"])){
		echo "<script>
			alertMessage('Le compte : ".$_SESSION['validateAccount']." a été vérifié avec succès', '/zz-sign_in');
		</script>";
		unset($_SESSION["validateAccount"]);
		session_destroy();
	}elseif(isset($_SESSION["errorValidateAccount"])){
		echo "<script>
			alertErrorMessage('Erreur lors de la validation du compte', '/zz-sign_in');
		</script>";
		unset($_SESSION["errorValidateAccount"]);
		session_destroy();
	}