<style>
	<?php 
		$style = new StylesImport();
		echo $style->mainCSS;
	?>
</style>
<script>
$(document).ready(function(){
	<?php 
		echo $style->containText;
	?>
});
</script>
<body class="overflow-y-auto">
    <header>
        <?php include (dirname(__FILE__).'/../templates/includes/front/header.php'); ?>
    </header>
    <?php include "modals/menu.mod.php"; ?>

    <?php echo $this->getHtmlFromDb(); ?>