<title>Bienvenue</title>
</head>

<body class="overflow-y-auto">
    <header>
        <?php include (dirname(__FILE__).'/../templates/includes/front/header.php'); ?>
    </header>
    
    <!--/////////////////////////////////////////////////////////////////////////////// -->
    <!-- /////////////////////////BESOIN-RECHERCHE//////////////////////////////////////// -->
    <!-- /////////////////////////////////////////////////////////////////////// -->

    <section class="search space-top">
        <div class="need" >
            <h2>Qu'est ce qui vous amène ici ?</h2>
            <form id="contact" action="#" method="post">
                <div class="need-content">
                    <label for="need">Expliquez votre besoin</label>
                    <input type="text" name="need" placeholder="Ex: J'ai besoin d'aide pour un déménagement" required="required" />
                    <label for="location">A quel endroit ?</label>
                    <input type="text" name="location" placeholder="Ex: Paris" required="required" />
                </div>
                <button id="element-2" class="cta-button" type="submit">Cherchez vos voisins ! </button>
            </form>
        </div>
    </section>

    <!--/////////////////////////////////////////////////////////////////////////////// -->
    <!-- /////////////////////////ANNONCE//////////////////////////////////////// -->
    <!-- /////////////////////////////////////////////////////////////////////// -->

    <section class="annonce">
        <h2>Dernières annonces</h2>
        <div class="last_articles">
            <article>
                <a href="#">
                    <div class="top-part">
                        <div class="price">100€</div>
                        <div class="date">23/11/12</div>
                    </div>
                    <div class="middle-part">
                        <div class="left-part">
                            <img class="profile" src="/assets/images/front/profil/ahego.jpg" alt="" />
                        </div>
                        <div class="right-part">
                            <div>Cherche cours de Codage</div>
                            <div><i class="fas fa-map-marker-alt"></i>Paris</div>
                        </div>
                    </div>
                </a>
            </article>
            <article>
                <a href="#">
                    <div class="top-part">
                        <div class="price">100€</div>
                        <div class="date">23/11/12</div>
                    </div>
                    <div class="middle-part">
                        <div class="left-part">
                            <img class="profile" src="/assets/images/front/profil/ahego.jpg" alt="" />
                        </div>
                        <div class="right-part">
                            <div>Cherche cours de Codage</div>
                            <div><i class="fas fa-map-marker-alt">&nbsp</i>Paris</div>
                        </div>
                    </div>
                </a>
            </article>
            <article><a href="#">
                <a href="#">
                    <div class="top-part">
                        <div class="price">100€</div>
                        <div class="date">23/11/12</div>
                    </div>
                    <div class="middle-part">
                        <div class="left-part">
                            <img class="profile" src="/assets/images/front/profil/ahego.jpg" alt="" />
                        </div>
                        <div class="right-part">
                            <div>Cherche cours de Codage</div>
                            <div><i class="fas fa-map-marker-alt">&nbsp</i>Paris</div>
                        </div>
                    </div>
                </a>
            </article>
            <article>
                <a href="#">
                    <div class="top-part">
                        <div class="price">100€</div>
                        <div class="date">23/11/12</div>
                    </div>
                    <div class="middle-part">
                        <div class="left-part">
                            <img class="profile" src="/assets/images/front/profil/ahego.jpg" alt="" />
                        </div>
                        <div class="right-part">
                            <div>Cherche cours de Codage</div>
                            <div><i class="fas fa-map-marker-alt">&nbsp</i>Paris</div>
                        </div>
                    </div>
                </a>
            </article>
            <article>
                <a href="#">
                    <div class="top-part">
                        <div class="price">100€</div>
                        <div class="date">23/11/12</div>
                    </div>
                    <div class="middle-part">
                        <div class="left-part">
                            <img class="profile" src="/assets/images/front/profil/ahego.jpg" alt="" />
                        </div>
                        <div class="right-part">
                            <div>Cherche cours de Codage</div>
                            <div><i class="fas fa-map-marker-alt">&nbsp</i>Paris</div>
                        </div>
                    </div>
                </a>
            </article>
            <article>
                <a href="#">
                    <div class="top-part">
                        <div class="price">100€</div>
                        <div class="date">23/11/12</div>
                    </div>
                    <div class="middle-part">
                        <div class="left-part">
                            <img class="profile" src="/assets/images/front/profil/ahego.jpg" alt="" />
                        </div>
                        <div class="right-part">
                            <div>Cherche cours de Codage</div>
                            <div><i class="fas fa-map-marker-alt">&nbsp</i>Paris</div>
                        </div>
                    </div>
                </a>
            </article>
        </div>
    </section>

    <!--/////////////////////////////////////////////////////////////////////////////// -->
    <!-- /////////////////////////HOW IT WORK/////////////////////////////////////// -->
    <!-- /////////////////////////////////////////////////////////////////////// -->
    <section class="how-it-work">
        <h2>Comment ca fonctionne ?</h2>
        <div class="explication">
            <div class="working">
                <img class="logo" src="/assets/images/front/commun/business.png" alt="Une image explicative">
                <p>Je poste ma demande</p>
            </div>
            <div class="working">
                <img class="logo" src="/assets/images/front/commun/group.png" alt="Une image explicative">
                <p>Les voisins me propose leurs offres</p>
            </div>

            <div class="working">
                <img class="logo" src="/assets/images/front/commun/agreement.png" alt="Une image explicative">
                <p>J'accepte l'offre qui me convient</p>
            </div>
        </div>
    </section>
    <!--/////////////////////////////////////////////////////////////////////////////// -->
    <!-- /////////////////////////FORM//////////////////////////////////////// -->
    <!-- /////////////////////////////////////////////////////////////////////// -->
    <section class="form-contact">
        <h2>Contactez nous</h2>
        <form method="POST" action="#">
            <div class="form-first">
                <label for="message">Votre nom</label>
                <input type="text" id="input-name" />
                <label for="message">Votre email</label>
                <input type="email" id="input-email" />
            </div>
            <div class="form-second">
                <label for="message">Votre message</label>
                <textarea name="message" type="text" id="input-message"></textarea>
            </div>
            <button class="cta-button" type="submit">J'envoie mon message</button>
        </form>
    </section>