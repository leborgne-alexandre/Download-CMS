<script>
    $(".btn-toggle").on("click", function(){
        $(".toggle-nav").toggleClass("open");
        $("#toggle-nav-filter").toggleClass("hidden visible");
        $("body").toggleClass("overflow-y-hidden overflow-y-auto");
    });

    $("#toggle-nav-filter").on("click", function(){
        $(".toggle-nav").toggleClass("open");
        $("#toggle-nav-filter").toggleClass("visible hidden");
        $("body").attr("class", "overflow-y-auto");
    });
    var width = $(window).width();
    if(width > 768){
        $(".toggle-nav").addClass("background-transparent");
    }
    $(window).resize(function(){
        var width = $(window).width();
        if(width > 768){
            $("#toggle-nav-filter").removeClass("visible");
            $("#toggle-nav-filter").addClass("hidden");
            $(".toggle-nav").removeClass("open");
            $(".toggle-nav").addClass("background-transparent");
            $("body").attr("class", "overflow-y-auto");
        }else{
            $(".toggle-nav").removeClass("background-transparent");
        }
    });
</script>