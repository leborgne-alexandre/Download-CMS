<style>
    	<?php 
    		$css = new StylesImport();
    		echo $css->mainCSS;
    	?>
	</style>

<body class="overflow-y-auto">
    <header>
        <?php include (dirname(__FILE__).'/../templates/includes/front/header.php'); ?>
    </header>

    <section id="element-premiere-section-inscription-1041" class="sign-up-first-section">
    	<div id="element-label-inscription-1042" class="label-sign-up"></div>
    </section>

    <section id="element-deuxieme-section-inscription-1043">
    	<form id="element-form-inscription-1044" class="subscription-form" method="POST">
    		<div class="flex-wrap">
	    		<div class="flex">
	    			<div class="flex-wrap">
	    				<label id="element-label-inscription-nom-1045">Nom :</label>
	    				<input type="text" id="element-input-nom-inscription-1046" name="input-nom-inscription" required="required"/>
	    				<label id="element-label-inscription-prenom-1047">Prénom :</label>
	    				<input type="text" id="element-input-prenom-inscription-1048" name="input-prenom-inscription" required="required"/>
	    				<label id="element-label-inscription-mail-1049">Mail :</label>
	    				<input type="email" id="element-input-mail-inscription-1050" name="input-mail-inscription" required="required"/>
	    				<label id="element-label-inscription-telephone-1068">Téléphone :</label>
	    				<input type="tel" id="element-input-telephone-inscription-1069" name="input-telephone-inscription" maxlength="10" required="required"/>
	    				<label id="element-label-inscription-age-1051">Année de naissance :</label>
	    				<input type="number" id="element-input-age-inscription-1052" name="input-age-inscription" min="1900"/>
	    			</div>
	    			<div class="flex-wrap">
	    				<label id="element-label-inscription-adresse-1053">Adresse :</label>
	    				<input type="text" id="element-input-adresse-inscription-1054" name="input-adresse-inscription" required="required"/>
	    				<label id="element-label-inscription-ville-1055">Ville :</label>
	    				<input type="text" id="element-input-ville-inscription-1056" name="input-ville-inscription" required="required"/>
	    				<label id="element-label-inscription-code-postal-1057">Code postal :</label>
	    				<input type="number" id="element-input-code-postal-inscription-1058" name="input-code-postal-inscription" required="required"/>
	    				<label id="element-label-inscription-departement-1059">Département :</label>
	    				<select id="element-input-departement-inscription-1060" name="input-departement-inscription" size="1">
						<option>Ain (01)<option>Aisne (02)<option>Allier (03)<option>Hautes-Alpes (05)<option>Alpes-de-Haute-Provence (04)<option>Alpes-Maritimes (06)<option>Ardèche (07)<option>Ardennes (08)<option>Ariège (09)<option>Aube (10)<option>Aude (11)<option>Aveyron (12)<option>Bouches-du-Rhône (13)<option>Calvados (14)<option>Cantal (15)<option>Charente (16)<option>Charente-Maritime (17)<option>Cher (18)<option>Corrèze (19)<option>Corse-du-Sud (2A)<option>Haute-Corse (2B)<option>Côte-d'or (21)<option>Côtes-d'armor (22)<option>Creuse (23)<option>Dordogne (24)<option>Doubs (25)<option>Drôme (26)<option>Eure (27)<option>Eure-et-Loir (28)<option>Finistère (29)<option>Gard (30)<option>Haute-Garonne (31)<option>Gers (32)<option>Gironde (33)<option>Hérault (34)<option>Ile-et-Vilaine (35)<option>Indre (36)<option>Indre-et-Loire (37)<option>Isère (38)<option>Jura (39)<option>Landes (40)<option>Loir-et-Cher (41)<option>Loire (42)<option>Haute-Loire (43)<option>Loire-Atlantique (44)<option>Loiret (45)<option>Lot (46)<option>Lot-et-Garonne (47)<option>Lozère (48)<option>Maine-et-Loire (49)<option>Manche (50)<option>Marne (51)<option>Haute-Marne (52)<option>Mayenne (53)<option>Meurthe-et-Moselle (54)<option>Meuse (55)<option>Morbihan (56)<option>Moselle (57)<option>Nièvre (58)<option>Nord (59)<option>Oise (60)<option>Orne (61)<option>Pas-de-Calais (62)<option>Puy-de-Dôme (63)<option>Pyrénées-Atlantiques (64)<option>Hautes-Pyrénées (65)<option>Pyrénées-Orientales (66)<option>Bas-Rhin (67)<option>Haut-Rhin (68)<option>Rhône (69)<option>Haute-Saône (70)<option>Saône-et-Loire (71)<option>Sarthe (72)<option>Savoie (73)<option>Haute-Savoie (74)<option>Paris (75)<option>Seine-Maritime (76)<option>Seine-et-Marne (77)<option>Yvelines (78)<option>Deux-Sèvres (79)<option>Somme (80)<option>Tarn (81)<option>Tarn-et-Garonne (82)<option>Var (83)<option>Vaucluse (84)<option>Vendée (85)<option>Vienne (86)<option>Haute-Vienne (87)<option>Vosges (88)<option>Yonne (89)<option>Territoire de Belfort (90)<option>Essonne (91)<option>Hauts-de-Seine (92)<option>Seine-Saint-Denis (93)<option>Val-de-Marne (94)<option>Val-d'oise (95)<option>Mayotte (976)<option>Guadeloupe (971)<option>Guyane (973)<option>Martinique (972)<option>Réunion (974)
						</select>
	    				<label id="element-label-inscription-region-1061">Région :</label>
	    				<select id="element-input-region-inscription-1062" name="input-region-inscription" size="1">
	    				<option>Alsace<option>Aquitaine<option>Auvergne<option>Basse Normandie<option>Bourgogne<option>Bretagne<option>Centre<option>Champagne Ardenne<option>Corse<option>Franche Comte<option>Haute Normandie<option>Ile de France<option>Languedoc Roussillon<option>Limousin<option>Lorraine<option>Midi-Pyrénées<option>Nord Pas de Calais<option>Provence Alpes Côte dAzur<option>Pays de la Loire<option>Picardie<option>Poitou Charente<option>Rhone Alpes
						</select>
	    			</div>
	    			<div>
	    			</div>
	    		</div>
	    		<div>
	    			<div class="flex-wrap">
		    			<label id="element-label-inscription-password-1063">Mot de passe :</label>
						<input type="password" id="element-input-password-inscription-1064" name="input-password-inscription" required="required"/>
						<label id="element-label-inscription-confirm-password-1065">Confirmer le mot de passe :</label>
						<input type="password" id="element-input-confirm-password-inscription-1066" name="input-confirm-password-inscription" required="required"/>
						<label id="element-label-inscription-description-1070">Dites en plus sur vous :</label>
						<textarea id="element-input-description-inscription-1071" name="input-description-inscription"></textarea>
						<input type="submit" id="element-submit-inscription-1067"  />
					</div>
	    		</div>
	    	</div>
    	</form>
    </section>