<title>test Front</title>
</head>
<body class="overflow-y-auto">
    <header>
        <?php include (dirname(__FILE__).'/../templates/includes/front/header.php'); ?>
    </header>