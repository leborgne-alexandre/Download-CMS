<!DOCTYPE html>
<html>
<head>
<?php include 'includes/back/head.php'; ?>

<?php include $this->v; ?>

<footer>
	<?php include 'includes/back/footer.php'; ?>
</footer>
</body>
</html>