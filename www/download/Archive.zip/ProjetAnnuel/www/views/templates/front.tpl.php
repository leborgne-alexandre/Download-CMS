<!DOCTYPE html>
<html>
<head>
<?php include 'includes/front/head.php'; ?>
</head>

<?php include $this->v; ?>

<footer>
	<?php include 'includes/front/footer.php'; ?>
</footer>
</body>
</html>