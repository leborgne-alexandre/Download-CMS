<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=0, maximum-scale=1, initial-scale=1.0, maximum-scale=1">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://malsup.github.io/jquery.form.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0/dist/Chart.min.js"></script>
<link rel="icon" type="image/png" href="/assets/images/back/logos/ico/logo_fryzzer_ico.ico" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<link rel="stylesheet" href="/assets/styles/css/back/style.css"/>
<link rel="stylesheet" href="/assets/styles/css/global/global.css"/>
<script type="text/javascript" src="/assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="/assets/js/back/fields.js"></script>
<script type="text/javascript" src="/assets/js/back/addMedia.js"></script>
<script type="text/javascript" src="/assets/js/back/addElement.js"></script>
<script type="text/javascript" src="/assets/js/back/ajax/ajax.js"></script>
<script type="text/javascript" src="/assets/js/back/alert.js"></script>
<script type="text/javascript" src="/assets/js/back/menu.js"></script>
<script type="text/javascript" src="/assets/js/back/notifications.js"></script>
<script type="text/javascript" src="/assets/js/back/focus-elements.js"></script>
<script type="text/javascript" src="/assets/js/back/editStyleOptions.js"></script>