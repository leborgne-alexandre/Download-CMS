<header>
    <ul>
       <li><a href="index.php?page=home">Accueil</a></li>
    </ul>
</header>