<?php echo $this->getFooterFromDb(); ?>
        <!--<div class="footer-content">
            <div id="element-footer-first-24" class='footer-first'>
                <div id="element-bloc-nous-contacter-23" class="contact-form-title">
                    <div id="element-line-gauche-contacter-21"></div>
                    <div id="element-label-nous-contacter-13">Nous contacter</div>
                    <div id="element-line-droite-contacter-22"></div> 
                </div>
                <form id="element-form-footer-12">
                    <label id="element-label-nom-14">Nom :</label>
                    <input id="element-input-nom-15" type="text" />
                    <label id="element-label-mail-16" >E-mail :</label>
                    <input id="element-input-mail-17" type="email" />
                    <label id="element-label-message-18">Message :</label>
                    <textarea id="element-textarea-message-19"></textarea>
                    <input id="element-submit-20" type="submit" value="Envoyer" />
                </form>
            </div>
            <div id="element-footer-second-25" class='footer-second'>
                <div class="flex-vertical">
                    <div id="element-section-top-right-footer-3">
                        
                    </div>
                    <div id="element-bloc-social-11" class="social">
                        <p id="element-label-actu-footer-2">Suivez notre actualité :</p>
                        <div id="element-bloc-icons-27" class="logo">
                            <a href="#"><div id="element-icon-facebook-28" class="social-logo logo-facebook"></div></a>
                            <a href="#"><div id="element-icon-youtube-29" class="social-logo logo-youtube"></div></a>
                            <a href="#"><div id="element-icon-twitter-30" class="social-logo logo-twitter"></div></a>
                        </div>
                    </div>
                    <div id="element-bloc-links-footer-4">
                        <ul id="element-ul-links-footer-26">
                            <li id="element-li-questions-footer-5"><a href="#" id="element-link-questions-8">Questions</a></li>
                            <li id="element-li-contact-footer-6"><a href="#" id="element-link-contact-footer-9">Contact</a></li>
                            <li id="element-li-mentions-legales-footer-7"><a href="#" id="element-link-mentions-legales-footer-10">Mentions Légales</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>-->