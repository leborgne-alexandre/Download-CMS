<?php echo $this->getHeaderFromDb(); ?>

	<!--<nav id="element-nav-32">
		<div class="container-nav" id="element-container-nav-35">
			<div class="content-menu">
				<div id="element-header-logo-33" class="logo" ></div>
				<div class="toggle"><a href="#" id="element-burger-menu-34" class="btn-toggle">☰</a></div>
			</div>
			<ul class="toggle-nav">
				<li><a id="element-nav-link-accueil-36" href="#">Accueil</a></li>
				<li><a id="element-nav-link-demandes-37" href="#">Demandes</a></li>
				<li><a id="element-nav-link-annonces-38" href="#">Annonces</a></li>
				<li><a id="element-nav-link-inscription-39" href="#">Inscription</a></li>
				<li><a id="element-nav-link-connexion-40" href="#">Connexion</a></li>
			</ul>
		</div>
	</nav>
	<div id="toggle-nav-filter" class="hidden"></div>-->